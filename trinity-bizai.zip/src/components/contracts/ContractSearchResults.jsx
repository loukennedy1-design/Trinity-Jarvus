import React, { useState, useMemo } from 'react';
import ContractCard from '@/components/contracts/ContractCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Loader2, Filter } from 'lucide-react';

export default function ContractSearchResults({ opportunities, onSearch, onSelect, onAnalyze, searching }) {
  const [keywords, setKeywords] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = useMemo(() => {
    if (filter === 'all') return opportunities;
    return opportunities.filter(o => o.match_category === filter);
  }, [opportunities, filter]);

  const counts = useMemo(() => ({
    strong: opportunities.filter(o => o.match_category === 'strong').length,
    adjacent: opportunities.filter(o => o.match_category === 'adjacent').length,
    all: opportunities.length
  }), [opportunities]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 flex gap-2">
          <Input value={keywords} onChange={e => setKeywords(e.target.value)} onKeyDown={e => e.key === 'Enter' && onSearch(keywords)} placeholder="Search keywords (optional — defaults to your profile)" className="bg-background/50" />
          <Button onClick={() => onSearch(keywords)} disabled={searching} className="gap-2">
            {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Search
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-muted-foreground" />
        {['all', 'strong', 'adjacent'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${filter === f ? 'bg-primary/15 text-primary border-primary/30' : 'bg-muted/20 text-muted-foreground border-border hover:border-primary/20'}`}>
            {f === 'all' ? `All (${counts.all})` : f === 'strong' ? `Strong (${counts.strong})` : `Adjacent (${counts.adjacent})`}
          </button>
        ))}
      </div>

      {searching ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Trinity is searching SAM.gov and scoring matches...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground">{opportunities.length === 0 ? 'No searches yet. Click Search to find contracts.' : 'No opportunities in this category.'}</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filtered.map(o => <ContractCard key={o.id} opportunity={o} onSelect={onSelect} onAnalyze={onAnalyze} />)}
        </div>
      )}
    </div>
  );
}