import React, { useState } from 'react';
import { Settings as SettingsIcon } from 'lucide-react';
import BusinessPage from '@/components/business/BusinessPage';
import CompanyProfileForm from '@/components/contracts/CompanyProfileForm';
export default function Settings() {
  const [saved, setSaved] = useState(false);
  return <BusinessPage title="Company Settings" subtitle="The capabilities and credentials behind every contract match." icon={SettingsIcon}>{saved && <p role="status" className="text-primary">Company profile saved.</p>}<CompanyProfileForm hideApiKey onSaved={() => setSaved(true)} /></BusinessPage>;
}