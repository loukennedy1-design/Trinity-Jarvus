import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CheckCircle2, Circle, ExternalLink, Send } from 'lucide-react';

const STEPS = [
  { title: 'Log in to SAM.gov', desc: 'Go to sam.gov and sign in with your credentials. Navigate to the opportunity using the solicitation number.' },
  { title: 'Open the Response Portal', desc: 'Click "Respond" or "Submit Response" on the opportunity page to open the submission portal.' },
  { title: 'Upload Technical Proposal', desc: 'Upload your compiled technical proposal (Executive Summary, Technical Approach, Past Performance, Management Plan). Check page limits from the analysis.' },
  { title: 'Upload Required Forms', desc: 'Upload the completed required forms identified in the analysis (SF-33, representations and certifications, etc.).' },
  { title: 'Upload Supporting Documents', desc: 'Attach any supporting documents — resumes, past performance write-ups, capability statements.' },
  { title: 'Review All Sections', desc: 'Before submitting, review every uploaded file. Ensure filenames match section names and all required fields are complete.' },
  { title: 'Submit and Confirm', desc: 'Click Submit. SAM.gov will send a confirmation email. Save the confirmation number for your records.' }
];

export default function SubmissionGuide({ opportunity, proposal, onBack }) {
  const [checked, setChecked] = useState(new Set());
  const [submitting, setSubmitting] = useState(false);

  const toggle = (i) => {
    const next = new Set(checked);
    next.has(i) ? next.delete(i) : next.add(i);
    setChecked(next);
  };

  const markSubmitted = async () => {
    setSubmitting(true);
    try {
      await base44.entities.ContractOpportunity.update(opportunity.id, { status: 'submitted', submitted_at: opportunity.submitted_at || new Date().toISOString() });
      if (proposal) {
        await base44.entities.Proposal.update(proposal.id, { overall_status: 'submitted' });
      }
      onBack();
    } catch (e) { console.error(e); }
    setSubmitting(false);
  };

  const allChecked = checked.size === STEPS.length;

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to proposal
      </button>

      <div>
        <h2 className="font-heading text-xl font-semibold text-foreground mb-1">Submission Guide</h2>
        <p className="text-sm text-muted-foreground">Trinity walks you through submitting on SAM.gov. You do the actual submission — Trinity guides each step.</p>
      </div>

      {opportunity.solicitation_url && (
        <a href={opportunity.solicitation_url} target="_blank" rel="noreferrer">
          <Button variant="outline" className="gap-2 w-full">
            <ExternalLink className="w-4 h-4" /> Open Opportunity on SAM.gov
          </Button>
        </a>
      )}

      <div className="space-y-3">
        {STEPS.map((step, i) => (
          <div key={i} className={`glass-card rounded-2xl p-4 flex gap-3 cursor-pointer transition-all ${checked.has(i) ? 'border-primary/30 opacity-60' : ''}`} onClick={() => toggle(i)}>
            <div className="flex-shrink-0 mt-0.5">
              {checked.has(i) ? <CheckCircle2 className="w-5 h-5 text-primary" /> : <Circle className="w-5 h-5 text-muted-foreground/40" />}
            </div>
            <div>
              <h3 className={`font-heading text-sm font-semibold ${checked.has(i) ? 'text-muted-foreground line-through' : 'text-foreground'}`}>{i + 1}. {step.title}</h3>
              <p className="text-sm text-muted-foreground mt-0.5">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="glass-card rounded-2xl p-5 border-primary/20">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="font-heading text-sm font-semibold text-foreground">Mark as Submitted</h3>
            <p className="text-xs text-muted-foreground">After you submit on SAM.gov, log it here for tracking.</p>
          </div>
          <Button onClick={markSubmitted} disabled={!allChecked || submitting} className="gap-2">
            {submitting ? 'Saving...' : <><Send className="w-4 h-4" /> Mark Submitted</>}
          </Button>
        </div>
        {!allChecked && <p className="text-xs text-muted-foreground/60 mt-2">Complete all steps above first.</p>}
      </div>
    </div>
  );
}