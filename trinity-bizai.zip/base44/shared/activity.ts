import { waitUntil } from 'base44:runtime';
export function recordActivity(base44, user, action_type, description, entity_type = '', entity_id = '', metadata = {}) {
  if (!user?.id) return;
  // The server controls action contents and owner attribution. Ordinary users cannot forge audit entries.
  waitUntil(base44.asServiceRole.entities.ActivityLog.create({owner_id:user.id, action_type, description, entity_type, entity_id, metadata}).catch(error => console.warn('Activity logging failed:', error.message)));
}