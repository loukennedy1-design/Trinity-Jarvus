import React from 'react';
import { Loader2, Check, Plug, PlugZap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ConnectorCard({ integration, status, onConnect, onDisconnect, busy }) {
  const connected = status?.connected;
  const isBusy = busy === integration.id;
  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <integration.icon className="w-5 h-5 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-foreground truncate">{integration.name}</h3>
            {connected ? (
              <span className="inline-flex items-center gap-1 text-xs text-primary">
                <Check className="w-3 h-3" /> Connected
              </span>
            ) : (
              <span className="text-xs text-muted-foreground">Not connected</span>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">{integration.description}</p>
        </div>
      </div>
      <ul className="text-xs text-muted-foreground space-y-1">
        {integration.capabilities.map((c) => (
          <li key={c} className="flex items-center gap-1.5">
            <span className="w-1 h-1 rounded-full bg-primary/60" /> {c}
          </li>
        ))}
      </ul>
      <div className="flex gap-2 mt-1">
        {connected ? (
          <Button variant="outline" size="sm" disabled={isBusy} onClick={() => onDisconnect(integration)} className="flex-1">
            {isBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plug className="w-4 h-4" />} Disconnect
          </Button>
        ) : (
          <Button size="sm" disabled={isBusy} onClick={() => onConnect(integration)} className="flex-1">
            {isBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlugZap className="w-4 h-4" />} Connect
          </Button>
        )}
      </div>
    </div>
  );
}