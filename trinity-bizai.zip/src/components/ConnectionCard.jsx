import React from 'react';
import { FileText, HardDrive, Table, Mail, MessageSquare, Calendar, CalendarDays, BookOpen, Link2, Check, AlertCircle } from 'lucide-react';

const iconMap = {
  FileText,
  HardDrive,
  Table,
  Mail,
  MessageSquare,
  Calendar,
  CalendarDays,
  BookOpen,
  Link2
};

export default function ConnectionCard({ service, onConnect, onDisconnect }) {
  const Icon = iconMap[service.icon] || Link2;
  const connected = service.status === 'connected';

  return (
    <div className="glass-card rounded-2xl p-5 flex items-center gap-4 transition-all duration-300 hover:border-primary/20">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
        connected ? 'bg-primary/15' : 'bg-accent/40'
      }`}>
        <Icon className={`w-6 h-6 ${connected ? 'text-primary' : 'text-muted-foreground'}`} />
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="font-heading text-base font-semibold text-foreground">{service.display_name}</h3>
        <div className="flex items-center gap-1.5 mt-0.5">
          {connected ? (
            <>
              <Check className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs text-primary">Connected</span>
              {service.items_synced > 0 && (
                <span className="text-xs text-muted-foreground">· {service.items_synced} items synced</span>
              )}
            </>
          ) : service.status === 'error' ? (
            <>
              <AlertCircle className="w-3.5 h-3.5 text-destructive" />
              <span className="text-xs text-destructive">Connection error</span>
            </>
          ) : (
            <span className="text-xs text-muted-foreground">Not connected</span>
          )}
        </div>
      </div>

      {connected ? (
        <button
          onClick={() => onDisconnect?.(service)}
          className="px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-colors"
        >
          Disconnect
        </button>
      ) : (
        <button
          onClick={() => onConnect?.(service)}
          className="px-4 py-2 rounded-lg text-sm font-medium bg-primary/10 text-primary border border-primary/20 hover:bg-primary hover:text-primary-foreground transition-all"
        >
          Connect
        </button>
      )}
    </div>
  );
}