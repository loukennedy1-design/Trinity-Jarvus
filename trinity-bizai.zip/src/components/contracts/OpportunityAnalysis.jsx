import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, FileSearch, ArrowLeft, Check, AlertTriangle, XCircle, PenLine, Upload } from 'lucide-react';

export default function OpportunityAnalysis({ opportunity, onBack, onDraftProposal }) {
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState(null);
  const [uploadedUrl, setUploadedUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const analysis = opportunity.analysis;

  const handleAnalyze = async () => {
    setAnalyzing(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('analyzeOpportunity', {
        opportunity_id: opportunity.id,
        uploaded_file_url: uploadedUrl
      });
      if (res.data?.error) setError(res.data.message || res.data.error);
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    }
    setAnalyzing(false);
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setUploadedUrl(file_url);
    } catch (err) { console.error(err); }
    setUploading(false);
  };

  if (analyzing) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Trinity is analyzing the solicitation...</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to results
      </button>

      <div>
        <h2 className="font-heading text-xl font-semibold text-foreground mb-1">{opportunity.title}</h2>
        <div className="flex items-center gap-3 text-sm text-muted-foreground">
          <span>{opportunity.agency}</span>
          {opportunity.solicitation_number && <span>· {opportunity.solicitation_number}</span>}
        </div>
      </div>

      {!analysis ? (
        <div className="glass-card rounded-2xl p-8 text-center space-y-4">
          <FileSearch className="w-12 h-12 text-primary mx-auto" />
          <div>
            <h3 className="font-heading text-lg font-semibold text-foreground mb-1">Analyze This Solicitation</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">Trinity will break down the requirements, evaluation criteria, and gap analysis against your company profile.</p>
          </div>
          <div className="flex flex-col items-center gap-3">
            <label className="cursor-pointer">
              <input type="file" className="hidden" onChange={handleUpload} accept=".pdf,.doc,.docx,.txt" />
              <span className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {uploadedUrl ? 'Solicitation uploaded ✓' : 'Upload solicitation doc (optional)'}
              </span>
            </label>
            <Button onClick={handleAnalyze} disabled={uploading} className="gap-2">
              <FileSearch className="w-4 h-4" /> Analyze Solicitation
            </Button>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        </div>
      ) : (
        <>
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h3 className="font-heading text-base font-semibold text-foreground">Requirements Breakdown</h3>
            <AnalysisList icon={Check} color="text-primary" title="Required Qualifications" items={analysis.required_qualifications} />
            <AnalysisList icon={FileSearch} color="text-chart-4" title="Evaluation Criteria" items={analysis.evaluation_criteria} />
            <AnalysisList icon={PenLine} color="text-chart-5" title="Technical Requirements" items={analysis.technical_requirements} />
            {analysis.required_forms?.length > 0 && <AnalysisList icon={FileSearch} color="text-chart-2" title="Required Forms" items={analysis.required_forms} />}
            {analysis.page_limits && <p className="text-sm text-muted-foreground"><span className="font-medium text-foreground">Page limits:</span> {analysis.page_limits}</p>}
          </div>

          <div className="glass-card rounded-2xl p-5 space-y-3">
            <h3 className="font-heading text-base font-semibold text-foreground">Gap Analysis</h3>
            <AnalysisList icon={Check} color="text-primary" title="Your Strengths" items={analysis.gap_analysis?.strengths} />
            <AnalysisList icon={AlertTriangle} color="text-yellow-400" title="Weaknesses" items={analysis.gap_analysis?.weaknesses} />
            <AnalysisList icon={XCircle} color="text-destructive" title="Missing" items={analysis.gap_analysis?.missing} />
          </div>

          <div className="glass-card rounded-2xl p-5">
            <h3 className="font-heading text-base font-semibold text-foreground mb-2">Win Strategy</h3>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">{analysis.win_strategy}</p>
          </div>

          <Button onClick={onDraftProposal} className="w-full gap-2">
            <PenLine className="w-4 h-4" /> Draft Proposal
          </Button>
        </>
      )}
    </div>
  );
}

function AnalysisList({ icon: Icon, color, title, items }) {
  if (!items?.length) return null;
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1.5"><Icon className={`w-3.5 h-3.5 ${color}`} /> {title}</p>
      <ul className="space-y-1">
        {items.map((item, i) => <li key={i} className="text-sm text-foreground/90 pl-5 relative before:absolute before:left-0 before:top-2 before:w-1 before:h-1 before:rounded-full before:bg-muted-foreground/40">{item}</li>)}
      </ul>
    </div>
  );
}