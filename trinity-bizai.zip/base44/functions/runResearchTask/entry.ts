import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';
import { recordActivity } from '../../shared/activity.ts';

// Trinity's "browser-assisted" research: uses an LLM with live web search to
// gather real, cited information for a user question. This is the honest,
// available form of "open a browser and do the work" — full click-through
// automation of arbitrary sites is not available in the runtime.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { query, focus } = await req.json();
    const q = typeof query === 'string' ? query.trim() : '';
    if (q.length < 3 || q.length > 1000) {
      return Response.json({ error: 'Provide a research query between 3 and 1000 characters.' }, { status: 400 });
    }
    const focusLine = typeof focus === 'string' && focus.trim().slice(0, 300) ? `\nFocus: ${focus.trim()}` : '';

    const creditCheck = await consumeCredits(base44, CREDIT_COSTS.web_research);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits. Upgrade your plan to run web research.' }, { status: 402 });
    }

    const research = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are Trinity, a business research assistant. Research the following topic using live web sources and return structured, cited findings a business owner can act on.\n\nTopic: ${q}${focusLine}\n\nReturn a concise summary, key findings, recommended actions, and real sources (title + url). Prefer authoritative, recent sources. If information is sparse, say so honestly.`,
      add_context_from_internet: true,
      model: 'gemini_3_flash',
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          key_findings: { type: 'array', items: { type: 'string' } },
          recommended_actions: { type: 'array', items: { type: 'string' } },
          sources: {
            type: 'array',
            items: {
              type: 'object',
              properties: { title: { type: 'string' }, url: { type: 'string' } }
            }
          }
        }
      }
    });

    recordActivity(base44, user, 'search', `Web research: ${q.slice(0, 80)}`, '', '', { status: 'completed' });
    return Response.json({ success: true, research });
  } catch {
    return Response.json({ error: 'Research could not be completed. Try again later.' }, { status: 500 });
  }
}