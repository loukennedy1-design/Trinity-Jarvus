import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Check, Loader2, RefreshCw, Edit3, Eye } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function ProposalSection({ sectionName, sectionData, proposalId, opportunityId, onUpdated }) {
  const [editing, setEditing] = useState(false);
  const [content, setContent] = useState(sectionData?.content || '');
  const [regenerating, setRegenerating] = useState(false);
  const [saving, setSaving] = useState(false);

  const regenerate = async () => {
    setRegenerating(true);
    try {
      const res = await base44.functions.invoke('draftProposal', {
        opportunity_id: opportunityId,
        section_name: sectionName,
        regenerate: true
      });
      if (res.data?.sections?.[sectionName]) {
        setContent(res.data.sections[sectionName].content);
        onUpdated?.(res.data.sections);
      }
    } catch (e) { console.error(e); }
    setRegenerating(false);
  };

  const saveEdit = async () => {
    setSaving(true);
    try {
      await onUpdated?.({ [sectionName]: { ...sectionData, content, status: 'draft', approved: false } });
      setEditing(false);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const approve = async () => {
    await onUpdated?.({ [sectionName]: { ...sectionData, content, approved: true, status: 'approved' } });
  };

  const isApproved = sectionData?.approved;

  return (
    <div className={`glass-card rounded-2xl p-5 transition-all ${isApproved ? 'border-primary/30' : ''}`}>
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-heading text-sm font-semibold text-foreground">{sectionName}</h4>
        {isApproved ? (
          <span className="flex items-center gap-1 text-xs text-primary"><Check className="w-3.5 h-3.5" /> Approved</span>
        ) : (
          <span className="text-xs text-muted-foreground">Draft</span>
        )}
      </div>

      {editing ? (
        <div className="space-y-3">
          <Textarea value={content} onChange={e => setContent(e.target.value)} rows={10} className="bg-background/50 text-sm font-mono" />
          <div className="flex gap-2">
            <Button onClick={saveEdit} size="sm" disabled={saving}>{saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Save'}</Button>
            <Button onClick={() => { setContent(sectionData?.content || ''); setEditing(false); }} size="sm" variant="ghost">Cancel</Button>
          </div>
        </div>
      ) : (
        <div className="prose prose-invert prose-sm max-w-none text-foreground/90 mb-4">
          <ReactMarkdown>{content || sectionData?.content || '*Not yet generated.*'}</ReactMarkdown>
        </div>
      )}

      {!editing && (
        <div className="flex items-center gap-2 flex-wrap">
          {!isApproved && (
            <Button onClick={approve} size="sm" variant="outline" className="gap-1.5">
              <Check className="w-3.5 h-3.5" /> Approve
            </Button>
          )}
          <Button onClick={() => setEditing(true)} size="sm" variant="ghost" className="gap-1.5 text-muted-foreground">
            <Edit3 className="w-3.5 h-3.5" /> Edit
          </Button>
          <Button onClick={regenerate} size="sm" variant="ghost" disabled={regenerating} className="gap-1.5 text-muted-foreground">
            {regenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />} Regenerate
          </Button>
        </div>
      )}
    </div>
  );
}