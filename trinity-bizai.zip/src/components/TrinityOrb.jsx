import React from 'react';

export default function TrinityOrb({ size = 120, active = false }) {
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Outer glow */}
      <div
        className="absolute inset-0 rounded-full blur-2xl transition-opacity duration-700"
        style={{
          background: 'radial-gradient(circle, hsl(173 65% 51% / 0.4) 0%, transparent 70%)',
          opacity: active ? 0.8 : 0.4
        }}
      />
      {/* Rotating ring */}
      <div
        className="absolute inset-0 rounded-full border-2 border-primary/20 animate-orb-rotate"
        style={{ animationDuration: '12s' }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary" />
      </div>
      {/* Inner orb */}
      <div
        className={`relative rounded-full bg-gradient-to-br from-primary via-chart-2 to-chart-4 animate-orb-pulse ${active ? 'shadow-[0_0_40px_hsl(173_65%_51%_/_0.5)]' : ''}`}
        style={{ width: size * 0.55, height: size * 0.55 }}
      >
        <div className="absolute inset-2 rounded-full bg-gradient-to-tr from-transparent via-primary/20 to-white/10" />
        <div className="absolute top-1/4 left-1/4 w-1/4 h-1/4 rounded-full bg-white/30 blur-sm" />
      </div>
    </div>
  );
}