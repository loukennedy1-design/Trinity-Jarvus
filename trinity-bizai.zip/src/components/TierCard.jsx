import React from 'react';
import { Check, Sparkles } from 'lucide-react';

export default function TierCard({ tierKey, tier, current, onSelect }) {
  const isCurrent = current === tierKey;
  const isPro = tierKey === 'pro';

  return (
    <div className={`relative glass-card rounded-2xl p-6 flex flex-col transition-all duration-300 ${
      isPro ? 'border-primary/30 shadow-[0_0_30px_hsl(173_65%_51%_/_0.1)]' : ''
    } ${isCurrent ? 'ring-1 ring-primary' : ''}`}>
      {isPro && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold">
          Most Popular
        </div>
      )}
      <div className="mb-5">
        <h3 className="font-heading text-2xl font-semibold text-foreground">{tier.name}</h3>
        <div className="flex items-baseline gap-1 mt-2">
          <span className="font-heading text-4xl font-bold text-foreground">${tier.price}</span>
          <span className="text-muted-foreground text-sm">/month</span>
        </div>
        <p className="text-sm text-primary/70 mt-2">{tier.credits.toLocaleString()} credits / month</p>
      </div>

      <ul className="space-y-3 mb-6 flex-1">
        {tier.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2.5 text-sm">
            <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Check className="w-3 h-3 text-primary" />
            </div>
            <span className="text-foreground/80">{feature}</span>
          </li>
        ))}
      </ul>

      <button
        onClick={() => onSelect?.(tierKey)}
        disabled={isCurrent}
        className={`w-full py-3 rounded-xl font-medium text-sm transition-all ${
          isCurrent
            ? 'bg-muted text-muted-foreground cursor-default'
            : isPro
            ? 'bg-primary text-primary-foreground hover:opacity-90'
            : 'bg-accent/40 text-foreground hover:bg-accent/60 border border-border'
        }`}
      >
        {isCurrent ? 'Current Plan' : `Upgrade to ${tier.name}`}
      </button>
    </div>
  );
}