import React from 'react';
import { TrendingUp, Send, Trophy, DollarSign, Target, Briefcase } from 'lucide-react';
import BusinessPage from '@/components/business/BusinessPage';
import StatCard from '@/components/StatCard';
import useBusinessData, {metrics,money} from '@/components/business/useBusinessData';
import AnalyticsCharts from '@/components/business/AnalyticsCharts';
export default function PerformanceMetrics() {
  const {data,isLoading,error}=useBusinessData(); const m=metrics(data); const avg=m.won.length ? m.won.reduce((s,o)=>s+(o.contract_value || 0),0)/m.won.length : null;
  return <BusinessPage title="Performance Metrics" subtitle="Measure progress using your actual submissions, awards, and revenue." icon={TrendingUp} loading={isLoading} error={error}><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"><StatCard icon={Send} label="Total bids submitted" value={m.submitted} /><StatCard icon={Trophy} label="Win–loss record" value={`${m.won.length} : ${m.lost.length}`} sublabel={`Win rate: ${m.rate}`} /><StatCard icon={DollarSign} label="Recorded award revenue" value={money(m.revenue)} sublabel="Actual revenue entered for won bids" /><StatCard icon={Target} label="Average awarded deal" value={avg===null ? '—' : money(avg)} /><StatCard icon={Briefcase} label="Active pipeline" value={money(m.pipeline)} /><StatCard icon={TrendingUp} label="Pipeline coverage" value={m.revenue ? `${(m.pipeline/m.revenue).toFixed(1)}×` : '—'} sublabel="Pipeline value ÷ recorded revenue" /></div><AnalyticsCharts opportunities={data?.opportunities || []} /></BusinessPage>;
}