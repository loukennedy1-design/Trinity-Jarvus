import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useConversation } from '@/lib/ConversationContext';
import { Plus, Sparkles, Shield, Search, LogOut, MessageSquare } from 'lucide-react';
import NavigationGroups from '@/components/business/NavigationGroups';

export default function ChatSidebar({ isAdmin = false, onNavigate }) {
  const { conversations, createNew, selectConversation, conversation, loading } = useConversation();
  const location = useLocation();
  const navigate = useNavigate();
  const [creating, setCreating] = useState(false);

  const handleNewChat = async () => {
    setCreating(true);
    await createNew();
    setCreating(false);
    navigate('/');
    onNavigate?.();
  };

  const handleSelect = async (convId) => {
    await selectConversation(convId);
    onNavigate?.();
  };

  const handleLogout = async () => {
    await base44.auth.logout();
    window.location.href = '/login';
  };

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const getConvTitle = (conv) => {
    const firstUserMsg = conv.messages?.find((m) => m.role === 'user');
    if (firstUserMsg?.content) {
      const text = firstUserMsg.content.replace(/[#*`]/g, '').trim();
      return text.length > 40 ? text.slice(0, 40) + '…' : text;
    }
    const name = conv.metadata?.name;
    return name && name !== 'Trinity Chat' ? name : 'New Chat';
  };

  return (
    <div className="flex flex-col h-full">
      {/* Brand */}
      <div className="p-4 flex items-center gap-3 flex-shrink-0">
        <div className="relative w-9 h-9 flex-shrink-0">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary via-chart-2 to-chart-4 animate-orb-pulse" />
          <Sparkles className="absolute inset-0 m-auto w-4 h-4 text-primary-foreground" />
        </div>
        <div className="min-w-0">
          <h1 className="font-heading text-lg font-semibold text-foreground leading-none">Trinity AI</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Your business AI</p>
        </div>
      </div>

      {/* New Chat */}
      <div className="px-3 pb-2 flex-shrink-0">
        <button
          onClick={handleNewChat}
          disabled={creating}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-primary/15 text-primary border border-primary/20 hover:bg-primary/20 transition-all text-sm font-medium disabled:opacity-50"
        >
          <Plus className="w-4 h-4 flex-shrink-0" />
          New Chat
        </button>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin min-h-0">
      <NavigationGroups onNavigate={onNavigate} />
      {/* Conversation History */}
      <div className="px-3 py-2">
        <p className="text-xs text-muted-foreground/50 px-3 mb-1.5 uppercase tracking-wider font-medium">
          History
        </p>
        {loading && conversations.length === 0 ? (
          <div className="px-3 py-2 space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-7 rounded-lg bg-accent/30 animate-pulse" />
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <p className="text-xs text-muted-foreground/40 px-3 py-2">No conversations yet</p>
        ) : (
          <div className="space-y-0.5">
            {conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => handleSelect(conv.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all truncate flex items-center gap-2 ${
                  conversation?.id === conv.id
                    ? 'bg-accent/60 text-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent/30'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 flex-shrink-0 opacity-50" />
                <span className="truncate">{getConvTitle(conv)}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      </div>
      {/* Bottom Links */}
      <div className="border-t border-border p-3 space-y-0.5 flex-shrink-0">
        {isAdmin && (
          <>
            <SidebarLink
              to="/connector"
              icon={Search}
              label="Connector"
              active={isActive('/connector')}
              onNavigate={onNavigate}
            />
            <SidebarLink
              to="/admin"
              icon={Shield}
              label="Admin"
              active={isActive('/admin')}
              onNavigate={onNavigate}
            />
          </>
        )}
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-colors"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          Sign out
        </button>
      </div>
    </div>
  );
}

function SidebarLink({ to, icon: Icon, label, active, onNavigate }) {
  return (
    <Link
      to={to}
      onClick={onNavigate}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
        active
          ? 'bg-primary/15 text-primary border border-primary/20'
          : 'text-muted-foreground hover:text-foreground hover:bg-accent/50 border border-transparent'
      }`}
    >
      <Icon className="w-4 h-4 flex-shrink-0" />
      {label}
    </Link>
  );
}