import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Target, LineChart, Settings2, ArrowRight } from 'lucide-react';

const iconMap = {
  Sparkles,
  Target,
  LineChart,
  Settings2
};

export default function AgentCard({ agent, onStart }) {
  const Icon = iconMap[agent.icon] || Sparkles;
  const tierBadge = agent.tier === 'free' ? 'Free' : agent.tier === 'pro' ? 'Pro' : 'Enterprise';

  return (
    <div className="group glass-card rounded-2xl p-6 transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_30px_hsl(173_65%_51%_/_0.08)] flex flex-col">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${agent.gradient} flex items-center justify-center shadow-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
          agent.tier === 'free' ? 'bg-muted text-muted-foreground' : 'bg-primary/15 text-primary border border-primary/20'
        }`}>
          {tierBadge}
        </span>
      </div>

      <h3 className="font-heading text-lg font-semibold text-foreground mb-1">{agent.name}</h3>
      <p className="text-sm text-primary/80 mb-3">{agent.tagline}</p>
      <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">{agent.description}</p>

      <div className="flex flex-wrap gap-1.5 mb-5">
        {agent.capabilities.slice(0, 3).map((cap) => (
          <span key={cap} className="text-xs px-2 py-1 rounded-md bg-accent/40 text-accent-foreground/70 border border-border/50">
            {cap}
          </span>
        ))}
        {agent.capabilities.length > 3 && (
          <span className="text-xs px-2 py-1 rounded-md text-muted-foreground">
            +{agent.capabilities.length - 3} more
          </span>
        )}
      </div>

      <button
        onClick={() => onStart?.(agent)}
        className="w-full py-2.5 rounded-xl bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground border border-primary/20 hover:border-primary transition-all duration-200 text-sm font-medium flex items-center justify-center gap-2"
      >
        Start Conversation
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}