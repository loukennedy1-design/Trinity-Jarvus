import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';
import { recordActivity } from '../../shared/activity.ts';

import { getSAMCredential, getSAMKey, setSAMStatus } from '../../shared/samCredentials.ts';
import { requestSAM, samFailure } from '../../shared/samClient.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { keywords = '', limit = 25, validate_only = false } = body;
    if (typeof keywords !== 'string' || keywords.length > 200 || !Number.isInteger(limit) || limit < 1 || limit > 50) {
      return Response.json({error:'Use keywords up to 200 characters and a result limit between 1 and 50.'},{status:400});
    }

    // Load the caller's company profile (contains NAICS codes + API key).
    const profiles = await base44.entities.CompanyProfile.filter({created_by_id:user.id}, '-created_date', 1);
    if (!profiles.length) {
      return Response.json({ error: 'company_profile_required', message: 'Set up your company profile first.' }, { status: 400 });
    }
    const profile = profiles[0];

    const credential = await getSAMCredential(base44,user);
    if (!credential) return Response.json({error:'api_key_required',message:'Save your SAM.gov API key in Government Connections.'},{status:400});
    const apiKey = await getSAMKey(base44,user,credential);
    let response;
    try {
      response = await requestSAM(apiKey,{limit:validate_only?1:limit,title:validate_only?'':keywords.trim(),naics:validate_only?'':String((profile.naics_codes || [])[0] || '')});
    } catch {
      return Response.json({error:'sam_unavailable',message:'SAM.gov could not be reached. Please try again later.'},{status:502});
    }
    if (!response.ok) {
      if ([401,403].includes(response.status)) await setSAMStatus(base44,user,credential,'invalid');
      return Response.json({error:[401,403].includes(response.status)?'invalid_api_key':'sam_unavailable',message:samFailure(response.status)},{status:response.status===429?429:502});
    }
    await setSAMStatus(base44,user,credential,'connected');
    if (validate_only) return Response.json({valid:true});
    const samData = response.data;

    // Credit metering — charge only after the SAM.gov API call succeeds.
    const creditCheck = await consumeCredits(base44, CREDIT_COSTS.sam_search);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits. Upgrade your plan to search for contracts.' }, { status: 402 });
    }

    const rawOpps = samData.opportunitiesData || samData.opportunities || [];
    if (!rawOpps.length) {
      recordActivity(base44,user,'search','SAM.gov contract search completed with no matches.','CompanyProfile',profile.id,{count:0,status:'completed'});
      return Response.json({ success: true, opportunities: [], message: 'No opportunities found matching your profile. Try adjusting your NAICS codes or keywords.' });
    }

    // Normalize the raw SAM.gov results into a compact list for LLM categorization.
    const normalized = rawOpps.slice(0,limit).filter(o=>o.noticeId || o.id).map(o => ({
      noticeId: o.noticeId || o.id,
      title: String(o.title || '').slice(0,500),
      agency: o.fullParentPathName || o.agency || o.department || '',
      office: o.office || (o.fullParentPathName || '').split('.').pop() || '',
      naics: o.naicsCode ? [String(o.naicsCode)] : Array.isArray(o.naicsCodes) ? o.naicsCodes.map(String) : [],
      psc: o.classificationCode || o.psc || '',
      solicitationNumber: o.solicitationNumber || '',
      postedDate: (o.postedDate || '').slice(0,10),
      responseDate: o.responseDeadLine || o.reponseDeadLine || o.responseDate || o.responseDeadline || '',
      description: String(o.description || '').slice(0,500),
      link: o.uiLink || `https://sam.gov/opp/${encodeURIComponent(o.noticeId || o.id)}/view`
    }));

    // Use InvokeLLM to score and categorize each opportunity against the company profile.
    const categorizePrompt = `You are Trinity, an expert federal contracting advisor. Below is a company profile and a list of government contract opportunities from SAM.gov. For EACH opportunity, categorize it as one of:
- "strong": Directly aligned with the company's NAICS codes, capabilities, and past performance.
- "adjacent": Not an obvious fit, but with minor capability framing or a small pivot the company could credibly compete.
- "not_fit": Clearly outside the company's capabilities.

Also provide a match_score (0-100) and a one-sentence match_rationale explaining your reasoning in a way that helps the user understand the opportunity.

COMPANY PROFILE:
- Name: ${profile.business_name}
- NAICS: ${(profile.naics_codes || []).join(', ')}
- Capabilities: ${profile.capabilities_narrative || 'N/A'}
- Certifications: ${(profile.certifications || []).join(', ')}
- Past Performance: ${JSON.stringify(profile.past_performance || [])}
- Differentiators: ${profile.differentiators || 'N/A'}

OPPORTUNITIES TO CATEGORIZE:
${JSON.stringify(normalized)}

Return a JSON object with key "results" — an array of objects with fields: noticeId, match_category, match_score, match_rationale.`;

    const categorized = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: categorizePrompt,
      response_json_schema: {
        type: "object",
        properties: {
          results: {
            type: "array",
            items: {
              type: "object",
              properties: {
                noticeId: { type: "string" },
                match_category: { type: "string", enum: ["strong", "adjacent", "not_fit"] },
                match_score: { type: "number" },
                match_rationale: { type: "string" }
              }
            }
          }
        }
      }
    });

    const matchMap = new Map((categorized.results || []).map(r => [r.noticeId, r]));

    // Keep previously discovered bids: searches must not erase pipeline and proposal history.
    const previous = await base44.entities.ContractOpportunity.filter({created_by_id:user.id,sam_notice_id:{$in:normalized.map(o=>o.noticeId)}}, '-created_date', 100);
    const existing = new Map(previous.map(o=>[o.sam_notice_id,o]));

    // Build and save opportunity records, sorted by match score descending.
    const enriched = normalized
      .map(o => {
        const m = matchMap.get(o.noticeId) || { match_category: 'not_fit', match_score: 0, match_rationale: 'Not analyzed.' };
        return { ...o, ...m };
      })
      .sort((a, b) => b.match_score - a.match_score);

    const toCreate = enriched.map(o => ({
      sam_notice_id: o.noticeId,
      title: o.title,
      agency: o.agency,
      office: o.office,
      naics_codes: o.naics || [],
      psc: o.psc || '',
      posted_date: o.postedDate || null,
      response_deadline: o.responseDate && !Number.isNaN(Date.parse(o.responseDate)) ? new Date(o.responseDate).toISOString() : null,
      solicitation_number: o.solicitationNumber || '',
      solicitation_url: o.link || '',
      description: o.description || '',
      match_score: o.match_score || 0,
      match_category: o.match_category || 'not_fit',
      match_rationale: o.match_rationale || '',
      status: 'discovered'
    }));

    const newRecords = toCreate.filter(o=>!existing.has(o.sam_notice_id));
    const fresh = newRecords.length ? await base44.entities.ContractOpportunity.bulkCreate(newRecords) : [];
    const saved = [...fresh,...toCreate.filter(o=>existing.has(o.sam_notice_id)).map(o=>existing.get(o.sam_notice_id))];
    recordActivity(base44,user,'search',`SAM.gov contract search completed: ${saved.length} matching opportunities.`,'CompanyProfile',profile.id,{count:saved.length,status:'completed'});

    return Response.json({
      success: true,
      opportunities: saved,
      count: saved.length
    });
  } catch (error) {
    return Response.json({error:'search_failed',message:'Contract search could not be completed. Check your connection and try again.'},{status:500});
  }
}