import { encryptCredential, decryptCredential } from './credentialCrypto.ts';

// Trinity signs in to Axis Business Suite's MCP server with the user's own Axis account
// (OAuth 2.1 authorization code + PKCE, dynamic client registration — no shared secrets).
export const AXIS_MCP_URL = 'https://axisbusinesssuite.base44.app/api/mcp';
const AUTH_BASE = 'https://app.base44.com/oauth';
const SCOPE = 'app:mcp offline';
const PURPOSE = 'axis';

const b64url = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

export async function getAxisLink(base44, user) {
  const rows = await base44.asServiceRole.entities.PartnerConnection.filter({ owner_id: user.id, partner: 'axis' }, '-created_date', 1);
  return rows[0] || null;
}

async function tokenRequest(fields: Record<string, string>) {
  const res = await fetch(`${AUTH_BASE}/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body: new URLSearchParams({ ...fields, resource: AXIS_MCP_URL }).toString(),
  });
  if (!res.ok) throw new Error('token_exchange_failed');
  return res.json();
}

async function saveTokens(base44, user, link, tokens, extra = {}) {
  const update = {
    ...extra,
    status: 'connected',
    access_token: await encryptCredential(tokens.access_token, user.id, PURPOSE),
    expires_at: tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000).toISOString() : null,
  };
  if (tokens.refresh_token) update.refresh_token = await encryptCredential(tokens.refresh_token, user.id, PURPOSE);
  await base44.asServiceRole.entities.PartnerConnection.update(link.id, update);
}

export async function startAxisLink(base44, user, redirectUri: string) {
  const reg = await fetch(`${AUTH_BASE}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_name: 'Trinity Business Intelligence',
      redirect_uris: [redirectUri],
      grant_types: ['authorization_code', 'refresh_token'],
      response_types: ['code'],
      token_endpoint_auth_method: 'none',
      scope: SCOPE,
    }),
  });
  if (!reg.ok) throw new Error('registration_failed');
  const { client_id } = await reg.json();

  const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
  const challenge = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));
  const state = b64url(crypto.getRandomValues(new Uint8Array(16)));

  const existing = await getAxisLink(base44, user);
  const pending = {
    client_id,
    oauth_state: state,
    code_verifier: await encryptCredential(verifier, user.id, PURPOSE),
    redirect_uri: redirectUri,
    status: existing?.status === 'connected' ? 'connected' : 'pending',
  };
  if (existing) await base44.asServiceRole.entities.PartnerConnection.update(existing.id, pending);
  else await base44.asServiceRole.entities.PartnerConnection.create({ owner_id: user.id, partner: 'axis', ...pending });

  const url = new URL(`${AUTH_BASE}/authorize`);
  url.search = new URLSearchParams({
    response_type: 'code',
    client_id,
    redirect_uri: redirectUri,
    code_challenge: challenge,
    code_challenge_method: 'S256',
    state,
    scope: SCOPE,
    resource: AXIS_MCP_URL,
  }).toString();
  return url.toString();
}

export async function completeAxisLink(base44, user, code: string, state: string) {
  const link = await getAxisLink(base44, user);
  if (!link?.oauth_state || link.oauth_state !== state) throw new Error('state_mismatch');
  const verifier = await decryptCredential(link.code_verifier, user.id, PURPOSE);
  const tokens = await tokenRequest({
    grant_type: 'authorization_code',
    code,
    redirect_uri: link.redirect_uri,
    client_id: link.client_id,
    code_verifier: verifier,
  });
  await saveTokens(base44, user, link, tokens, { oauth_state: '', code_verifier: '', connected_at: new Date().toISOString() });
}

export async function markAxisLinkError(base44, link) {
  await base44.asServiceRole.entities.PartnerConnection.update(link.id, { status: 'error' });
}

// Returns a valid Axis access token for this user, refreshing it when it is about to expire.
export async function getAxisAccessToken(base44, user) {
  const link = await getAxisLink(base44, user);
  if (!link?.access_token || link.status !== 'connected') return { link, token: null };
  const fresh = !link.expires_at || Date.parse(link.expires_at) - 60000 > Date.now();
  if (fresh) return { link, token: await decryptCredential(link.access_token, user.id, PURPOSE) };
  if (!link.refresh_token) { await markAxisLinkError(base44, link); return { link, token: null }; }
  try {
    const tokens = await tokenRequest({
      grant_type: 'refresh_token',
      refresh_token: await decryptCredential(link.refresh_token, user.id, PURPOSE),
      client_id: link.client_id,
    });
    await saveTokens(base44, user, link, tokens);
    return { link, token: tokens.access_token };
  } catch {
    await markAxisLinkError(base44, link);
    return { link, token: null };
  }
}