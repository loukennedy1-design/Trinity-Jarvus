import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import TierCard from '@/components/TierCard';
import TrinityOrb from '@/components/TrinityOrb';
import { TIER_INFO } from '@/lib/agentCatalog';
import { Zap, Check, Loader2 } from 'lucide-react';

export default function Subscription() {
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null);
  const [paymentMessage, setPaymentMessage] = useState(null);

  useEffect(() => {
    loadSubscription();
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('checkout') === 'success') {
      const tier = params.get('tier');
      const orderId = params.get('transactionId') || params.get('orderId') || params.get('order_id');
      window.history.replaceState({}, '', '/subscription');
      if (tier) {
        base44.functions.invoke('fulfillCheckout', { tier, order_id: orderId })
          .then(() => loadSubscription())
          .catch((err) => console.error('Fulfillment failed:', err));
      }
    }
  }, []);

  const loadSubscription = async () => {
    try {
      const subs = await base44.entities.Subscription.list('-created_date', 1);
      if (subs.length) setSubscription(subs[0]);
    } catch (err) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const currentTier = subscription?.tier || 'free';
  const creditsUsed = subscription?.credits_used || 0;
  const creditsLimit = subscription?.credits_limit || TIER_INFO[currentTier].credits;
  const usagePercent = Math.min(100, (creditsUsed / creditsLimit) * 100);

  const handleSelectTier = async (tierKey) => {
    if (tierKey === currentTier || tierKey === 'free') return;
    setUpdating(tierKey);
    setPaymentMessage(null);
    try {
      const redirectUrl = window.location.origin + '/subscription?checkout=success&tier=' + tierKey;
      const res = await base44.functions.invoke('createCheckout', { tier: tierKey, redirect_url: redirectUrl });
      const data = res.data;
      if (data.configured === false) {
        setPaymentMessage(data.message);
      } else if (data.checkout_url) {
        window.location.href = data.checkout_url;
      } else if (data.error) {
        setPaymentMessage(data.error);
      }
    } catch (err) {
      console.error('Checkout failed:', err);
      setPaymentMessage('Checkout failed. Please try again.');
    } finally {
      setUpdating(null);
    }
  };

  return (
    <div className="aurora-bg h-full overflow-y-auto scrollbar-thin px-6 md:px-12 py-8 md:py-12">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <TrinityOrb size={60} />
          </div>
          <h1 className="font-heading text-3xl font-semibold text-foreground mb-2">Subscription</h1>
          <p className="text-muted-foreground">Choose the plan that powers your business intelligence.</p>
        </div>

        {paymentMessage && (
          <div className="glass-card rounded-2xl p-4 mb-6 border-primary/30">
            <p className="text-sm text-foreground/80 text-center">{paymentMessage}</p>
          </div>
        )}

        {/* Current Plan */}
        {!loading && (
          <div className="glass-card rounded-2xl p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Current Plan</p>
                <h2 className="font-heading text-2xl font-semibold text-foreground">
                  {TIER_INFO[currentTier].name}
                </h2>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Renews</p>
                <p className="text-sm text-foreground">
                  {subscription?.renews_at
                    ? new Date(subscription.renews_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                    : '—'}
                </p>
              </div>
            </div>

            {/* Usage Bar */}
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-primary" />
                  Credits Used
                </span>
                <span className="text-sm text-foreground font-medium">
                  {creditsUsed.toLocaleString()} / {creditsLimit.toLocaleString()}
                </span>
              </div>
              <div className="h-2 rounded-full bg-accent/40 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-primary to-chart-2 transition-all duration-500"
                  style={{ width: `${usagePercent}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Tier Cards */}
        {loading ? (
          <div className="flex justify-center py-12">
            <TrinityOrb size={60} />
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-5 pt-4">
            {Object.entries(TIER_INFO).map(([key, tier]) => (
              <div key={key} className="relative">
                <TierCard
                  tierKey={key}
                  tier={tier}
                  current={currentTier}
                  onSelect={handleSelectTier}
                />
                {updating === key && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm rounded-2xl">
                    <Loader2 className="w-6 h-6 text-primary animate-spin" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Feature Comparison */}
        <div className="mt-12 glass-card rounded-2xl p-6">
          <h3 className="font-heading text-lg font-semibold text-foreground mb-4">All Plans Include</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {[
              'Trinity Core AI chat',
              'Wealth of Nations economic principles',
              'Knowledge base training',
              'Real-time agent intelligence',
              'Mobile-optimized interface',
              'Secure data encryption'
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-2.5 text-sm">
                <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                <span className="text-foreground/80">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}