import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { TIER_INFO } from '@/lib/agentCatalog';
import TrinityOrb from '@/components/TrinityOrb';
import {
  Zap, MessageSquare, BookOpen, Database, Link2, Brain,
  Calendar, TrendingUp, Check, Loader2, Clock, Sparkles
} from 'lucide-react';

export default function Usage() {
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [knowledgeCount, setKnowledgeCount] = useState(0);
  const [trainingJobs, setTrainingJobs] = useState([]);
  const [conversationCount, setConversationCount] = useState(0);
  const [connections, setConnections] = useState([]);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      const [subs, knowledge, jobs, convs, conns] = await Promise.all([
        base44.entities.Subscription.list('-created_date', 1),
        base44.entities.KnowledgeBase.list('-created_date', 100),
        base44.entities.TrainingJob.list('-created_date', 20),
        base44.agents.listConversations({ q: { agent_name: 'trinity_core' }, sort: '-created_date', limit: 100 }),
        base44.entities.Connection.list('-created_date', 50),
      ]);

      if (subs.length) setSubscription(subs[0]);
      setKnowledgeCount(knowledge.length);
      setTrainingJobs(jobs);
      setConversationCount(convs?.length || 0);
      setConnections(conns);
    } catch (err) {
      console.error('Failed to load usage data:', err);
    } finally {
      setLoading(false);
    }
  };

  const currentTier = subscription?.tier || 'free';
  const tierInfo = TIER_INFO[currentTier];
  const creditsUsed = subscription?.credits_used || 0;
  const creditsLimit = subscription?.credits_limit || tierInfo.credits;
  const creditsPercent = Math.min(100, (creditsUsed / creditsLimit) * 100);
  const creditsRemaining = Math.max(0, creditsLimit - creditsUsed);

  const messagesUsed = subscription?.messages_this_period || 0;
  const messagesLimit = subscription?.messages_limit ?? tierInfo.messages;
  const messagesUnlimited = messagesLimit === null;
  const messagesPercent = messagesUnlimited ? 0 : Math.min(100, (messagesUsed / messagesLimit) * 100);

  const activeConnections = connections.filter((c) => c.status === 'connected').length;
  const completedJobs = trainingJobs.filter((j) => j.status === 'completed').length;
  const processingJobs = trainingJobs.filter((j) => j.status === 'processing' || j.status === 'queued').length;

  if (loading) {
    return (
      <div className="aurora-bg h-full flex items-center justify-center">
        <TrinityOrb size={80} active />
      </div>
    );
  }

  return (
    <div className="aurora-bg h-full overflow-y-auto scrollbar-thin px-6 md:px-12 py-8 md:py-12">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <TrinityOrb size={60} />
          </div>
          <h1 className="font-heading text-3xl font-semibold text-foreground mb-2">Usage Dashboard</h1>
          <p className="text-muted-foreground">Track your Trinity AI activity and resource consumption.</p>
        </div>

        {/* Plan + Credits + Messages */}
        <div className="grid md:grid-cols-3 gap-5 mb-8">
          {/* Plan Card */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-primary" />
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Current Plan</p>
            </div>
            <h2 className="font-heading text-2xl font-semibold text-foreground mb-1">{tierInfo.name}</h2>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-3">
              <Calendar className="w-3.5 h-3.5" />
              <span>
                Renews{' '}
                {subscription?.renews_at
                  ? new Date(subscription.renews_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                  : '—'}
              </span>
            </div>
          </div>

          {/* Credits Card */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-primary" />
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Credits</p>
            </div>
            <div className="flex items-baseline gap-1.5 mb-3">
              <span className="font-heading text-2xl font-semibold text-foreground">{creditsUsed.toLocaleString()}</span>
              <span className="text-sm text-muted-foreground">/ {creditsLimit.toLocaleString()} used</span>
            </div>
            <div className="h-2 rounded-full bg-accent/40 overflow-hidden mb-2">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary to-chart-2 transition-all duration-500"
                style={{ width: `${creditsPercent}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">{creditsRemaining.toLocaleString()} remaining</p>
          </div>

          {/* Messages Card */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare className="w-4 h-4 text-primary" />
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Chat Messages</p>
            </div>
            {messagesUnlimited ? (
              <div className="flex items-baseline gap-1.5 mb-3">
                <span className="font-heading text-2xl font-semibold text-foreground">Unlimited</span>
              </div>
            ) : (
              <>
                <div className="flex items-baseline gap-1.5 mb-3">
                  <span className="font-heading text-2xl font-semibold text-foreground">{messagesUsed}</span>
                  <span className="text-sm text-muted-foreground">/ {messagesLimit} this period</span>
                </div>
                <div className="h-2 rounded-full bg-accent/40 overflow-hidden mb-2">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-chart-4 to-primary transition-all duration-500"
                    style={{ width: `${messagesPercent}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground">{Math.max(0, messagesLimit - messagesUsed)} remaining</p>
              </>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={BookOpen} label="Knowledge Entries" value={knowledgeCount} accent="primary" />
          <StatCard icon={Brain} label="Training Jobs" value={trainingJobs.length} sublabel={`${completedJobs} completed`} accent="chart-2" />
          <StatCard icon={MessageSquare} label="Conversations" value={conversationCount} accent="chart-4" />
          <StatCard icon={Link2} label="Connections" value={connections.length} sublabel={`${activeConnections} active`} accent="chart-5" />
        </div>

        {/* Recent Training Jobs */}
        <div className="glass-card rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-lg font-semibold text-foreground flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              Recent Training Jobs
            </h3>
            {processingJobs > 0 && (
              <span className="flex items-center gap-1.5 text-xs text-primary">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                {processingJobs} in progress
              </span>
            )}
          </div>
          {trainingJobs.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No training jobs yet. Upload documents in chat to train Trinity.</p>
          ) : (
            <div className="space-y-2">
              {trainingJobs.slice(0, 8).map((job) => (
                <div key={job.id} className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-accent/30">
                  <div className="flex items-center gap-3 min-w-0">
                    <StatusBadge status={job.status} />
                    <div className="min-w-0">
                      <p className="text-sm text-foreground truncate">{job.agent_name || job.agent_slug}</p>
                      <p className="text-xs text-muted-foreground">
                        {job.document_count} doc{job.document_count !== 1 ? 's' : ''}
                        {job.created_date && ` · ${new Date(job.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`}
                      </p>
                    </div>
                  </div>
                  {job.knowledge_entries_created > 0 && (
                    <span className="text-xs text-primary flex items-center gap-1 flex-shrink-0">
                      <Database className="w-3 h-3" />
                      {job.knowledge_entries_created} entries
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Auto-Learning Status */}
        <div className="glass-card rounded-2xl p-6">
          <h3 className="font-heading text-lg font-semibold text-foreground flex items-center gap-2 mb-3">
            <TrendingUp className="w-5 h-5 text-primary" />
            Auto-Learning Automation
          </h3>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
              <Clock className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-foreground font-medium">Trinity Auto-Learning — Active</p>
              <p className="text-sm text-muted-foreground mt-1">
                Trinity automatically gathers knowledge from Claude, GPT-5, and Gemini every 6 hours on a rotating
                schedule of {24} business topics. Each run synthesizes multiple AI perspectives into a permanent
                knowledge base entry — so Trinity gets smarter even while you sleep.
              </p>
              <div className="flex items-center gap-2 mt-3">
                <span className="flex items-center gap-1.5 text-xs text-chart-5">
                  <Check className="w-3.5 h-3.5" />
                  Runs every 6 hours
                </span>
                <span className="text-muted-foreground/30">·</span>
                <span className="flex items-center gap-1.5 text-xs text-chart-5">
                  <Check className="w-3.5 h-3.5" />
                  {knowledgeCount} entries accumulated
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sublabel, accent }) {
  const colorMap = {
    primary: 'text-primary',
    'chart-2': 'text-chart-2',
    'chart-4': 'text-chart-4',
    'chart-5': 'text-chart-5',
  };
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 ${colorMap[accent] || 'text-primary'}`} />
        <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">{label}</p>
      </div>
      <p className="font-heading text-2xl font-semibold text-foreground">{value.toLocaleString()}</p>
      {sublabel && <p className="text-xs text-muted-foreground mt-0.5">{sublabel}</p>}
    </div>
  );
}

function StatusBadge({ status }) {
  const styles = {
    completed: 'bg-chart-5/15 text-chart-5',
    processing: 'bg-primary/15 text-primary',
    queued: 'bg-accent text-muted-foreground',
    failed: 'bg-destructive/15 text-destructive',
  };
  const icons = {
    completed: <Check className="w-3 h-3" />,
    processing: <Loader2 className="w-3 h-3 animate-spin" />,
    queued: <Clock className="w-3 h-3" />,
    failed: <span className="w-2 h-2 rounded-full bg-current" />,
  };
  return (
    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium flex-shrink-0 ${styles[status] || styles.queued}`}>
      {icons[status] || icons.queued}
      {status}
    </span>
  );
}