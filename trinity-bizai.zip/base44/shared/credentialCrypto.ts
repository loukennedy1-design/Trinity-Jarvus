import { secrets } from 'base44:runtime';
const encoder = new TextEncoder();
const encode = bytes => btoa(String.fromCharCode(...bytes));
const decode = value => Uint8Array.from(atob(value), char => char.charCodeAt(0));
async function encryptionKey() {
  const secret = secrets.get('SAM_CREDENTIAL_ENCRYPTION_KEY');
  if (!secret || secret.length < 32) throw new Error('Connection encryption is not configured correctly.');
  const hash = await crypto.subtle.digest('SHA-256', encoder.encode(secret));
  return crypto.subtle.importKey('raw', hash, {name:'AES-GCM'}, false, ['encrypt','decrypt']);
}
export async function encryptCredential(value, ownerId, purpose = 'samgov') {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode(`${purpose}:${ownerId}`)}, await encryptionKey(), encoder.encode(value));
  return `v1.${encode(iv)}.${encode(new Uint8Array(encrypted))}`;
}
export async function decryptCredential(value, ownerId, purpose = 'samgov') {
  const [version, iv, data] = value.split('.');
  if (version !== 'v1' || !iv || !data) throw new Error('Reconnect your SAM.gov account to restore access.');
  try {
    const decrypted = await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(iv),additionalData:encoder.encode(`${purpose}:${ownerId}`)}, await encryptionKey(), decode(data));
    return new TextDecoder().decode(decrypted);
  } catch {
    throw new Error('Your saved SAM.gov key could not be unlocked. Reconnect your account.');
  }
}