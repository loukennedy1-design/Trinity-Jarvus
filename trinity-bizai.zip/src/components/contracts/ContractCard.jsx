import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building, Calendar, ExternalLink, ArrowRight } from 'lucide-react';

const CATEGORY_STYLES = {
  strong: { label: 'Strong Match', cls: 'bg-primary/15 text-primary border-primary/30' },
  adjacent: { label: 'Adjacent', cls: 'bg-chart-4/15 text-chart-4 border-chart-4/30' },
  not_fit: { label: 'Not a Fit', cls: 'bg-muted/30 text-muted-foreground border-border' }
};

export default function ContractCard({ opportunity, onSelect, onAnalyze }) {
  const cat = CATEGORY_STYLES[opportunity.match_category] || CATEGORY_STYLES.not_fit;
  const deadline = opportunity.response_deadline ? new Date(opportunity.response_deadline).toLocaleDateString() : 'N/A';
  const daysLeft = opportunity.response_deadline
    ? Math.ceil((new Date(opportunity.response_deadline) - new Date()) / 86400000)
    : null;

  return (
    <div className="glass-card rounded-2xl p-5 hover:border-primary/30 transition-all duration-200">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <Badge variant="outline" className={cat.cls}>{cat.label}</Badge>
            <span className="text-xs text-muted-foreground">{opportunity.match_score}% match</span>
          </div>
          <h3 className="font-heading text-base font-semibold text-foreground leading-snug">{opportunity.title}</h3>
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
        <span className="flex items-center gap-1"><Building className="w-3.5 h-3.5" /> {opportunity.agency || 'N/A'}</span>
        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {deadline}{daysLeft !== null && daysLeft >= 0 ? ` (${daysLeft}d left)` : ''}</span>
      </div>

      {opportunity.match_rationale && (
        <p className="text-sm text-muted-foreground/80 mb-4 line-clamp-2 italic">"{opportunity.match_rationale}"</p>
      )}

      <div className="flex items-center gap-2">
        <Button onClick={() => onSelect(opportunity)} size="sm" variant="outline" className="gap-1">
          View Details <ArrowRight className="w-3.5 h-3.5" />
        </Button>
        {opportunity.solicitation_url && (
          <a href={opportunity.solicitation_url} target="_blank" rel="noreferrer">
            <Button size="sm" variant="ghost" className="gap-1 text-muted-foreground">
              SAM.gov <ExternalLink className="w-3 h-3" />
            </Button>
          </a>
        )}
        {opportunity.status === 'analyzed' ? (
          <Badge className="ml-auto bg-primary/10 text-primary border border-primary/20 text-xs">Analyzed</Badge>
        ) : (
          <Button onClick={() => onAnalyze(opportunity)} size="sm" className="ml-auto">Analyze</Button>
        )}
      </div>
    </div>
  );
}