import { encryptCredential, decryptCredential } from './credentialCrypto.ts';
export async function getSAMCredential(base44, user) {
  if (!user?.id) throw new Error('Unauthorized');
  // Vault access is server-only and always scoped to the authenticated caller.
  const rows = await base44.asServiceRole.entities.GovernmentCredential.filter({owner_id:user.id,service:'samgov'}, '-created_date', 1);
  return rows[0] || null;
}
export function publicSAMStatus(row) {
  return {configured:!!row,status:row?.status || 'not_set',validated_at:row?.validated_at || null};
}
export async function saveSAMCredential(base44, user, value) {
  const existing = await getSAMCredential(base44, user);
  const data = {owner_id:user.id,service:'samgov',encrypted_key:await encryptCredential(value,user.id),status:'saved',validated_at:null};
  return existing ? await base44.asServiceRole.entities.GovernmentCredential.update(existing.id,data) : await base44.asServiceRole.entities.GovernmentCredential.create(data);
}
export async function getSAMKey(base44, user, credential) {
  const row = credential || await getSAMCredential(base44,user);
  if (!row) return null;
  if (row.owner_id !== user.id || row.service !== 'samgov') throw new Error('Unauthorized');
  return decryptCredential(row.encrypted_key,user.id);
}
export async function setSAMStatus(base44, user, row, status) {
  if (row.owner_id !== user.id || row.service !== 'samgov') throw new Error('Unauthorized');
  const updated = await base44.asServiceRole.entities.GovernmentCredential.update(row.id,{status,validated_at:new Date().toISOString()});
  await syncSAMProfileStatus(base44,user,status);
  return updated;
}
export async function syncSAMProfileStatus(base44,user,status) {
  const profiles = await base44.entities.CompanyProfile.filter({created_by_id:user.id},'-created_date',1);
  if (profiles[0]) await base44.entities.CompanyProfile.update(profiles[0].id,{sam_api_status:status==='connected'?'connected':status==='invalid'?'invalid':'not_set'});
}