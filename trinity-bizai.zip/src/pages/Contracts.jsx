import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import CompanyProfileForm from '@/components/contracts/CompanyProfileForm';
import ContractSearchResults from '@/components/contracts/ContractSearchResults';
import OpportunityAnalysis from '@/components/contracts/OpportunityAnalysis';
import ProposalBuilder from '@/components/contracts/ProposalBuilder';
import SubmissionGuide from '@/components/contracts/SubmissionGuide';
import TrinityOrb from '@/components/TrinityOrb';
import { Briefcase, Search, FileText, PenLine, Send } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Contracts() {
  const [view, setView] = useState('profile');
  const [profile, setProfile] = useState(null);
  const [opportunities, setOpportunities] = useState([]);
  const [selectedOpp, setSelectedOpp] = useState(null);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [loadingProfile, setLoadingProfile] = useState(true);

  useEffect(() => { loadProfile(); }, []);

  const loadProfile = async () => {
    try {
      const user = await base44.auth.me();
      const list = await base44.entities.CompanyProfile.filter({created_by_id:user.id}, '-created_date', 1);
      setProfile(list[0] || null);
      if (list[0]?.business_name) {
        setView('search');
      }
    } catch (e) { console.error(e); }
    finally { setLoadingProfile(false); }
  };

  const loadOpportunities = async () => {
    try {
      const list = await base44.entities.ContractOpportunity.list('-match_score', 100);
      setOpportunities(list);
    } catch (e) { console.error(e); }
  };

  useEffect(() => { if (view === 'search') loadOpportunities(); }, [view]);

  const handleSearch = async (keywords) => {
    setSearching(true);
    setSearchError('');
    try {
      const res = await base44.functions.invoke('searchSAMGov', { keywords });
      if (res.data?.error) throw new Error(res.data.message || res.data.error);
      if (res.data?.opportunities) {
        setOpportunities(res.data.opportunities);
      }
    } catch (e) { setSearchError(e.response?.data?.message || e.response?.data?.error || e.message); }
    finally { setSearching(false); }
  };

  const handleSelectOpp = async (opp) => {
    const fresh = await base44.entities.ContractOpportunity.get(opp.id);
    setSelectedOpp(fresh);
    setView('opportunity');
  };

  const handleAnalyze = async (opp) => {
    setSelectedOpp(opp);
    setView('opportunity');
  };

  const handleDraftProposal = async () => {
    const proposals = await base44.entities.Proposal.filter({ opportunity_id: selectedOpp.id }, '-created_date', 1);
    setSelectedProposal(proposals[0] || null);
    setView('proposal');
  };

  const handleSubmissionGuide = async () => {
    if (!selectedProposal) {
      const proposals = await base44.entities.Proposal.filter({ opportunity_id: selectedOpp.id }, '-created_date', 1);
      setSelectedProposal(proposals[0] || null);
    }
    setView('submission');
  };

  if (loadingProfile) {
    return <div className="aurora-bg h-full flex items-center justify-center"><TrinityOrb size={80} /></div>;
  }

  return (
    <div className="aurora-bg h-full overflow-y-auto scrollbar-thin">
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-6 md:py-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Briefcase className="w-6 h-6 text-primary" />
          <div>
            <h1 className="font-heading text-2xl font-semibold text-foreground">Government Contracts</h1>
            <p className="text-sm text-muted-foreground">Find, analyze, and bid on SAM.gov opportunities</p>
          </div>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-1 mb-8 overflow-x-auto scrollbar-thin pb-1">
          {[
            { key: 'profile', label: 'Profile', icon: FileText },
            { key: 'search', label: 'Search', icon: Search },
            { key: 'opportunity', label: 'Analyze', icon: FileText },
            { key: 'proposal', label: 'Proposal', icon: PenLine },
            { key: 'submission', label: 'Submit', icon: Send }
          ].map((s, i) => {
            const active = view === s.key;
            const completed = ['profile', 'search', 'opportunity', 'proposal', 'submission'].indexOf(view) > i;
            return (
              <React.Fragment key={s.key}>
                <button onClick={() => s.key === 'profile' || s.key === 'search' ? setView(s.key) : null} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex-shrink-0 ${active ? 'bg-primary/15 text-primary border border-primary/20' : completed ? 'text-muted-foreground' : 'text-muted-foreground/40'}`}>
                  <s.icon className="w-3.5 h-3.5" /> {s.label}
                </button>
                {i < 4 && <div className="w-4 h-px bg-border flex-shrink-0" />}
              </React.Fragment>
            );
          })}
        </div>

        {view === 'profile' && <CompanyProfileForm onSaved={loadProfile} />}

        {view === 'search' && <><p className="text-sm text-muted-foreground mb-4">Searches use your first NAICS code and optional title keywords. <Link to="/government-connections" className="text-primary underline">Manage SAM.gov connection</Link></p>{searchError && <p role="alert" className="text-destructive text-sm mb-4">{searchError}</p>}<ContractSearchResults opportunities={opportunities} onSearch={handleSearch} onSelect={handleSelectOpp} onAnalyze={handleAnalyze} searching={searching} /></>}

        {view === 'opportunity' && selectedOpp && (
          <OpportunityAnalysis opportunity={selectedOpp} onBack={() => { loadOpportunities(); setView('search'); }} onDraftProposal={handleDraftProposal} />
        )}

        {view === 'proposal' && selectedOpp && (
          <ProposalBuilder opportunity={selectedOpp} onBack={() => setView('opportunity')} onSubmissionGuide={handleSubmissionGuide} />
        )}

        {view === 'submission' && selectedOpp && (
          <SubmissionGuide opportunity={selectedOpp} proposal={selectedProposal} onBack={() => setView('proposal')} />
        )}
      </div>
    </div>
  );
}