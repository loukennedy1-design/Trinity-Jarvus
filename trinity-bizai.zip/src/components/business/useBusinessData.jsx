import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
export async function readRecords(name, filter = {}, sort = '-created_date') {
  const records = [];
  for (let skip = 0; ; skip += 100) {
    const batch = await base44.entities[name].filter(filter, sort, 100, skip);
    records.push(...batch);
    if (batch.length < 100) break;
  }
  return records;
}
export async function readOwned(name) {
  const user = await base44.auth.me();
  return readRecords(name, name === 'ActivityLog' ? {owner_id:user.id} : {created_by_id:user.id});
}
export default function useBusinessData() {
  return useQuery({ queryKey: ['business-data'], queryFn: async () => {
    const [opportunities, proposals, profiles, knowledge, activity] = await Promise.all(['ContractOpportunity','Proposal','CompanyProfile','KnowledgeBase','ActivityLog'].map(readOwned));
    return { opportunities, proposals, profile: profiles[0], knowledge, activity };
  }});
}
export const money = value => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value || 0);
export const metrics = data => {
  const o = data?.opportunities || [], p = data?.proposals || [];
  const won = o.filter(x => x.outcome === 'won'), lost = o.filter(x => x.outcome === 'lost');
  const active = o.filter(x => !['submitted','archived'].includes(x.status) && (!x.outcome || x.outcome === 'pending'));
  return { active, won, lost, submitted: new Set([...p.filter(x => x.overall_status === 'submitted').map(x=>x.opportunity_id),...o.filter(x=>x.status==='submitted' || ['won','lost'].includes(x.outcome)).map(x=>x.id)]).size, rate: won.length + lost.length ? Math.round(won.length / (won.length + lost.length) * 100) + '%' : '—', pipeline: active.reduce((s,x) => s + (x.contract_value || 0),0), revenue: won.reduce((s,x) => s + (x.realized_revenue || 0),0) };
};