import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { User, Sparkles, Loader2, Wrench, CheckCircle2, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react';

export default function ChatMessage({ message }) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex justify-end animate-fade-in">
        <div className="flex gap-3 max-w-[80%]">
          <div className="bg-primary/15 border border-primary/20 rounded-2xl rounded-tr-sm px-4 py-3">
            <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{message.content}</p>
          </div>
          <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start animate-fade-in">
      <div className="flex gap-3 max-w-[85%]">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-chart-4 flex items-center justify-center flex-shrink-0">
          <Sparkles className="w-4 h-4 text-primary-foreground" />
        </div>
        <div className="glass-card rounded-2xl rounded-tl-sm px-4 py-3 min-w-0">
          {message.content ? (
            <div className="text-sm text-foreground leading-relaxed prose prose-sm prose-invert max-w-none prose-p:my-1 prose-ul:my-1 prose-ol:my-1 prose-li:my-0 prose-headings:mb-2 prose-headings:text-foreground prose-strong:text-foreground prose-code:text-primary prose-code:bg-accent/40 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:content-none prose-code:after:content-none">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Trinity is thinking...</span>
            </div>
          )}
          {message.tool_calls?.map((tc, idx) => (
            <ToolCallDisplay key={idx} toolCall={tc} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ToolCallDisplay({ toolCall }) {
  const [expanded, setExpanded] = useState(false);
  const status = toolCall.status || 'pending';
  const isFailed = status === 'failed' || status === 'error';
  const isRunning = ['pending', 'running', 'in_progress'].includes(status);

  const statusIcon = isFailed ? <AlertCircle className="w-3.5 h-3.5 text-destructive" /> :
                     status === 'success' || status === 'completed' ? <CheckCircle2 className="w-3.5 h-3.5 text-primary" /> :
                     <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />;

  const label = toolCall.display_projection?.label || toolCall.name || 'Tool';
  const activeLabel = toolCall.display_projection?.active_label || label;
  const errorLabel = toolCall.display_projection?.error_label || `${label} failed`;

  const hideDetails = toolCall.display_projection?.hide_details && toolCall.display_projection?.details_redacted;
  if (hideDetails) {
    return (
      <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
        {statusIcon}
        <span>{isFailed ? errorLabel : isRunning ? activeLabel : label}</span>
      </div>
    );
  }

  let parsedArgs = toolCall.arguments_string;
  try { parsedArgs = JSON.parse(toolCall.arguments_string); } catch {}

  let parsedResults = toolCall.results;
  try { if (typeof toolCall.results === 'string') parsedResults = JSON.parse(toolCall.results); } catch {}

  return (
    <div className="mt-2 text-xs">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
      >
        {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        {statusIcon}
        <span className="font-medium">{isFailed ? errorLabel : isRunning ? activeLabel : label}</span>
      </button>
      {expanded && (
        <div className="mt-1.5 space-y-1.5 pl-5">
          {parsedArgs && (
            <div>
              <p className="text-muted-foreground/60 mb-0.5">Parameters:</p>
              <pre className="text-xs bg-background/40 rounded p-2 overflow-x-auto text-foreground/80">{JSON.stringify(parsedArgs, null, 2)}</pre>
            </div>
          )}
          {parsedResults !== undefined && (
            <div>
              <p className="text-muted-foreground/60 mb-0.5">Result:</p>
              <pre className="text-xs bg-background/40 rounded p-2 overflow-x-auto text-foreground/80 max-h-40">{typeof parsedResults === 'string' ? parsedResults : JSON.stringify(parsedResults, null, 2)}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}