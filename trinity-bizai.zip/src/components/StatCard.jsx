import React from 'react';

export default function StatCard({ icon: Icon, label, value, sublabel, accent = 'primary' }) {
  return (
    <div className="glass-card rounded-2xl p-5 transition-all duration-300 hover:border-primary/20">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl bg-${accent}/15 flex items-center justify-center`}>
          <Icon className={`w-5 h-5 text-${accent}`} />
        </div>
      </div>
      <p className="font-heading text-2xl font-bold text-foreground">{value}</p>
      <p className="text-sm text-muted-foreground mt-0.5">{label}</p>
      {sublabel && <p className="text-xs text-primary/60 mt-1">{sublabel}</p>}
    </div>
  );
}