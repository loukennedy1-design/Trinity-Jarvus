import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { waitUntil } from 'base44:runtime';
import { recordActivity } from '../../shared/activity.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { file_urls, agent_slug, agent_name } = await req.json();
    if (!file_urls || !file_urls.length) {
      return Response.json({ error: 'At least one file URL is required' }, { status: 400 });
    }

    const job = await base44.entities.TrainingJob.create({
      agent_slug: agent_slug || 'trinity_core',
      agent_name: agent_name || 'Trinity Core',
      status: 'processing',
      progress: 0,
      document_count: file_urls.length,
      file_urls
    });

    recordActivity(base44,user,'training',`Document training started: ${file_urls.length} documents.`,'TrainingJob',job.id,{status:'processing'});
    waitUntil(processTraining(base44, job, file_urls, agent_slug, user));

    return Response.json({ job_id: job.id, status: 'processing', message: 'Training started. The agent is learning from your documents.' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

async function processTraining(base44, job, fileUrls, agentSlug, user) {
  try {
    const entries = [];
    for (let i = 0; i < fileUrls.length; i++) {
      const fileUrl = fileUrls[i];
      const fileName = fileUrl.split('/').pop() || 'uploaded_document';

      const extracted = await base44.asServiceRole.integrations.Core.ExtractDataFromUploadedFile({
        file_url: fileUrl,
        json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            summary: { type: "string" },
            tags: { type: "array", items: { type: "string" } },
            domain: { type: "string", enum: ["strategy", "finance", "operations", "market", "economics", "general"] }
          }
        }
      });

      if (extracted.status === 'success' && extracted.output) {
        const data = Array.isArray(extracted.output) ? extracted.output[0] : extracted.output;
        const entry = await base44.entities.KnowledgeBase.create({
          title: data.title || fileName,
          content: (data.content || '').slice(0, 10000),
          summary: (data.summary || '').slice(0, 500),
          source_type: 'training',
          source_name: fileName,
          source_url: fileUrl,
          agent_slug: agentSlug || 'general',
          tags: data.tags || [],
          domain: data.domain || 'general',
          status: 'ready'
        });
        entries.push(entry);
      }

      await base44.entities.TrainingJob.update(job.id, {
        progress: Math.round(((i + 1) / fileUrls.length) * 90)
      });
    }

    let summary = 'Training completed successfully.';
    if (entries.length > 0) {
      const summaryResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `An AI agent was just trained with the following knowledge entries:\n${entries.map(e => `- ${e.title}: ${e.summary}`).join('\n')}\n\nWrite a brief 2-3 sentence summary of what the agent learned. Be specific about the knowledge gained.`,
        response_json_schema: { type: "object", properties: { summary: { type: "string" } } }
      });
      summary = summaryResult.summary || summary;
    }

    await base44.entities.TrainingJob.update(job.id, {
      status: 'completed',
      progress: 100,
      knowledge_entries_created: entries.length,
      summary
    });
    recordActivity(base44,user,'training',`Document training completed: ${entries.length} knowledge entries created.`,'TrainingJob',job.id,{status:'completed'});
  } catch (error) {
    await base44.entities.TrainingJob.update(job.id, {
      status: 'failed',
      summary: `Training failed: ${error.message}`
    });
    recordActivity(base44,user,'training','Document training failed. Review the training job for details.','TrainingJob',job.id,{status:'failed'});
  }
}