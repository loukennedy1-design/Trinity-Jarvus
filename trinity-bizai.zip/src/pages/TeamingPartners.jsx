import React from 'react';
import { Users } from 'lucide-react';
import DirectoryPage from '@/components/business/DirectoryPage';
const fields=[{key:'company_name',label:'Company Name',required:true},{key:'contact_name',label:'Contact Name'},{key:'email',label:'Email',type:'email'},{key:'phone',label:'Phone'},{key:'capabilities',label:'Capabilities',long:true},{key:'naics_codes',label:'NAICS Codes',array:true},{key:'certifications',label:'Certifications',array:true},{key:'notes',label:'Notes',long:true}];
export default function TeamingPartners(){return <DirectoryPage name="TeamingPartner" title="Teaming Partners" subtitle="Organize potential partners for stronger joint federal bids." icon={Users} fields={fields} titleField="company_name" />;}