import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { TIER_LIMITS } from '../../shared/credits.ts';

// Resets credits_used and messages_this_period for subscriptions past their renewal date,
// then pushes renews_at forward one month. Uses service role for cross-user subscription
// updates. Requires the sole admin to be authenticated.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    // Requires the sole admin to be authenticated.
    let user = null;
    try { user = await base44.auth.me(); } catch {}
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const adminId = secrets.get('ADMIN_USER_ID');
    if (!adminId || user.role !== 'admin' || user.id !== adminId) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const now = new Date();
    const allSubs = await base44.asServiceRole.entities.Subscription.list('-created_date', 500);
    const expired = allSubs.filter(s => s.renews_at && new Date(s.renews_at) <= now);

    const newRenews = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();

    for (const sub of expired) {
      await base44.asServiceRole.entities.Subscription.update(sub.id, {
        credits_used: 0,
        messages_this_period: 0,
        renews_at: newRenews
      });
    }

    return Response.json({ success: true, reset_count: expired.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}