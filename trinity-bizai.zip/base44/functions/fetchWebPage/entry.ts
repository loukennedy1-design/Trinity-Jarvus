import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';

// Lets Trinity read any public web page. Removes the limit on where she can
// obtain knowledge: any URL the user mentions, she can fetch and reason over.
function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)));
}

function extractText(html: string): { title: string; text: string } {
  let title = '';
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (titleMatch) title = decodeEntities(titleMatch[1].trim()).slice(0, 200);

  // Drop non-content blocks.
  let body = html.replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ');
  // Preserve some structure.
  body = body.replace(/<\/(p|div|li|h[1-6]|br|tr)>/gi, '\n').replace(/<br\s*\/?>/gi, '\n');
  body = body.replace(/<[^>]+>/g, ' ');
  body = decodeEntities(body);
  body = body.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  return { title, text: body.slice(0, 12000) };
}

function isBlockedHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  return h === 'localhost' || h === '0.0.0.0' || h.endsWith('.localhost') ||
    h === 'metadata.google.internal' ||
    /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h);
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { url } = await req.json();
    if (typeof url !== 'string' || url.length > 2048) {
      return Response.json({ error: 'A valid http(s) URL is required.' }, { status: 400 });
    }
    let parsed: URL;
    try { parsed = new URL(url); } catch { return Response.json({ error: 'Invalid URL.' }, { status: 400 }); }
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return Response.json({ error: 'Only http and https URLs are supported.' }, { status: 400 });
    }
    if (isBlockedHost(parsed.hostname)) {
      return Response.json({ error: 'This URL cannot be fetched.' }, { status: 400 });
    }

    const creditCheck = await consumeCredits(base44, CREDIT_COSTS.web_fetch || 1);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits.' }, { status: 402 });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    let res: Response;
    try {
      res = await fetch(parsed.toString(), {
        headers: { 'User-Agent': 'Trinity-Business-AI/1.0 (+knowledge gathering)', 'Accept': 'text/html,application/xhtml+xml,text/plain,*/*;q=0.8' },
        redirect: 'follow',
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }
    if (!res.ok) return Response.json({ error: `Could not fetch page (HTTP ${res.status}).` }, { status: 502 });

    const contentType = res.headers.get('content-type') || '';
    const raw = await res.text();
    const { title, text } = extractText(raw);
    if (!text.trim()) return Response.json({ error: 'No readable content found on this page.' }, { status: 422 });

    return Response.json({
      success: true,
      url: parsed.toString(),
      title: title || parsed.hostname,
      content_type: contentType,
      text,
    });
  } catch {
    return Response.json({ error: 'Could not read this page. It may block automated access.' }, { status: 502 });
  }
}