export async function requestSAM(apiKey, {limit=1, title='', naics=''} = {}) {
  const format = date => `${String(date.getUTCMonth()+1).padStart(2,'0')}/${String(date.getUTCDate()).padStart(2,'0')}/${date.getUTCFullYear()}`;
  const params = new URLSearchParams({api_key:apiKey,postedFrom:format(new Date(Date.now()-90*86400000)),postedTo:format(new Date()),limit:String(limit),offset:'0'});
  if (title) params.set('title', title);
  if (naics) params.set('ncode', naics);
  // Fixed official destination; refuse redirects so a credential cannot be forwarded elsewhere.
  const response = await fetch(`https://api.sam.gov/opportunities/v2/search?${params}`, {redirect:'error',signal:AbortSignal.timeout(15000)});
  const data = response.ok ? await response.json() : null;
  return {ok:response.ok,status:response.status,data};
}
export function samFailure(status) {
  if ([401,403].includes(status)) return 'SAM.gov rejected this key or its permissions. Check your key and account access.';
  if (status===429) return 'SAM.gov daily request limit reached. Try again after the limit resets.';
  return 'SAM.gov is unavailable or could not complete the request. Please try again later.';
}