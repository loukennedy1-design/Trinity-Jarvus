// Shared credit metering logic — imported by speakResponse, gatherKnowledge, consumeChatMessage.
// Never copy this logic across functions; import from here.

import { secrets } from 'base44:runtime';

export const CREDIT_COSTS = {
  voice_output: 1,
  knowledge_gathering: 10,
  sam_search: 5,
  opportunity_analysis: 10,
  proposal_drafting: 5,
  web_research: 3,
  web_fetch: 1
};

// The sole platform admin gets unlimited credits and messages.
// Admin ID is stored as a secret — never hardcoded in source.
async function isSoleAdmin(base44) {
  try {
    const user = await base44.auth.me();
    const adminId = secrets.get('ADMIN_USER_ID');
    return !!adminId && user?.id === adminId;
  } catch {
    return false;
  }
}

export const TIER_LIMITS = {
  free: { credits: 50, messages: 50 },
  pro: { credits: 1000, messages: null },
  enterprise: { credits: 10000, messages: null }
};

// Load the caller's subscription, creating a free one if none exists yet.
export async function getOrCreateSubscription(base44) {
  const subs = await base44.entities.Subscription.list('-created_date', 1);
  if (subs.length) return subs[0];
  return await base44.asServiceRole.entities.Subscription.create({
    tier: 'free',
    status: 'active',
    credits_used: 0,
    credits_limit: TIER_LIMITS.free.credits,
    messages_this_period: 0,
    messages_limit: TIER_LIMITS.free.messages,
    started_at: new Date().toISOString(),
    renews_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
  });
}

// Check and consume credits for a premium action (voice output, knowledge gathering).
// Returns { allowed, remaining, subscription }.
export async function consumeCredits(base44, amount) {
  const sub = await getOrCreateSubscription(base44);
  if (await isSoleAdmin(base44)) {
    return { allowed: true, remaining: Infinity, subscription: sub };
  }
  const limit = sub.credits_limit ?? TIER_LIMITS[sub.tier]?.credits ?? 50;
  const used = sub.credits_used || 0;
  const remaining = limit - used;
  if (remaining < amount) {
    return { allowed: false, remaining, subscription: sub };
  }
  await base44.asServiceRole.entities.Subscription.update(sub.id, { credits_used: used + amount });
  return { allowed: true, remaining: remaining - amount, subscription: sub };
}

// Check and consume a chat message against the free-tier cap.
// Paid tiers are unlimited (no increment). Returns { allowed, remaining, limit, unlimited, subscription }.
export async function consumeChatMessage(base44) {
  const sub = await getOrCreateSubscription(base44);
  if (await isSoleAdmin(base44)) {
    return { allowed: true, unlimited: true, subscription: sub };
  }
  if (sub.tier !== 'free') {
    return { allowed: true, unlimited: true, subscription: sub };
  }
  const limit = sub.messages_limit ?? TIER_LIMITS.free.messages;
  const used = sub.messages_this_period || 0;
  if (used >= limit) {
    return { allowed: false, remaining: 0, limit, subscription: sub };
  }
  await base44.asServiceRole.entities.Subscription.update(sub.id, { messages_this_period: used + 1 });
  return { allowed: true, remaining: limit - used - 1, limit, subscription: sub };
}