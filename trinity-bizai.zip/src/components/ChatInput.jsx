import React, { useState } from 'react';
import { Send, Paperclip, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import VoiceInput from './VoiceInput';

export default function ChatInput({ onSend, disabled, placeholder = "Ask Trinity anything about your business...", onListeningChange }) {
  const [text, setText] = useState('');
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);

  const handleSend = () => {
    if (!text.trim() || disabled) return;
    onSend(text.trim(), files);
    setText('');
    setFiles([]);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFile = async (e) => {
    const selected = Array.from(e.target.files || []);
    if (!selected.length) return;
    setUploading(true);
    try {
      const uploaded = [];
      for (const file of selected) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploaded.push({ url: file_url, name: file.name });
      }
      setFiles(prev => [...prev, ...uploaded]);
    } catch (err) {
      console.error('Upload failed:', err);
    } finally {
      setUploading(false);
    }
  };

  const removeFile = (idx) => {
    setFiles(prev => prev.filter((_, i) => i !== idx));
  };

  return (
    <div className="glass-card rounded-2xl p-3 border border-border/60">
      {files.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2 px-1">
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-1.5 bg-accent/40 rounded-lg px-2 py-1 text-xs">
              <Paperclip className="w-3 h-3 text-primary" />
              <span className="text-foreground/80 max-w-32 truncate">{f.name}</span>
              <button onClick={() => removeFile(i)} className="text-muted-foreground hover:text-destructive">×</button>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-end gap-2">
        <label className="p-2.5 rounded-xl hover:bg-accent/50 cursor-pointer transition-colors flex-shrink-0">
          <input type="file" multiple onChange={handleFile} className="hidden" />
          {uploading ? <Loader2 className="w-5 h-5 text-primary animate-spin" /> : <Paperclip className="w-5 h-5 text-muted-foreground" />}
        </label>
        <VoiceInput
          onResult={(t) => setText((prev) => (prev ? prev + ' ' + t : t))}
          onListeningChange={onListeningChange}
          disabled={disabled}
        />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          placeholder={placeholder}
          rows={1}
          className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground resize-none outline-none py-2.5 max-h-32 scrollbar-thin"
          style={{ minHeight: '44px' }}
        />
        <button
          onClick={handleSend}
          disabled={disabled || (!text.trim() && files.length === 0)}
          className="p-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex-shrink-0"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}