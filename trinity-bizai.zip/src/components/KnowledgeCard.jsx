import React from 'react';
import { FileText, Database, Globe, Upload, BookOpen, Trash2 } from 'lucide-react';

const sourceIcons = {
  upload: Upload,
  oauth_sync: Globe,
  manual: BookOpen,
  training: FileText
};

const domainColors = {
  strategy: 'text-chart-2',
  finance: 'text-chart-4',
  operations: 'text-chart-5',
  market: 'text-chart-1',
  economics: 'text-chart-3',
  general: 'text-muted-foreground'
};

export default function KnowledgeCard({ entry, onDelete }) {
  const SourceIcon = sourceIcons[entry.source_type] || FileText;
  const domainColor = domainColors[entry.domain] || 'text-muted-foreground';

  return (
    <div className="glass-card rounded-xl p-4 transition-all duration-200 hover:border-primary/20 group">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-accent/40 flex items-center justify-center flex-shrink-0">
          <SourceIcon className={`w-5 h-5 ${domainColor}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-sm text-foreground truncate">{entry.title}</h3>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{entry.summary || entry.content?.slice(0, 120)}</p>
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <span className={`text-xs font-medium ${domainColor}`}>{entry.domain}</span>
            <span className="text-xs text-muted-foreground/50">·</span>
            <span className="text-xs text-muted-foreground truncate max-w-32">{entry.source_name}</span>
            {entry.tags?.slice(0, 2).map(tag => (
              <span key={tag} className="text-xs px-1.5 py-0.5 rounded bg-accent/30 text-muted-foreground">{tag}</span>
            ))}
          </div>
        </div>
        {onDelete && (
          <button
            onClick={() => onDelete(entry)}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/5 opacity-0 group-hover:opacity-100 transition-all flex-shrink-0"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}