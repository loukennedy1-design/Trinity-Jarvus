import React, {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {History} from 'lucide-react';
import {base44} from '@/api/base44Client';
import {readOwned,readRecords} from '@/components/business/useBusinessData';
import BusinessPage from '@/components/business/BusinessPage';
import RecordForm from '@/components/business/RecordForm';
import {Input} from '@/components/ui/input';
import {Button} from '@/components/ui/button';
const types=['search','analysis','proposal','training','pipeline','profile','connection'];
const fields=[{key:'owner_id',label:'User ID',required:true},{key:'action_type',label:'Action Type',options:types,default:'profile'},{key:'description',label:'Description',long:true,required:true},{key:'entity_type',label:'Related Entity'},{key:'entity_id',label:'Related Record ID'}];
export default function ActivityLog(){
  const [type,setType]=useState('all');const [search,setSearch]=useState('');const [editing,setEditing]=useState(null);const [failure,setFailure]=useState('');const [page,setPage]=useState(0);const [busy,setBusy]=useState(false);
  const {data,isLoading,error,refetch}=useQuery({queryKey:['audit-log'],queryFn:async()=>{const user=await base44.auth.me();const rows=user.role==='admin'?await readRecords('ActivityLog'):await readOwned('ActivityLog');return {user,rows};}});
  const admin=data?.user.role==='admin';const rows=(data?.rows || []).filter(a=>(type==='all'||a.action_type===type)&&a.description.toLowerCase().includes(search.toLowerCase()));
  const save=async values=>{if(editing.id)await base44.entities.ActivityLog.update(editing.id,values);else await base44.entities.ActivityLog.create(values);await refetch();};
  const remove=async a=>{if(!window.confirm('Delete this audit entry? This removes its history permanently.'))return;setBusy(true);try{await base44.entities.ActivityLog.delete(a.id);await refetch();}catch(e){setFailure(e.message);}finally{setBusy(false);}};
  const link=a=>a.entity_type==='Proposal'?`/proposals?id=${encodeURIComponent(a.entity_id)}`:a.entity_type==='ContractOpportunity'?'/bid-pipeline':a.entity_type==='CompanyProfile'?'/settings':null;
  return <BusinessPage title="Activity Log" subtitle="System-recorded searches, analysis, drafting, and training activity from now onward." icon={History} loading={isLoading} error={error || failure} actions={admin && <Button onClick={()=>setEditing({owner_id:data.user.id})}>Add Administrative Entry</Button>}>
    {editing && admin && <RecordForm title="Administrative Audit Entry" fields={fields} initial={editing} onSave={save} onClose={()=>setEditing(null)} />}
    <div className="flex flex-wrap gap-3"><Input className="max-w-sm" placeholder="Search activity…" aria-label="Search activity" value={search} onChange={e=>{setSearch(e.target.value);setPage(0);}}/><select className="bg-card border p-2 rounded-lg" aria-label="Filter activity type" value={type} onChange={e=>{setType(e.target.value);setPage(0);}}>{['all',...types].map(t=><option key={t} value={t}>{t}</option>)}</select><Button variant="outline" onClick={()=>refetch()}>Refresh</Button></div>
    <div className="glass-card rounded-2xl divide-y">{rows.slice(page*30,(page+1)*30).map(a=><article key={a.id} className="p-5"><div className="flex flex-wrap justify-between gap-2"><p className="text-primary text-xs uppercase tracking-wide">{a.action_type}{a.metadata?.status ? ` · ${a.metadata.status}`:''}</p><time className="text-xs text-muted-foreground">{new Date(a.created_date).toLocaleString()}</time></div><p className="my-2">{a.description}</p>{link(a) && <Link to={link(a)} className="text-sm text-primary">Open related record →</Link>}{a.entity_id && <p className="text-xs text-muted-foreground mt-1">{a.entity_type}: {a.entity_id}</p>}{admin && <div className="flex gap-2 mt-3"><Button variant="ghost" onClick={()=>setEditing(a)}>Edit</Button><Button disabled={busy} variant="ghost" onClick={()=>remove(a)}>Delete</Button></div>}</article>)}{!rows.length && <p className="p-8 text-muted-foreground">No activity yet. Run a search, analyze a document, or draft a proposal.</p>}</div>
    <div className="flex gap-3 items-center"><Button variant="outline" disabled={!page} onClick={()=>setPage(page-1)}>Previous</Button><span className="text-sm">Page {page+1}</span><Button variant="outline" disabled={(page+1)*30>=rows.length} onClick={()=>setPage(page+1)}>Next</Button></div>
  </BusinessPage>;
}