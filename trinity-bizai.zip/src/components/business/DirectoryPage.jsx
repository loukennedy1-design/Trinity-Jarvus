import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { readOwned, readRecords } from '@/components/business/useBusinessData';
import BusinessPage from '@/components/business/BusinessPage';
import RecordForm from '@/components/business/RecordForm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
export default function DirectoryPage({ name,title,subtitle,icon,fields,titleField,allowAdminAll=false }) {
  const [editing,setEditing]=useState(null); const [search,setSearch]=useState(''); const [filter,setFilter]=useState('all'); const [failure,setFailure]=useState(''); const [deleting,setDeleting]=useState(false);
  const {data,isLoading,error,refetch}=useQuery({queryKey:[name],queryFn:async()=>{const user=await base44.auth.me();const rows=allowAdminAll && user.role==='admin' ? await readRecords(name) : await readOwned(name);return {rows,user};}});
  const save=async values=>{if(editing?.id) await base44.entities[name].update(editing.id,values); else await base44.entities[name].create(values);await refetch();};
  const remove=async row=>{if(!window.confirm(`Delete “${row[titleField]}”? This cannot be undone.`))return;setDeleting(true);setFailure('');try{await base44.entities[name].delete(row.id);await refetch();}catch(e){setFailure(e.message);}finally{setDeleting(false);}};
  const statuses=fields.find(f=>f.key==='status')?.options;
  const rows=(data?.rows || []).filter(r=>(filter==='all' || r.status===filter) && JSON.stringify(r).toLowerCase().includes(search.toLowerCase()));
  return <BusinessPage title={title} subtitle={subtitle} icon={icon} loading={isLoading} error={error || failure} actions={<Button onClick={()=>setEditing({})}>Add {name==='SupportTicket'?'Ticket':'Partner'}</Button>}>
    {editing && <RecordForm title={editing.id?'Edit Record':'New Record'} fields={fields} initial={editing} onSave={save} onClose={()=>setEditing(null)} />}
    <div className="flex gap-3 flex-wrap"><Input className="max-w-sm" aria-label="Search directory" placeholder="Search…" value={search} onChange={e=>setSearch(e.target.value)} />{statuses && <select aria-label="Filter status" className="bg-card border p-2 rounded-lg" value={filter} onChange={e=>setFilter(e.target.value)}>{['all',...statuses].map(x=><option key={x} value={x}>{x.replaceAll('_',' ')}</option>)}</select>}</div>
    {!rows.length && <p className="glass-card p-8 rounded-2xl text-muted-foreground">No records match this view. Add your first {name==='SupportTicket'?'ticket':'partner'} above.</p>}
    <div className="grid md:grid-cols-2 gap-4">{rows.map(r=><article key={r.id} className="glass-card rounded-2xl p-5 space-y-3"><h2 className="font-semibold">{r[titleField]}</h2>{fields.filter(f=>f.key!==titleField).map(f=><div key={f.key}><p className="text-xs uppercase tracking-wide text-muted-foreground">{f.label}</p><p className="text-sm whitespace-pre-wrap break-words">{Array.isArray(r[f.key]) ? r[f.key].join(', ') || '—' : String(r[f.key] || '—').replaceAll('_',' ')}</p></div>)}<p className="text-xs text-muted-foreground">Updated {new Date(r.updated_date).toLocaleString()}</p><div className="flex gap-2"><Button variant="outline" onClick={()=>setEditing(r)}>Edit</Button><Button variant="ghost" disabled={deleting} onClick={()=>remove(r)}>Delete</Button></div></article>)}</div>
  </BusinessPage>;
}