import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { AXIS_MCP_URL, getAxisAccessToken, markAxisLinkError } from '../../shared/axisLink.ts';

const ALLOWED_METHODS = ['tools/list', 'tools/call', 'resources/list', 'resources/read', 'prompts/list'];

async function rpc(token: string, sessionId: string | null, payload: Record<string, unknown>) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json, text/event-stream',
    Authorization: `Bearer ${token}`,
  };
  if (sessionId) headers['Mcp-Session-Id'] = sessionId;
  const res = await fetch(AXIS_MCP_URL, { method: 'POST', headers, body: JSON.stringify(payload) });
  const text = await res.text();
  let data = null;
  try {
    if ((res.headers.get('content-type') || '').includes('text/event-stream')) {
      const line = text.split('\n').filter((l) => l.startsWith('data:')).pop();
      data = line ? JSON.parse(line.slice(5).trim()) : null;
    } else if (text) {
      data = JSON.parse(text);
    }
  } catch { data = null; }
  return { ok: res.ok, status: res.status, data, sessionId: res.headers.get('mcp-session-id') || sessionId };
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { method, params } = body;
    if (!ALLOWED_METHODS.includes(method) || (params != null && typeof params !== 'object')) {
      return Response.json({ error: 'invalid_request', message: `method must be one of: ${ALLOWED_METHODS.join(', ')}` }, { status: 400 });
    }

    const { link, token } = await getAxisAccessToken(base44, user);
    if (!token) {
      return Response.json({ error: 'axis_not_connected', message: 'Sign in to Axis Business Suite from Integrations first.' }, { status: 409 });
    }

    const init = await rpc(token, null, {
      jsonrpc: '2.0', id: 1, method: 'initialize',
      params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'Trinity Business Intelligence', version: '1.0.0' } },
    });
    if (init.status === 401) {
      await markAxisLinkError(base44, link);
      return Response.json({ error: 'axis_reauth_required', message: 'Your Axis sign-in expired. Reconnect from Integrations.' }, { status: 401 });
    }
    if (!init.ok) return Response.json({ error: 'axis_unavailable', message: 'Axis Business Suite did not respond.' }, { status: 502 });

    await rpc(token, init.sessionId, { jsonrpc: '2.0', method: 'notifications/initialized' });
    const result = await rpc(token, init.sessionId, { jsonrpc: '2.0', id: 2, method, params: params ?? {} });
    if (!result.ok || !result.data) return Response.json({ error: 'axis_call_failed', message: 'Axis Business Suite could not complete the request.' }, { status: 502 });

    return Response.json(result.data);
  } catch {
    return Response.json({ error: 'axis_call_failed', message: 'Could not reach Axis Business Suite.' }, { status: 502 });
  }
}