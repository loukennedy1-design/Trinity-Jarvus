import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

const TIER_PRICES = {
  pro: { amount: 1900, name: 'Trinity Pro — Monthly' },
  enterprise: { amount: 9900, name: 'Trinity Enterprise — Monthly' }
};

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { tier } = await req.json();
    if (!TIER_PRICES[tier]) return Response.json({ error: 'Invalid tier' }, { status: 400 });

    // Construct redirect URL server-side — never trust client-supplied redirect targets.
    const appOrigin = new URL(req.url).origin;
    const safeRedirectUrl = `${appOrigin}/subscription?checkout=success`;

    const accessToken = secrets.get('SQUARE_ACCESS_TOKEN');
    const locationId = secrets.get('SQUARE_LOCATION_ID');
    const environment = secrets.get('SQUARE_ENVIRONMENT') || 'sandbox';

    // Graceful seam — until Square credentials are wired in, surface a clear message.
    if (!accessToken || !locationId) {
      return Response.json({
        configured: false,
        message: 'Payment is coming soon. We are finalizing our billing system — please check back shortly to complete your upgrade.'
      });
    }

    const baseUrl = environment === 'production'
      ? 'https://connect.squareup.com'
      : 'https://connect.squareupsandbox.com';

    const price = TIER_PRICES[tier];
    const idempotencyKey = crypto.randomUUID();

    const response = await fetch(`${baseUrl}/v2/online-checkout/payment-links`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Square-Version': '2024-08-21'
      },
      body: JSON.stringify({
        idempotency_key: idempotencyKey,
        quick_pay: {
          name: price.name,
          price_money: { amount: price.amount, currency: 'USD' },
          location_id: locationId
        },
        checkout_options: { redirect_url: safeRedirectUrl }
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return Response.json({ error: data.errors?.[0]?.detail || 'Square checkout failed' }, { status: 502 });
    }

    // Bind the order to the calling user so only they can fulfill it.
    const orderId = data.payment_link?.order_id;
    if (orderId) {
      try {
        const subs = await base44.asServiceRole.entities.Subscription.filter(
          { created_by_id: user.id }, '-created_date', 1
        );
        if (subs.length) {
          await base44.asServiceRole.entities.Subscription.update(subs[0].id, { pending_order_id: orderId });
        }
      } catch { /* best-effort binding */ }
    }

    return Response.json({
      configured: true,
      checkout_url: data.payment_link?.url,
      payment_link_id: data.payment_link?.id,
      order_id: orderId
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}