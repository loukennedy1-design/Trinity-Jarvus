import React, { useState } from 'react';
import ProposalBuilder from '@/components/contracts/ProposalBuilder';
import SubmissionGuide from '@/components/contracts/SubmissionGuide';
import ReactMarkdown from 'react-markdown';
export default function ProposalWorkspace({ proposal, opportunity, onBack }) {
  const [submit,setSubmit] = useState(false);
  if (!opportunity) return <section className="glass-card p-6 rounded-2xl space-y-4"><button className="text-primary" onClick={onBack}>← Back to library</button><p className="text-muted-foreground">The linked opportunity is unavailable. Saved proposal content is shown below.</p>{Object.entries(proposal.sections || {}).map(([title,s])=><div key={title}><h2 className="font-semibold">{title}</h2><ReactMarkdown>{s.content || ''}</ReactMarkdown></div>)}</section>;
  return submit ? <SubmissionGuide opportunity={opportunity} proposal={proposal} onBack={onBack} /> : <ProposalBuilder opportunity={opportunity} proposalId={proposal.id} onBack={onBack} onSubmissionGuide={()=>setSubmit(true)} />;
}