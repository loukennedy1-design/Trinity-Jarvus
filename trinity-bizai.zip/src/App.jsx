import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Layout from '@/components/Layout';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import OAuthConsent from '@/pages/OAuthConsent';
import Chat from '@/pages/Chat';
import IntegrationsHub from '@/pages/IntegrationsHub';
import Subscription from '@/pages/Subscription';
import Usage from '@/pages/Usage';
import Admin from '@/pages/Admin';
import Connector from '@/pages/Connector';
import Contracts from '@/pages/Contracts';
import AdminRoute from '@/components/AdminRoute';
import Dashboard from '@/pages/Dashboard';
import Proposals from '@/pages/Proposals';
import Settings from '@/pages/Settings';
import BidPipeline from '@/pages/BidPipeline';
import Analytics from '@/pages/Analytics';
import PerformanceMetrics from '@/pages/PerformanceMetrics';
import ComplianceAudit from '@/pages/ComplianceAudit';
import SupportTickets from '@/pages/SupportTickets';
import TeamingPartners from '@/pages/TeamingPartners';
import ActivityLog from '@/pages/ActivityLog';
import LearningCenter from '@/pages/LearningCenter';
import GovernmentConnections from '@/pages/GovernmentConnections';
import AxisCallback from '@/pages/AxisCallback';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/oauth/consent" element={<OAuthConsent />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Chat />} />
          <Route path="/integrations" element={<IntegrationsHub />} />
          <Route path="/connections" element={<IntegrationsHub />} />
          <Route path="/integrations/axis/callback" element={<AxisCallback />} />
          <Route path="/subscription" element={<Subscription />} />
          <Route path="/usage" element={<Usage />} />
          <Route path="/contracts" element={<Contracts />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/proposals" element={<Proposals />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/bid-pipeline" element={<BidPipeline />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/performance-metrics" element={<PerformanceMetrics />} />
          <Route path="/compliance-audit" element={<ComplianceAudit />} />
          <Route path="/support-tickets" element={<SupportTickets />} />
          <Route path="/teaming-partners" element={<TeamingPartners />} />
          <Route path="/activity-log" element={<ActivityLog />} />
          <Route path="/learning-center" element={<LearningCenter />} />
          <Route path="/government-connections" element={<GovernmentConnections />} />
          <Route element={<AdminRoute />}>
            <Route path="/connector" element={<Connector />} />
            <Route path="/admin" element={<Admin />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App