import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Loader2, LogIn, CheckCircle2, Unplug } from 'lucide-react';

export default function AxisLinkPanel() {
  const [link, setLink] = useState({ loading: true, connected: false, status: 'not_connected' });
  const [toolCount, setToolCount] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    base44.functions.invoke('manageAxisLink', { action: 'status' })
      .then((res) => setLink({ loading: false, ...res.data }))
      .catch(() => setLink({ loading: false, connected: false, status: 'not_connected' }));
  }, []);

  useEffect(() => {
    if (!link.connected) return;
    base44.functions.invoke('axisMcpCall', { method: 'tools/list' })
      .then((res) => setToolCount(res.data?.result?.tools?.length ?? 0))
      .catch(() => setError('Axis did not respond. Try reconnecting.'));
  }, [link.connected]);

  const connect = async () => {
    setBusy(true);
    setError('');
    try {
      const redirect_uri = new URL('/integrations/axis/callback', window.location.origin).toString();
      const res = await base44.functions.invoke('manageAxisLink', { action: 'start', redirect_uri });
      window.location.href = res.data.auth_url;
    } catch {
      setError('Could not start the Axis sign-in. Try again.');
      setBusy(false);
    }
  };

  const disconnect = async () => {
    setBusy(true);
    await base44.functions.invoke('manageAxisLink', { action: 'disconnect' });
    setLink({ loading: false, connected: false, status: 'not_connected' });
    setToolCount(null);
    setBusy(false);
  };

  if (link.loading) return <div className="flex items-center gap-2 text-xs text-muted-foreground"><Loader2 className="w-3.5 h-3.5 animate-spin" />Checking Axis connection…</div>;

  return (
    <div className="space-y-2">
      {link.connected ? (
        <div className="flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 text-sm text-primary"><CheckCircle2 className="w-4 h-4" />Signed in to Axis{toolCount !== null && ` · ${toolCount} tools`}</span>
          <Button variant="ghost" size="sm" onClick={disconnect} disabled={busy}><Unplug />Disconnect</Button>
        </div>
      ) : (
        <Button onClick={connect} disabled={busy} className="w-full">
          {busy ? <Loader2 className="animate-spin" /> : <LogIn />}
          {link.status === 'error' ? 'Reconnect to Axis' : 'Sign in to Axis'}
        </Button>
      )}
      {link.status === 'error' && !link.connected && <p className="text-xs text-muted-foreground">Your Axis sign-in expired. Sign in again to restore the link.</p>}
      {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
    </div>
  );
}