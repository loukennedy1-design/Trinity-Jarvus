import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import ProposalSection from '@/components/contracts/ProposalSection';
import { ArrowLeft, Loader2, PenLine, CheckCircle2, FileText, Upload } from 'lucide-react';

const SECTIONS = ['Executive Summary', 'Technical Approach', 'Past Performance', 'Management Plan', 'Required Forms'];

export default function ProposalBuilder({ opportunity, proposalId, onBack, onSubmissionGuide }) {
  const [proposal, setProposal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [drafting, setDrafting] = useState(false);
  const [activeSection, setActiveSection] = useState(null);
  const [supportingDocs, setSupportingDocs] = useState([]);

  useEffect(() => { loadProposal(); }, [opportunity.id]);

  const loadProposal = async () => {
    try {
      const list = proposalId ? [await base44.entities.Proposal.get(proposalId)] : await base44.entities.Proposal.filter({ opportunity_id: opportunity.id }, '-created_date', 1);
      setProposal(list[0] || null);
      setSupportingDocs(list[0]?.supporting_docs || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const draftAll = async () => {
    setDrafting(true);
    try {
      const res = await base44.functions.invoke('draftProposal', { opportunity_id: opportunity.id });
      if (res.data?.sections) {
        await loadProposal();
      }
    } catch (e) { console.error(e); }
    setDrafting(false);
  };

  const handleSectionUpdated = async (updates) => {
    if (!proposal) return;
    const newSections = { ...proposal.sections, ...updates };
    const overall_status = SECTIONS.every(s => newSections[s]?.approved) ? 'approved' : 'in_review';
    await base44.entities.Proposal.update(proposal.id, { sections: newSections, overall_status });
    setProposal({ ...proposal, sections: newSections, overall_status });
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      const docs = [...supportingDocs, file_url];
      setSupportingDocs(docs);
      if (proposal) {
        await base44.entities.Proposal.update(proposal.id, { supporting_docs: docs });
      }
    } catch (err) { console.error(err); }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  const sections = proposal?.sections || {};
  const approvedCount = SECTIONS.filter(s => sections[s]?.approved).length;
  const allApproved = approvedCount === SECTIONS.length;

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to opportunity
      </button>

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-heading text-xl font-semibold text-foreground">Proposal Builder</h2>
          <p className="text-sm text-muted-foreground">{opportunity.title}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">{approvedCount}/{SECTIONS.length} approved</span>
          {!proposal || Object.keys(sections).length === 0 ? (
            <Button onClick={draftAll} disabled={drafting} className="gap-2">
              {drafting ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenLine className="w-4 h-4" />}
              Draft Full Proposal
            </Button>
          ) : allApproved ? (
            <Button onClick={onSubmissionGuide} className="gap-2">
              <CheckCircle2 className="w-4 h-4" /> Go to Submission Guide
            </Button>
          ) : null}
        </div>
      </div>

      <div className="grid md:grid-cols-[200px_1fr] gap-5">
        {/* Section list sidebar */}
        <div className="space-y-1">
          {SECTIONS.map(s => {
            const has = sections[s];
            const approved = has?.approved;
            return (
              <button key={s} onClick={() => setActiveSection(s)} className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all flex items-center gap-2 ${activeSection === s ? 'bg-primary/15 text-primary border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-accent/30 border border-transparent'}`}>
                {approved ? <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" /> : has ? <FileText className="w-4 h-4 flex-shrink-0 opacity-50" /> : <div className="w-4 h-4 rounded-full border border-muted-foreground/30 flex-shrink-0" />}
                <span className="truncate">{s}</span>
              </button>
            );
          })}
          <div className="pt-3 mt-2 border-t border-border">
            <label className="cursor-pointer">
              <input type="file" className="hidden" onChange={handleUpload} multiple />
              <span className="flex items-center gap-2 text-xs text-muted-foreground hover:text-primary transition-colors px-3 py-2">
                <Upload className="w-3.5 h-3.5" /> Add supporting doc
              </span>
            </label>
            {supportingDocs.length > 0 && <p className="text-xs text-muted-foreground/60 px-3">{supportingDocs.length} doc(s) attached</p>}
          </div>
        </div>

        {/* Active section editor */}
        <div>
          {activeSection && sections[activeSection] ? (
            <ProposalSection key={activeSection} sectionName={activeSection} sectionData={sections[activeSection]} proposalId={proposal?.id} opportunityId={opportunity.id} onUpdated={handleSectionUpdated} />
          ) : activeSection ? (
            <div className="glass-card rounded-2xl p-8 text-center">
              <p className="text-sm text-muted-foreground mb-4">This section hasn't been generated yet.</p>
              <Button onClick={draftAll} disabled={drafting} className="gap-2">
                {drafting ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenLine className="w-4 h-4" />} Generate All Sections
              </Button>
            </div>
          ) : (
            <div className="glass-card rounded-2xl p-8 text-center">
              <PenLine className="w-10 h-10 text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Select a section to review, or draft the full proposal to get started.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}