import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';
import { recordActivity } from '../../shared/activity.ts';

export default async function(req: Request): Promise<Response> {
  let resetStatus = async () => {};
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { opportunity_id, uploaded_file_url } = await req.json();
    if (!opportunity_id) return Response.json({ error: 'opportunity_id required' }, { status: 400 });

    const opportunity = await base44.entities.ContractOpportunity.get(opportunity_id);
    if (!opportunity) return Response.json({ error: 'Opportunity not found' }, { status: 404 });

    // Credit metering.
    const creditCheck = await consumeCredits(base44, CREDIT_COSTS.opportunity_analysis);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits. Upgrade your plan to analyze opportunities.' }, { status: 402 });
    }

    await base44.entities.ContractOpportunity.update(opportunity_id, { status: 'analyzing' });

    // Ensure status is reset if anything below fails — prevents stuck "analyzing" state.
    resetStatus = () => base44.entities.ContractOpportunity.update(opportunity_id, { status: 'discovered' }).catch(() => {});

    // Load the company profile for gap analysis.
    const profiles = await base44.entities.CompanyProfile.list('-created_date', 1);
    const profile = profiles[0] || {};

    // Gather the solicitation text — from an uploaded file, or by fetching the opportunity URL.
    let solicitationText = '';
    if (uploaded_file_url) {
      const extracted = await base44.asServiceRole.integrations.Core.ExtractDataFromUploadedFile({
        file_url: uploaded_file_url,
        json_schema: { type: "object", properties: { content: { type: "string" } } }
      });
      solicitationText = extracted.output?.content || JSON.stringify(extracted.output || {});
    } else if (opportunity.solicitation_url) {
      // SSRF protection — only fetch https URLs on sam.gov domains.
      try {
        const parsed = new URL(opportunity.solicitation_url);
        const host = parsed.hostname.toLowerCase();
        const isSamGov = host === 'sam.gov' || host.endsWith('.sam.gov');
        if (parsed.protocol !== 'https:' || !isSamGov) {
          solicitationText = '';
        } else {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 15000);
          const docRes = await fetch(parsed.href, { signal: controller.signal });
          clearTimeout(timeout);
          solicitationText = (await docRes.text()).slice(0, 20000);
        }
      } catch {
        solicitationText = '';
      }
    }

    // Fall back to the opportunity description if no document was available.
    if (!solicitationText) {
      solicitationText = opportunity.description || 'No solicitation document available — analyze based on the opportunity title and description only.';
    }

    const analysisPrompt = `You are Trinity, an expert federal contracting proposal strategist. Analyze the following government solicitation and produce a structured breakdown for the user.

SOLICITATION:
Title: ${opportunity.title}
Agency: ${opportunity.agency}
NAICS: ${(opportunity.naics_codes || []).join(', ')}
Deadline: ${opportunity.response_deadline || 'N/A'}

SOLICITATION DOCUMENT:
${solicitationText}

COMPANY PROFILE:
- Name: ${profile.business_name || 'N/A'}
- NAICS: ${(profile.naics_codes || []).join(', ')}
- Capabilities: ${profile.capabilities_narrative || 'N/A'}
- Certifications: ${(profile.certifications || []).join(', ')}
- Past Performance: ${JSON.stringify(profile.past_performance || [])}
- Differentiators: ${profile.differentiators || 'N/A'}

Produce a JSON object with:
- required_qualifications: array of strings (what the contractor must have to bid)
- evaluation_criteria: array of strings (how proposals will be scored)
- submission_deadline: string (the response deadline if found)
- required_forms: array of strings (forms that must be submitted)
- page_limits: string (any page limit requirements)
- technical_requirements: array of strings (key technical scope items)
- gap_analysis: object with strengths (array), weaknesses (array), missing (array) — comparing the company profile to the solicitation requirements
- win_strategy: string (2-3 paragraph strategy for how this company can win, grounded in their strengths and differentiators)`;

    const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: analysisPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          required_qualifications: { type: "array", items: { type: "string" } },
          evaluation_criteria: { type: "array", items: { type: "string" } },
          submission_deadline: { type: "string" },
          required_forms: { type: "array", items: { type: "string" } },
          page_limits: { type: "string" },
          technical_requirements: { type: "array", items: { type: "string" } },
          gap_analysis: {
            type: "object",
            properties: {
              strengths: { type: "array", items: { type: "string" } },
              weaknesses: { type: "array", items: { type: "string" } },
              missing: { type: "array", items: { type: "string" } }
            }
          },
          win_strategy: { type: "string" }
        }
      }
    });

    await base44.entities.ContractOpportunity.update(opportunity_id, {
      analysis,
      status: 'analyzed'
    });

    recordActivity(base44,user,'analysis',`AI solicitation analysis completed: ${opportunity.title}`,'ContractOpportunity',opportunity_id,{status:'completed'});
    return Response.json({ success: true, analysis });
  } catch (error) {
    await resetStatus();
    return Response.json({ error: error.message }, { status: 500 });
  }
}