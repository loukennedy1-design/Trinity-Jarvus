import React, { useState, useEffect } from 'react';
import { Outlet, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ConversationProvider } from '@/lib/ConversationContext';
import ChatSidebar from '@/components/ChatSidebar';
import { Menu } from 'lucide-react';

export default function Layout() {
  const [user, setUser] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isAdmin = user?.role === 'admin';

  return (
    <ConversationProvider>
      <div className="h-screen aurora-bg flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex w-64 flex-col border-r border-border bg-sidebar/40 backdrop-blur-xl flex-shrink-0">
          <ChatSidebar isAdmin={isAdmin} />
        </aside>

        {/* Mobile Sidebar */}
        {mobileOpen && (
          <div className="md:hidden fixed inset-0 z-50">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            <aside className="absolute inset-y-0 left-0 w-64 bg-sidebar border-r border-border flex flex-col animate-fade-in">
              <ChatSidebar isAdmin={isAdmin} onNavigate={() => setMobileOpen(false)} />
            </aside>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 min-w-0 flex flex-col">
          {/* Mobile Header */}
          <header className="md:hidden flex items-center justify-between p-4 border-b border-border bg-card/40 backdrop-blur-xl sticky top-0 z-30 flex-shrink-0">
            <button
              onClick={() => setMobileOpen(true)}
              className="p-2 rounded-lg hover:bg-accent transition-colors"
            >
              <Menu className="w-5 h-5 text-foreground" />
            </button>
            <Link to="/" className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-chart-4 animate-orb-pulse" />
              <span className="font-heading text-lg font-semibold text-foreground">Trinity</span>
            </Link>
            <div className="w-9" />
          </header>

          <main className="flex-1 overflow-hidden min-h-0">
            <Outlet />
          </main>
        </div>
      </div>
    </ConversationProvider>
  );
}