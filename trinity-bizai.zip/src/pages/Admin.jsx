import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import StatCard from '@/components/StatCard';
import TrinityOrb from '@/components/TrinityOrb';
import AdminRevenue from '@/components/admin/AdminRevenue';
import AdminUserTable from '@/components/admin/AdminUserTable';
import AdminSystemPanel from '@/components/admin/AdminSystemPanel';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { AGENT_CATALOG, TIER_INFO } from '@/lib/agentCatalog';
import { Users, DollarSign, Brain, BookOpen, Database, Shield, AlertCircle, Check, X, Server, Cpu } from 'lucide-react';

export default function Admin() {
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    users: [], subscriptions: [], knowledge: [], connections: [], trainingJobs: [], agents: []
  });

  useEffect(() => {
    loadAdmin();
  }, []);

  const loadAdmin = async () => {
    try {
      const me = await base44.auth.me();
      setUser(me);
      const admin = me?.role === 'admin';
      setIsAdmin(admin);

      if (admin) {
        const [allUsers, subs, kb, conns, jobs, agents] = await Promise.all([
          base44.entities.User.list('-created_date', 100),
          base44.entities.Subscription.list('-created_date', 100),
          base44.entities.KnowledgeBase.list('-created_date', 100),
          base44.entities.Connection.list('-created_date', 100),
          base44.entities.TrainingJob.list('-created_date', 50),
          base44.entities.Agent.list('-created_date', 50)
        ]);
        setData({ users: allUsers, subscriptions: subs, knowledge: kb, connections: conns, trainingJobs: jobs, agents });
      }
    } catch (err) {
      console.error('Admin load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleAgentActive = async (agent) => {
    try {
      await base44.entities.Agent.update(agent.id, { is_active: !agent.is_active });
      setData(prev => ({ ...prev, agents: prev.agents.map(a => a.id === agent.id ? { ...a, is_active: !a.is_active } : a) }));
    } catch (err) {
      console.error('Toggle failed:', err);
    }
  };

  // Compute stats
  const proCount = data.subscriptions.filter(s => s.tier === 'pro' && s.status === 'active').length;
  const entCount = data.subscriptions.filter(s => s.tier === 'enterprise' && s.status === 'active').length;
  const mrr = proCount * TIER_INFO.pro.price + entCount * TIER_INFO.enterprise.price;
  const entityCounts = {
    User: data.users.length,
    Agent: data.agents.length,
    KnowledgeBase: data.knowledge.length,
    Connection: data.connections.length,
    Subscription: data.subscriptions.length,
    TrainingJob: data.trainingJobs.length
  };

  if (loading) {
    return (
      <div className="aurora-bg h-full flex items-center justify-center">
        <TrinityOrb size={80} />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="aurora-bg h-full flex items-center justify-center px-6">
        <div className="glass-card rounded-2xl p-8 text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h2 className="font-heading text-xl font-semibold text-foreground mb-2">Admin Access Required</h2>
          <p className="text-muted-foreground">
            You need administrator privileges to access the Trinity AI admin dashboard.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="aurora-bg h-full overflow-y-auto scrollbar-thin px-6 md:px-12 py-8 md:py-12">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-7 h-7 text-primary" />
          <div>
            <h1 className="font-heading text-2xl font-semibold text-foreground">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground">System overview, users, revenue, and platform functions</p>
          </div>
        </div>

        <Tabs defaultValue="overview">
          <TabsList className="grid grid-cols-4 w-full mb-6 bg-card/40 border border-border/50">
            <TabsTrigger value="overview" className="text-sm">Overview</TabsTrigger>
            <TabsTrigger value="users" className="text-sm">Users</TabsTrigger>
            <TabsTrigger value="revenue" className="text-sm">Revenue</TabsTrigger>
            <TabsTrigger value="system" className="text-sm">System</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard icon={Users} label="Total Users" value={data.users.length} accent="primary" />
              <StatCard icon={DollarSign} label="Monthly Revenue" value={`$${mrr.toLocaleString()}`} accent="chart-2" />
              <StatCard icon={BookOpen} label="Knowledge Entries" value={data.knowledge.length} accent="chart-4" />
              <StatCard icon={Server} label="Training Jobs" value={data.trainingJobs.length} accent="chart-5" />
            </div>

            {/* Agent Governance */}
            <div className="glass-card rounded-2xl p-6">
              <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <Brain className="w-5 h-5 text-primary" />
                Agent Governance
              </h2>
              {data.agents.length === 0 ? (
                <div className="space-y-2">
                  {AGENT_CATALOG.map((agent) => (
                    <div key={agent.slug} className="flex items-center gap-3 p-3 rounded-xl bg-accent/20">
                      <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${agent.gradient} flex items-center justify-center`}>
                        <Brain className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{agent.name}</p>
                        <p className="text-xs text-muted-foreground">{agent.tagline}</p>
                      </div>
                      <span className="text-xs px-2 py-1 rounded-full bg-primary/15 text-primary border border-primary/20">Active</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {data.agents.map((agent) => (
                    <div key={agent.id} className="flex items-center gap-3 p-3 rounded-xl bg-accent/20">
                      <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
                        <Brain className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{agent.name}</p>
                        <p className="text-xs text-muted-foreground">{agent.tagline}</p>
                      </div>
                      <button
                        onClick={() => toggleAgentActive(agent)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          agent.is_active ? 'bg-primary/15 text-primary border border-primary/20' : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {agent.is_active ? <><Check className="w-3 h-3" /> Active</> : <><X className="w-3 h-3" /> Inactive</>}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Stats */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="glass-card rounded-2xl p-5">
                <Cpu className="w-6 h-6 text-primary mb-3" />
                <h3 className="font-heading text-base font-semibold text-foreground mb-2">Platform Resources</h3>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Active connections</span><span className="text-foreground">{data.connections.filter(c => c.status === 'connected').length}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Paying subscribers</span><span className="text-foreground">{proCount + entCount}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Completed training jobs</span><span className="text-foreground">{data.trainingJobs.filter(j => j.status === 'completed').length}</span></div>
                </div>
              </div>
              <div className="glass-card rounded-2xl p-5">
                <Database className="w-6 h-6 text-chart-2 mb-3" />
                <h3 className="font-heading text-base font-semibold text-foreground mb-2">Data Storage</h3>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Knowledge entries</span><span className="text-foreground">{data.knowledge.length}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Subscription records</span><span className="text-foreground">{data.subscriptions.length}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Total entity records</span><span className="text-foreground">{Object.values(entityCounts).reduce((a, b) => a + b, 0)}</span></div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <AdminUserTable users={data.users} subscriptions={data.subscriptions} />
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue">
            <AdminRevenue subscriptions={data.subscriptions} userCount={data.users.length} />
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system">
            <AdminSystemPanel entityCounts={entityCounts} trainingJobs={data.trainingJobs} connections={data.connections} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}