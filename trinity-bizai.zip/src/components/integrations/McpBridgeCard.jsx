import React, { useState } from 'react';
import { Network, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AxisLinkPanel from '@/components/integrations/AxisLinkPanel';

export default function McpBridgeCard({ integration }) {
  const [copied, setCopied] = useState(false);
  const serverUrl = new URL('/api/mcp', window.location.origin).toString();

  const copy = async () => {
    await navigator.clipboard.writeText(serverUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Network className="w-5 h-5 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold text-foreground truncate">{integration.name}</h3>
          <p className="text-sm text-muted-foreground mt-0.5">{integration.description}</p>
        </div>
      </div>

      <div className="space-y-1.5">
        <p className="text-xs font-medium text-foreground/80">Trinity → Axis</p>
        <AxisLinkPanel />
      </div>

      <div className="space-y-1.5 border-t border-border/40 pt-3">
        <p className="text-xs font-medium text-foreground/80">Axis → Trinity</p>
        <div className="rounded-lg bg-accent/30 border border-border/50 px-3 py-2 flex items-center gap-2">
          <code className="text-xs text-foreground/80 truncate flex-1 font-mono">{serverUrl}</code>
          <Button variant="ghost" size="icon" onClick={copy} className="h-7 w-7 flex-shrink-0" aria-label="Copy Trinity MCP address">
            {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground/80">Axis signs in to Trinity at this address the same way.</p>
      </div>
    </div>
  );
}