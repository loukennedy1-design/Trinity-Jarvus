import React from 'react';
import { Brain, Code, Database, Zap, CheckCircle2, XCircle, Loader2, FileText } from 'lucide-react';

const BACKEND_FUNCTIONS = [
  { name: 'queryKnowledge', description: 'Semantic search over the knowledge base using LLM ranking', path: 'base44/functions/queryKnowledge/entry.ts' },
  { name: 'trainAgent', description: 'Processes uploaded documents into knowledge base entries', path: 'base44/functions/trainAgent/entry.ts' },
  { name: 'gatherKnowledge', description: 'Gathers knowledge from Claude, GPT-5 & Gemini (10 credits)', path: 'base44/functions/gatherKnowledge/entry.ts' },
  { name: 'speakResponse', description: 'Generates Trinity\'s spoken voice output (1 credit)', path: 'base44/functions/speakResponse/entry.ts' },
  { name: 'consumeChatMessage', description: 'Enforces the free-tier 50-message monthly cap', path: 'base44/functions/consumeChatMessage/entry.ts' },
  { name: 'createCheckout', description: 'Creates a Square checkout link for plan upgrades', path: 'base44/functions/createCheckout/entry.ts' },
  { name: 'fulfillCheckout', description: 'Verifies Square payment and activates the paid tier', path: 'base44/functions/fulfillCheckout/entry.ts' },
  { name: 'resetCredits', description: 'Monthly credit & message counter reset (workflow)', path: 'base44/functions/resetCredits/entry.ts' }
];

const AGENT_CONFIGS = [
  { name: 'trinity_core', file: 'trinity_core.jsonc', description: 'Main business AI' },
  { name: 'strategy_agent', file: 'strategy_agent.jsonc', description: 'Strategic expertise' },
  { name: 'research_agent', file: 'research_agent.jsonc', description: 'Financial & market expertise' },
  { name: 'ops_agent', file: 'ops_agent.jsonc', description: 'Operational expertise' }
];

const ENTITY_TYPES = [
  { name: 'User', icon: 'Users', description: 'Platform users' },
  { name: 'Agent', icon: 'Brain', description: 'Agent catalog entries' },
  { name: 'KnowledgeBase', icon: 'BookOpen', description: 'Knowledge entries' },
  { name: 'Connection', icon: 'Link2', description: 'OAuth connections' },
  { name: 'Subscription', icon: 'CreditCard', description: 'Subscription records' },
  { name: 'TrainingJob', icon: 'FileText', description: 'Training job records' }
];

export default function AdminSystemPanel({ entityCounts, trainingJobs, connections }) {
  return (
    <div className="space-y-6">
      {/* Entity Overview */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          Data Entities
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {ENTITY_TYPES.map((entity) => (
            <div key={entity.name} className="bg-accent/20 rounded-xl p-4 border border-border/30">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">{entity.name}</p>
                <p className="font-heading text-xl font-bold text-primary">{entityCounts[entity.name] ?? '—'}</p>
              </div>
              <p className="text-xs text-muted-foreground">{entity.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Backend Functions */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Code className="w-5 h-5 text-primary" />
          Backend Functions
        </h3>
        <div className="space-y-2">
          {BACKEND_FUNCTIONS.map((fn) => (
            <div key={fn.name} className="flex items-start gap-3 p-3 rounded-xl bg-accent/20">
              <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0">
                <Zap className="w-4.5 h-4.5 text-primary" style={{ width: 18, height: 18 }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground font-mono">{fn.name}()</p>
                <p className="text-xs text-muted-foreground mt-0.5">{fn.description}</p>
                <p className="text-xs text-muted-foreground/50 mt-1 font-mono truncate">{fn.path}</p>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-primary/15 text-primary border border-primary/20 whitespace-nowrap">Deployed</span>
            </div>
          ))}
        </div>
      </div>

      {/* Agent Configs */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          Agent Configurations
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          {AGENT_CONFIGS.map((agent) => (
            <div key={agent.name} className="flex items-center gap-3 p-3 rounded-xl bg-accent/20">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center flex-shrink-0">
                <Brain className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground font-mono">{agent.name}</p>
                <p className="text-xs text-muted-foreground">{agent.description}</p>
                <p className="text-xs text-muted-foreground/50 font-mono truncate">{agent.file}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Training Jobs */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          Training Jobs ({trainingJobs.length})
        </h3>
        {trainingJobs.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No training jobs yet.</p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-thin">
            {trainingJobs.map((job) => (
              <div key={job.id} className="flex items-center gap-3 p-3 rounded-xl bg-accent/20">
                {job.status === 'processing' || job.status === 'queued' ? (
                  <Loader2 className="w-4 h-4 text-primary animate-spin flex-shrink-0" />
                ) : job.status === 'completed' ? (
                  <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-destructive flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{job.agent_name} · {job.document_count} doc(s)</p>
                  {job.summary && <p className="text-xs text-muted-foreground truncate">{job.summary}</p>}
                </div>
                <span className={`text-xs capitalize ${job.status === 'completed' ? 'text-primary' : job.status === 'failed' ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {job.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Connections */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          All Connections ({connections.length})
        </h3>
        {connections.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No connections configured.</p>
        ) : (
          <div className="space-y-2">
            {connections.map((conn) => (
              <div key={conn.id} className="flex items-center gap-3 p-3 rounded-xl bg-accent/20">
                <div className={`w-2.5 h-2.5 rounded-full ${conn.status === 'connected' ? 'bg-primary' : 'bg-muted'}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{conn.display_name}</p>
                  <p className="text-xs text-muted-foreground">{conn.items_synced || 0} items synced</p>
                </div>
                <span className={`text-xs capitalize ${conn.status === 'connected' ? 'text-primary' : 'text-muted-foreground'}`}>
                  {conn.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}