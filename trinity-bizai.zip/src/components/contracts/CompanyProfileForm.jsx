import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Building2, Loader2, Plus, X } from 'lucide-react';
import { Link } from 'react-router-dom';

const CERT_OPTIONS = ['8a', 'HUBZone', 'SDVOSB', 'WOSB', 'small_business', 'EDWOSB'];

export default function CompanyProfileForm({ onSaved, hideApiKey = false }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    business_name: '', uei: '', naics_codes: [], psc_codes: [],
    capabilities_narrative: '', certifications: [], differentiators: '',
    teaming_partners: [], past_performance: []
  });
  const [naicsInput, setNaicsInput] = useState('');
  const [pscInput, setPscInput] = useState('');

  useEffect(() => { loadProfile(); }, []);

  const loadProfile = async () => {
    try {
      const user = await base44.auth.me();
      const list = await base44.entities.CompanyProfile.filter({ created_by_id: user.id }, '-created_date', 1);
      if (list.length) {
        setProfile(list[0]);
        setForm(f => ({ ...f, ...list[0] }));
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const updates = Object.fromEntries(['business_name','uei','naics_codes','psc_codes','capabilities_narrative','certifications','differentiators','teaming_partners','past_performance'].map(key => [key, form[key]]));

      if (profile) {
        await base44.entities.CompanyProfile.update(profile.id, updates);
      } else {
        const created = await base44.entities.CompanyProfile.create(updates);
        setProfile(created);
      }
      onSaved?.();
    } catch (e) { setError(e.message); }
    finally { setSaving(false); }
  };

  const toggleCert = (c) => {
    setForm(f => ({
      ...f,
      certifications: f.certifications.includes(c)
        ? f.certifications.filter(x => x !== c)
        : [...f.certifications, c]
    }));
  };

  const addNaics = () => {
    if (naicsInput && !form.naics_codes.includes(naicsInput)) {
      setForm(f => ({ ...f, naics_codes: [...f.naics_codes, naicsInput] }));
    }
    setNaicsInput('');
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Building2 className="w-6 h-6 text-primary" />
        <div>
          <h2 className="font-heading text-xl font-semibold text-foreground">Company Profile</h2>
          <p className="text-sm text-muted-foreground">Trinity uses this to find contracts and write proposals tailored to your business.</p>
        </div>
      </div>

      <div className="glass-card rounded-2xl p-6 space-y-4">
        <div>
          <Label>Legal Business Name *</Label>
          <Input value={form.business_name} onChange={e => setForm({ ...form, business_name: e.target.value })} placeholder="Acme Defense Solutions LLC" className="bg-background/50" />
        </div>
        <div>
          <Label>UEI (Unique Entity ID)</Label>
          <Input value={form.uei || ''} onChange={e => setForm({ ...form, uei: e.target.value })} placeholder="Your SAM.gov UEI" className="bg-background/50" />
        </div>
        <div>
          <Label>NAICS Codes</Label>
          <div className="flex gap-2 mb-2">
            <Input value={naicsInput} onChange={e => setNaicsInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addNaics())} placeholder="541512" className="bg-background/50" />
            <Button onClick={addNaics} size="sm" variant="outline"><Plus className="w-4 h-4" /></Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {form.naics_codes.map(c => (
              <Badge key={c} variant="secondary" className="gap-1">{c}<X className="w-3 h-3 cursor-pointer" onClick={() => setForm({ ...form, naics_codes: form.naics_codes.filter(x => x !== c) })} /></Badge>
            ))}
          </div>
        </div>
        <div>
          <Label>Capabilities Narrative</Label>
          <Textarea value={form.capabilities_narrative} onChange={e => setForm({ ...form, capabilities_narrative: e.target.value })} placeholder="Describe your core services and capabilities..." rows={4} className="bg-background/50" />
        </div>
        <div>
          <Label>Certifications</Label>
          <div className="flex flex-wrap gap-2 mt-1">
            {CERT_OPTIONS.map(c => (
              <button key={c} onClick={() => toggleCert(c)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${form.certifications.includes(c) ? 'bg-primary/15 text-primary border-primary/30' : 'bg-muted/30 text-muted-foreground border-border hover:border-primary/20'}`}>{c}</button>
            ))}
          </div>
        </div>
        <div>
          <Label>Differentiators</Label>
          <Textarea value={form.differentiators} onChange={e => setForm({ ...form, differentiators: e.target.value })} placeholder="What sets you apart from competitors?" rows={2} className="bg-background/50" />
        </div>
      </div>

      {!hideApiKey && <div className="glass-card rounded-2xl p-6 text-sm"><p className="text-muted-foreground mb-2">SAM.gov keys are managed separately and stored encrypted.</p><Link to="/government-connections" className="text-primary underline">Manage Government Connections →</Link></div>}

      {error && <p role="alert" className="text-destructive">{error}</p>}
      <Button onClick={save} disabled={saving || !form.business_name} className="w-full">
        {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</> : 'Save Company Profile'}
      </Button>
    </div>
  );
}