import React, { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { FileText } from 'lucide-react';
import BusinessPage from '@/components/business/BusinessPage';
import useBusinessData from '@/components/business/useBusinessData';
import ProposalWorkspace from '@/components/business/ProposalWorkspace';
import { Input } from '@/components/ui/input';
export default function Proposals() {
  const { data, isLoading, error, refetch } = useBusinessData();
  const [params, setParams] = useSearchParams(); const [search,setSearch] = useState(''); const [status,setStatus] = useState('all');
  const selected = data?.proposals.find(p => p.id === params.get('id'));
  const list = (data?.proposals || []).filter(p => (status === 'all' || p.overall_status === status) && (p.opportunity_title || '').toLowerCase().includes(search.toLowerCase()));
  return <BusinessPage title="Proposal Library" subtitle="Review, edit, and finalize your drafted bids." icon={FileText} loading={isLoading} error={error}>
    {selected ? <ProposalWorkspace proposal={selected} opportunity={data.opportunities.find(o => o.id === selected.opportunity_id)} onBack={() => { setParams({}); refetch(); }} /> : <><div className="flex flex-wrap gap-3"><Input aria-label="Search proposals" placeholder="Search proposal titles…" value={search} onChange={e=>setSearch(e.target.value)} className="max-w-sm" /><select aria-label="Filter proposal status" className="bg-card border rounded-lg px-3" value={status} onChange={e=>setStatus(e.target.value)}>{['all','drafting','in_review','approved','submitted'].map(s=><option key={s} value={s}>{s.replaceAll('_',' ')}</option>)}</select></div>
    {!list.length && <div className="glass-card rounded-2xl p-10 text-center"><p className="text-muted-foreground">No proposals match this view.</p><Link className="text-primary" to="/contracts">Find a contract and draft your first bid →</Link></div>}
    <div className="space-y-3">{list.map(p=><button key={p.id} onClick={()=>setParams({id:p.id})} className="w-full text-left glass-card rounded-2xl p-5 flex flex-wrap justify-between gap-3 hover:border-primary/40"><div><h2 className="font-semibold">{p.opportunity_title || 'Untitled proposal'}</h2><p className="text-sm text-muted-foreground">Updated {new Date(p.updated_date).toLocaleDateString()} · {Object.keys(p.sections || {}).length} sections</p></div><span className="text-primary text-sm">{p.overall_status.replaceAll('_',' ')} · Open →</span></button>)}</div></>}
  </BusinessPage>;
}