import React, {useState} from 'react';
import {useQuery, useQueryClient} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {ShieldCheck, Loader2} from 'lucide-react';
import {base44} from '@/api/base44Client';
import BusinessPage from '@/components/business/BusinessPage';
import {Input} from '@/components/ui/input';
import {Button} from '@/components/ui/button';
export default function GovernmentConnections() {
  const [key,setKey]=useState('');const [busy,setBusy]=useState('');const [failure,setFailure]=useState('');const [notice,setNotice]=useState('');const client=useQueryClient();
  const {data,isLoading,error,refetch}=useQuery({queryKey:['government-connection'],queryFn:async()=>{const response=await base44.functions.invoke('manageGovernmentConnection',{action:'status'});if(response.data.error)throw new Error(response.data.error);return response.data;}});
  const perform=async action=>{if(action==='disconnect' && !window.confirm('Remove your saved SAM.gov key? Contract discovery will stop until you reconnect.'))return;setBusy(action);setFailure('');setNotice('');try{const response=await base44.functions.invoke('manageGovernmentConnection',{action,...(action==='save'?{api_key:key.trim()}:{})});if(response.data.error)throw new Error(response.data.error);if(action==='save')setKey('');setNotice(response.data.message || 'Connection updated.');await refetch();await client.invalidateQueries({queryKey:['business-data']});}catch(e){setFailure(e.response?.data?.error || e.message);if(action==='test')await refetch();}finally{setBusy('');}};
  const submit=e=>{e.preventDefault();perform('save');};
  const labels={not_set:'Not connected',saved:'Key saved — not yet tested',connected:'Connected',invalid:'Key needs attention'};
  return <BusinessPage title="Government Connections" subtitle="Securely connect your SAM.gov account for official opportunity discovery." icon={ShieldCheck} loading={isLoading} error={error}>
    <section className="glass-card rounded-2xl p-6 max-w-2xl space-y-5"><header className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold">SAM.gov</h2><p className={data?.status==='connected'?'text-primary text-sm':'text-muted-foreground text-sm'}>{labels[data?.status] || labels.not_set}</p></header>
      <p className="text-sm text-muted-foreground">Your key is encrypted before storage and never returned to your browser. Testing sends one request to the official SAM.gov API; SAM.gov daily limits apply. No Trinity search credits are charged for a connection test.</p>
      {data?.validated_at && <p className="text-sm text-muted-foreground">Last test: {new Date(data.validated_at).toLocaleString()}</p>}
      <form onSubmit={submit} className="space-y-3"><label htmlFor="sam-key" className="block text-sm font-medium">{data?.configured?'Replace your API key':'SAM.gov API key'}</label><Input id="sam-key" type="password" autoComplete="off" spellCheck={false} minLength={16} maxLength={512} required value={key} onChange={e=>setKey(e.target.value)} placeholder="Paste your SAM.gov public API key" disabled={!!busy} />
        <div className="flex flex-wrap gap-3"><Button disabled={!!busy || key.trim().length<16}>{busy==='save'?<><Loader2 className="animate-spin"/>Saving…</>:data?.configured?'Replace Key':'Save Key'}</Button><Button type="button" variant="outline" disabled={!!busy || !data?.configured} onClick={()=>perform('test')}>{busy==='test'?<><Loader2 className="animate-spin"/>Testing…</>:'Test Connection'}</Button>{data?.configured && <Button type="button" variant="ghost" disabled={!!busy} onClick={()=>perform('disconnect')}>Disconnect</Button>}</div>
      </form>{failure && <p role="alert" className="text-destructive text-sm">{failure}</p>}{notice && <p role="status" className="text-primary text-sm">{notice}</p>}
      <p className="text-sm text-muted-foreground">Get your public API key from your SAM.gov Account Details. Never enter your SAM.gov password here.</p><div className="flex flex-wrap gap-4 text-sm"><a href="https://sam.gov" target="_blank" rel="noreferrer" className="text-primary underline">Open SAM.gov ↗</a><a href="https://open.gsa.gov/api/get-opportunities-public-api/" target="_blank" rel="noreferrer" className="text-primary underline">Official API guidance ↗</a></div>
    </section><div className="flex flex-wrap gap-4 text-sm"><Link to="/settings" className="text-primary">Update company profile →</Link><Link to="/contracts" className="text-primary">Discover contracts →</Link></div>
  </BusinessPage>;
}