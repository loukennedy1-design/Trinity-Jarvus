import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Checks whether the current app user has an active OAuth connection for each
// provided workspace connector id. Connection status is detected by attempting
// to fetch the user's access token — there is no separate "check" API.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'status_all';

    if (action === 'status_all') {
      const ids = Array.isArray(body.ids)
        ? body.ids.filter((i) => typeof i === 'string' && i.length > 0 && i.length < 80)
        : [];
      if (!ids.length) return Response.json({ statuses: {} });

      const results = await Promise.allSettled(ids.map(async (id) => {
        const conn = await Promise.race([
          base44.asServiceRole.connectors.getCurrentAppUserConnection(id),
          new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 8000)),
        ]);
        return { id, connected: !!(conn && conn.accessToken) };
      }));

      const statuses: Record<string, { connected: boolean }> = {};
      results.forEach((r, i) => {
        statuses[ids[i]] = { connected: r.status === 'fulfilled' && !!r.value?.connected };
      });
      return Response.json({ statuses });
    }

    return Response.json({ error: 'Unsupported connection action.' }, { status: 400 });
  } catch {
    return Response.json({ error: 'Connection status could not be checked.' }, { status: 500 });
  }
}