import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';
import { recordActivity } from '../../shared/activity.ts';

const PROPOSAL_SECTIONS = [
  'Executive Summary',
  'Technical Approach',
  'Past Performance',
  'Management Plan',
  'Required Forms'
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { opportunity_id, section_name, regenerate = false } = await req.json();
    if (!opportunity_id) return Response.json({ error: 'opportunity_id required' }, { status: 400 });

    const opportunity = await base44.entities.ContractOpportunity.get(opportunity_id);
    if (!opportunity) return Response.json({ error: 'Opportunity not found' }, { status: 404 });
    if (!opportunity.analysis) return Response.json({ error: 'Analyze the opportunity first before drafting a proposal.' }, { status: 400 });

    // Determine which sections to generate.
    const sectionsToGenerate = section_name ? [section_name] : PROPOSAL_SECTIONS;

    // Credit metering — charge proportional to the number of sections being generated.
    const creditCost = CREDIT_COSTS.proposal_drafting * sectionsToGenerate.length;
    const creditCheck = await consumeCredits(base44, creditCost);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits. Upgrade your plan to draft proposals.' }, { status: 402 });
    }

    // Load the company profile.
    const profiles = await base44.entities.CompanyProfile.list('-created_date', 1);
    const profile = profiles[0] || {};

    // Find or create the proposal record for this opportunity.
    let proposals = await base44.entities.Proposal.filter({ opportunity_id }, '-created_date', 1);
    let proposal = proposals[0];
    if (!proposal) {
      proposal = await base44.entities.Proposal.create({
        opportunity_id,
        opportunity_title: opportunity.title,
        sections: {},
        supporting_docs: [],
        overall_status: 'drafting'
      });
    }

    const updatedSections = { ...(proposal.sections || {}) };

    for (const section of sectionsToGenerate) {
      const draftPrompt = `You are Trinity, an expert federal proposal writer. Write the "${section}" section of a government proposal for the following opportunity. Ground your writing in the company's real capabilities and past performance. Be specific, professional, and persuasive — this is a competitive bid.

OPPORTUNITY:
Title: ${opportunity.title}
Agency: ${opportunity.agency}
Solicitation: ${opportunity.solicitation_number || 'N/A'}

ANALYSIS:
${JSON.stringify(opportunity.analysis)}

COMPANY PROFILE:
- Name: ${profile.business_name || 'N/A'}
- NAICS: ${(profile.naics_codes || []).join(', ')}
- Capabilities: ${profile.capabilities_narrative || 'N/A'}
- Certifications: ${(profile.certifications || []).join(', ')}
- Past Performance: ${JSON.stringify(profile.past_performance || [])}
- Differentiators: ${profile.differentiators || 'N/A'}

Write the ${section} section now. Return a JSON object with a single field "content" containing the full section text in markdown.`;

      const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: draftPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            content: { type: "string" }
          }
        }
      });

      updatedSections[section] = {
        content: result.content || '',
        status: 'draft',
        approved: false
      };
    }

    // Update the proposal and the opportunity status.
    const allApproved = PROPOSAL_SECTIONS.every(s => updatedSections[s]?.approved);
    const overallStatus = allApproved ? 'in_review' : 'drafting';

    await base44.entities.Proposal.update(proposal.id, {
      sections: updatedSections,
      overall_status: overallStatus
    });

    if (overallStatus === 'in_review') {
      await base44.entities.ContractOpportunity.update(opportunity_id, { status: 'drafting_complete' });
    } else if (!regenerate) {
      await base44.entities.ContractOpportunity.update(opportunity_id, { status: 'drafting' });
    }

    recordActivity(base44,user,'proposal',`Proposal drafting completed: ${opportunity.title} (${sectionsToGenerate.length} sections).`,'Proposal',proposal.id,{status:'completed',sections:sectionsToGenerate.length});
    return Response.json({
      success: true,
      proposal_id: proposal.id,
      sections: updatedSections,
      overall_status: overallStatus
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}