import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { INTEGRATIONS, INTEGRATION_CATEGORIES, PARTNER_INTEGRATIONS } from '@/lib/integrationsCatalog';
import BusinessPage from '@/components/business/BusinessPage';
import ConnectorCard from '@/components/integrations/ConnectorCard';
import McpBridgeCard from '@/components/integrations/McpBridgeCard';
import { Globe, Info } from 'lucide-react';

export default function IntegrationsHub() {
  const [authed, setAuthed] = useState(true);
  const [statuses, setStatuses] = useState({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');

  const ids = INTEGRATIONS.map((i) => i.id);

  const fetchStatuses = useCallback(async () => {
    try {
      const res = await base44.functions.invoke('manageAppConnection', { action: 'status_all', ids });
      setStatuses(res.data?.statuses || {});
    } catch {
      setStatuses({});
    } finally {
      setLoading(false);
    }
  }, [ids]);

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (ok) => {
      if (!ok) { setAuthed(false); setLoading(false); return; }
      await fetchStatuses();
    });
  }, [fetchStatuses]);

  const refreshOne = async (id) => {
    try {
      const res = await base44.functions.invoke('manageAppConnection', { action: 'status_all', ids: [id] });
      if (res.data?.statuses) setStatuses((prev) => ({ ...prev, ...res.data.statuses }));
    } catch { /* ignore */ }
  };

  const handleConnect = async (integration) => {
    setBusy(integration.id);
    try {
      const url = await base44.connectors.connectAppUser(integration.id);
      if (!url) { setError(`Could not start the ${integration.name} connection.`); return; }
      const popup = window.open(url, '_blank', 'noopener');
      const timer = setInterval(() => {
        if (!popup || popup.closed) {
          clearInterval(timer);
          refreshOne(integration.id);
        }
      }, 600);
    } catch {
      setError(`Could not connect ${integration.name}. Try again.`);
    } finally {
      setBusy(null);
    }
  };

  const handleDisconnect = async (integration) => {
    setBusy(integration.id);
    try {
      await base44.connectors.disconnectAppUser(integration.id);
      setStatuses((prev) => ({ ...prev, [integration.id]: { connected: false } }));
    } catch {
      setError(`Could not disconnect ${integration.name}.`);
    } finally {
      setBusy(null);
    }
  };

  if (!authed) {
    return (
      <BusinessPage title="Integrations" subtitle="Connect your tools so Trinity can work on your behalf." icon={Globe}>
        <div className="glass-card rounded-2xl p-6 max-w-md">
          <p className="text-sm text-muted-foreground mb-4">Sign in to connect and manage your integrations.</p>
          <button onClick={() => base44.auth.redirectToLogin()} className="text-primary underline">Sign in →</button>
        </div>
      </BusinessPage>
    );
  }

  const connectedCount = Object.values(statuses).filter((s) => s?.connected).length;

  return (
    <BusinessPage
      title="Integrations"
      subtitle="Connect the services Trinity can use on your behalf. Each connection is authorized by you and revocable anytime."
      icon={Globe}
      loading={loading}
      actions={<span className="text-sm text-muted-foreground">{connectedCount} connected</span>}
    >
      <div className="glass-card rounded-2xl p-4 flex items-start gap-3 border-primary/20">
        <Info className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
        <p className="text-sm text-foreground/90">
          These are supported <span className="font-medium">MCP / OAuth</span> connections. Trinity uses each connection only with your permission and only for the actions you request. For services without a connector, Trinity can still research them on the open web from chat.
        </p>
      </div>

      {error && <p role="alert" className="text-destructive text-sm">{error}</p>}

      {INTEGRATION_CATEGORIES.map((category) => (
        <section key={category} className="space-y-3">
          <h2 className="font-heading text-lg font-semibold text-foreground">{category}</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {INTEGRATIONS.filter((i) => i.category === category).map((integration) => (
              <ConnectorCard
                key={integration.id}
                integration={integration}
                status={statuses[integration.id]}
                busy={busy}
                onConnect={handleConnect}
                onDisconnect={handleDisconnect}
              />
            ))}
          </div>
        </section>
      ))}

      <section className="space-y-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Partner Platforms</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {PARTNER_INTEGRATIONS.map((integration) => (
            <McpBridgeCard key={integration.id} integration={integration} />
          ))}
        </div>
      </section>
    </BusinessPage>
  );
}