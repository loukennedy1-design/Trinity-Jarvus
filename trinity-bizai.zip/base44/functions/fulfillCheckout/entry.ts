import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { TIER_LIMITS } from '../../shared/credits.ts';

// Expected payment amounts (cents) per tier — must match createCheckout.
const TIER_PRICES = {
  pro: 1900,
  enterprise: 9900
};

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { tier, order_id } = await req.json();
    if (!tier || !TIER_LIMITS[tier]) return Response.json({ error: 'Invalid tier' }, { status: 400 });
    if (!TIER_PRICES[tier]) return Response.json({ error: 'Invalid tier' }, { status: 400 });
    if (!order_id) return Response.json({ error: 'Missing order_id — payment verification required' }, { status: 400 });

    const accessToken = secrets.get('SQUARE_ACCESS_TOKEN');
    if (!accessToken) return Response.json({ error: 'Payment provider not configured' }, { status: 500 });
    const environment = secrets.get('SQUARE_ENVIRONMENT') || 'sandbox';

    // Always verify the payment against Square before fulfilling.
    const baseUrl = environment === 'production'
      ? 'https://connect.squareup.com'
      : 'https://connect.squareupsandbox.com';
    const verifyRes = await fetch(`${baseUrl}/v2/orders/${order_id}`, {
      headers: { 'Authorization': `Bearer ${accessToken}`, 'Square-Version': '2024-08-21' }
    });
    const verifyData = await verifyRes.json();
    if (!verifyRes.ok) {
      return Response.json({ error: 'Payment verification failed' }, { status: 502 });
    }

    // Verify the order total matches the expected tier price (prevents tier mismatch).
    const expectedAmount = TIER_PRICES[tier];
    const orderTotal = verifyData.order?.total_money?.amount;
    if (orderTotal !== expectedAmount) {
      return Response.json({ error: 'Order amount does not match the selected tier' }, { status: 400 });
    }

    // Verify a tender exists and exactly matches the expected amount (payment actually completed).
    const tenderAmount = verifyData.order?.tenders?.[0]?.amount_money?.amount;
    if (!tenderAmount || tenderAmount !== expectedAmount) {
      return Response.json({ error: 'Payment amount does not match the expected total' }, { status: 400 });
    }

    // Reject refunded or canceled orders.
    if (verifyData.order?.state === 'CANCELED') {
      return Response.json({ error: 'Order was canceled' }, { status: 400 });
    }
    if (verifyData.order?.refunds?.length > 0) {
      return Response.json({ error: 'Order has been refunded' }, { status: 400 });
    }

    // Verify the order belongs to the calling user (bound at createCheckout time).
    const callerSubs = await base44.asServiceRole.entities.Subscription.filter(
      { created_by_id: user.id }, '-created_date', 1
    );
    if (!callerSubs.length || callerSubs[0].pending_order_id !== order_id) {
      return Response.json({ error: 'Order does not belong to the calling user' }, { status: 403 });
    }

    // Replay prevention — reject if this order was already fulfilled for any subscription.
    const alreadyFulfilled = await base44.asServiceRole.entities.Subscription.filter(
      { last_order_id: order_id }, '-created_date', 1
    );
    if (alreadyFulfilled.length > 0) {
      return Response.json({ error: 'This order has already been fulfilled' }, { status: 409 });
    }

    // Fulfill: update (or create) the caller's subscription to the paid tier.
    // Service role is required because Subscription RLS restricts create/update to admins.
    const limits = TIER_LIMITS[tier];
    const now = new Date();
    const renewsAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();

    const subs = await base44.asServiceRole.entities.Subscription.filter(
      { created_by_id: user.id }, '-created_date', 1
    );
    if (subs.length) {
      await base44.asServiceRole.entities.Subscription.update(subs[0].id, {
        tier,
        status: 'active',
        credits_used: 0,
        credits_limit: limits.credits,
        messages_this_period: 0,
        messages_limit: limits.messages,
        renews_at: renewsAt,
        last_order_id: order_id,
        pending_order_id: null
      });
    } else {
      await base44.asServiceRole.entities.Subscription.create({
        tier,
        status: 'active',
        credits_used: 0,
        credits_limit: limits.credits,
        messages_this_period: 0,
        messages_limit: limits.messages,
        started_at: now.toISOString(),
        renews_at: renewsAt,
        last_order_id: order_id,
        pending_order_id: null
      });
    }

    return Response.json({ success: true, tier });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}