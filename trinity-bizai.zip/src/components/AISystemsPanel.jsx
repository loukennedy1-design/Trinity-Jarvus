import React, { useState } from 'react';
import { Brain, Sparkles, Loader2, CheckCircle2, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const AI_SYSTEMS = [
  { name: 'Claude', model: 'claude_sonnet_4_6', color: 'from-orange-500/20 to-amber-500/10', icon: '🧠', role: 'Deep reasoning & analysis' },
  { name: 'GPT-5', model: 'gpt_5_4', color: 'from-emerald-500/20 to-teal-500/10', icon: '⚡', role: 'Broad knowledge & synthesis' },
  { name: 'Gemini', model: 'gemini_3_1_pro', color: 'from-blue-500/20 to-indigo-500/10', icon: '✦', role: 'Real-time web search' }
];

export default function AISystemsPanel() {
  const [gathering, setGathering] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleGather = async () => {
    setGathering(true);
    setError(null);
    setResult(null);
    try {
      const res = await base44.functions.invoke('gatherKnowledge', {});
      setResult(res.data);
    } catch (err) {
      setError(err.message || 'Failed to gather knowledge');
    } finally {
      setGathering(false);
    }
  };

  return (
    <div className="glass-card rounded-2xl p-5 border border-border/60">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          <h3 className="font-heading font-semibold text-foreground">AI Knowledge Network</h3>
        </div>
        <span className="text-xs text-muted-foreground flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          Auto-learning every 6h
        </span>
      </div>

      <p className="text-sm text-muted-foreground mb-4">
        Trinity autonomously connects to the world's leading AI systems, gathers their knowledge, and synthesizes it into her own knowledge base — continuously becoming the smartest business AI.
      </p>

      <div className="grid grid-cols-3 gap-3 mb-4">
        {AI_SYSTEMS.map((sys) => (
          <div key={sys.name} className={`rounded-xl p-3 bg-gradient-to-br ${sys.color} border border-border/40`}>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">{sys.icon}</span>
              <span className="font-medium text-sm text-foreground">{sys.name}</span>
            </div>
            <p className="text-xs text-muted-foreground">{sys.role}</p>
          </div>
        ))}
      </div>

      <button
        onClick={handleGather}
        disabled={gathering}
        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-primary/15 border border-primary/30 text-primary hover:bg-primary/25 disabled:opacity-50 disabled:cursor-not-allowed transition-all text-sm font-medium"
      >
        {gathering ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Gathering knowledge from AI systems...
          </>
        ) : (
          <>
            <Zap className="w-4 h-4" />
            Gather Knowledge Now
          </>
        )}
      </button>

      {result?.success && (
        <div className="mt-3 flex items-start gap-2 p-3 rounded-xl bg-primary/10 border border-primary/20 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="text-foreground font-medium">Learned: {result.topic}</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Synthesized from {result.models_queried?.join(', ')} · Stored in knowledge base
            </p>
          </div>
        </div>
      )}

      {error && (
        <div className="mt-3 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-sm text-destructive">
          {error}
        </div>
      )}
    </div>
  );
}