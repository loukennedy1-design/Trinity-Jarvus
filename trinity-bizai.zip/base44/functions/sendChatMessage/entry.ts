import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { consumeChatMessage } from '../../shared/credits.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { conversation, message, file_urls } = await req.json();
    if (!conversation) return Response.json({ error: 'conversation required' }, { status: 400 });
    if (!message) return Response.json({ error: 'message required' }, { status: 400 });

    // Server-side quota enforcement — the free-tier cap is checked and consumed here,
    // not in the browser, so direct SDK calls cannot bypass it.
    const check = await consumeChatMessage(base44);
    if (!check.allowed) {
      return Response.json({
        error: 'message_limit_reached',
        message: 'You have reached your free monthly message limit.'
      }, { status: 402 });
    }

    try {
      const updated = await base44.agents.addMessage(conversation, {
        role: 'user',
        content: message,
        file_urls: file_urls?.length ? file_urls : undefined,
      });
      return Response.json({ success: true, messages: updated.messages || [] });
    } catch (sendErr) {
      // Refund the consumed message if the user is on a metered plan.
      if (!check.unlimited && check.subscription) {
        await base44.asServiceRole.entities.Subscription.update(
          check.subscription.id,
          { messages_this_period: check.subscription.messages_this_period || 0 }
        ).catch(() => {});
      }
      throw sendErr;
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}