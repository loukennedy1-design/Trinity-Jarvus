import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getSAMCredential, saveSAMCredential, getSAMKey, publicSAMStatus, setSAMStatus, syncSAMProfileStatus } from '../../shared/samCredentials.ts';
import { requestSAM, samFailure } from '../../shared/samClient.ts';
import { recordActivity } from '../../shared/activity.ts';
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({error:'Unauthorized'},{status:401});
    const body = await req.json();
    const action = body.action || 'status';
    if (!['status','save','test','disconnect'].includes(action)) return Response.json({error:'Unsupported connection action.'},{status:400});
    if (action==='save') {
      const value = typeof body.api_key==='string' ? body.api_key.trim() : '';
      if (value.length<16 || value.length>512 || /\s/.test(value)) return Response.json({error:'Enter a SAM.gov public API key between 16 and 512 characters without spaces.'},{status:400});
      const saved = await saveSAMCredential(base44,user,value);
      await syncSAMProfileStatus(base44,user,'saved');
      recordActivity(base44,user,'connection','SAM.gov key saved with encrypted storage.');
      return Response.json({...publicSAMStatus(saved),message:'Key saved securely. Test the connection to verify access.'});
    }
    if (action==='disconnect') {
      await base44.asServiceRole.entities.GovernmentCredential.deleteMany({owner_id:user.id,service:'samgov'});
      await syncSAMProfileStatus(base44,user,'not_set');
      recordActivity(base44,user,'connection','SAM.gov connection removed.');
      return Response.json({...publicSAMStatus(null),message:'SAM.gov disconnected and the saved key removed.'});
    }
    const credential = await getSAMCredential(base44,user);
    if (action==='status') return Response.json(publicSAMStatus(credential));
    if (!credential) return Response.json({error:'Save your SAM.gov key first.'},{status:400});
    if (credential.validated_at && Date.now()-new Date(credential.validated_at).getTime()<30000) return Response.json({error:'Wait 30 seconds between connection tests.'},{status:429});
    const apiKey = await getSAMKey(base44,user,credential);
    let result;
    try { result = await requestSAM(apiKey); }
    catch { return Response.json({error:'SAM.gov could not be reached. Your saved key has not been changed.'},{status:502}); }
    const status = result.ok ? 'connected' : [401,403].includes(result.status) ? 'invalid' : credential.status;
    const updated = await setSAMStatus(base44,user,credential,status);
    recordActivity(base44,user,'connection',result.ok?'SAM.gov connection verified.':'SAM.gov connection test did not succeed.','', '',{status:result.ok?'completed':'failed'});
    if (!result.ok) return Response.json({error:samFailure(result.status),...publicSAMStatus(updated)},{status:result.status===429?429:result.status===401||result.status===403?400:502});
    return Response.json({...publicSAMStatus(updated),message:'Connection verified. You can now search official SAM.gov opportunities.'});
  } catch {
    // Never expose encryption details, credential-bearing URLs, or service responses.
    return Response.json({error:'The connection could not be updated. Please try again or check the encryption setup.'},{status:500});
  }
}