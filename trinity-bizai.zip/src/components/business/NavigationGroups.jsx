import React from 'react';
import { NavLink } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from '@/components/ui/collapsible';
const groups = {
  Business: [['Business Dashboard','/dashboard'],['Analytics Hub','/analytics'],['Performance Metrics','/performance-metrics']],
  Contracts: [['Discover Contracts','/contracts'],['Proposal Library','/proposals'],['Bid Pipeline','/bid-pipeline'],['Compliance Audit','/compliance-audit']],
  Resources: [['Learning Center','/learning-center'],['Support Tickets','/support-tickets'],['Teaming Partners','/teaming-partners'],['Activity Log','/activity-log']],
  Account: [['Company Settings','/settings'],['Integrations','/integrations'],['Government Connections','/government-connections'],['Subscription','/subscription'],['Usage','/usage']]
};
export default function NavigationGroups({ onNavigate }) {
  return <nav aria-label="Business navigation" className="px-3 py-2">{Object.entries(groups).map(([label,links])=><Collapsible key={label} defaultOpen className="mb-2"><CollapsibleTrigger className="w-full min-h-10 px-3 flex items-center justify-between text-xs uppercase tracking-wider text-muted-foreground group">{label}<ChevronDown className="w-4 h-4 transition-transform group-data-[state=closed]:-rotate-90" /></CollapsibleTrigger><CollapsibleContent>{links.map(([name,to])=><NavLink key={to} to={to} onClick={onNavigate} className={({isActive})=>`block rounded-lg px-3 py-2 text-sm min-h-10 ${isActive ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:bg-accent hover:text-foreground'}`}>{name}</NavLink>)}</CollapsibleContent></Collapsible>)}</nav>;
}