import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

export default function AxisCallback() {
  const navigate = useNavigate();
  const [status, setStatus] = useState('working');
  const [message, setMessage] = useState('');
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');
    if (!code || !state) {
      setStatus('error');
      setMessage(params.get('error') === 'access_denied' ? 'Axis access was not approved.' : 'The Axis sign-in did not finish.');
      return;
    }
    base44.functions.invoke('manageAxisLink', { action: 'complete', code, state })
      .then(() => {
        setStatus('done');
        setTimeout(() => navigate('/integrations', { replace: true }), 1200);
      })
      .catch((err) => {
        setStatus('error');
        setMessage(err?.response?.data?.message || 'The Axis connection could not be completed.');
      });
  }, [navigate]);

  return (
    <div className="h-full flex items-center justify-center aurora-bg p-6">
      <div className="glass-card rounded-2xl p-8 max-w-sm w-full text-center space-y-3">
        {status === 'working' && <><Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" /><p className="text-sm text-muted-foreground">Linking Trinity to Axis Business Suite…</p></>}
        {status === 'done' && <><CheckCircle2 className="w-8 h-8 mx-auto text-primary" /><p className="text-sm text-foreground">Connected to Axis. Returning to Integrations…</p></>}
        {status === 'error' && (
          <>
            <AlertCircle className="w-8 h-8 mx-auto text-destructive" />
            <p className="text-sm text-foreground">{message}</p>
            <Link to="/integrations" className="text-sm text-primary underline">Back to Integrations</Link>
          </>
        )}
      </div>
    </div>
  );
}