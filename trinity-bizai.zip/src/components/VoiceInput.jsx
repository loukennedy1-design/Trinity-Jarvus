import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff } from 'lucide-react';

export default function VoiceInput({ onResult, disabled, onListeningChange }) {
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec = new SR();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = 'en-US';
    rec.onresult = (e) => {
      let final = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
      }
      if (final && onResult) onResult(final.trim());
    };
    rec.onend = () => {
      setListening(false);
      if (onListeningChange) onListeningChange(false);
    };
    rec.onerror = () => {
      setListening(false);
      if (onListeningChange) onListeningChange(false);
    };
    recognitionRef.current = rec;
    return () => {
      try { rec.abort(); } catch {}
    };
  }, [onResult, onListeningChange]);

  const toggle = () => {
    if (!recognitionRef.current || disabled) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
      if (onListeningChange) onListeningChange(false);
    } else {
      try {
        recognitionRef.current.start();
        setListening(true);
        if (onListeningChange) onListeningChange(true);
      } catch {}
    }
  };

  if (!supported) return null;

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={disabled}
      className={`p-2.5 rounded-xl transition-all flex-shrink-0 ${
        listening
          ? 'bg-primary/20 text-primary ring-2 ring-primary/50 animate-pulse'
          : 'hover:bg-accent/50 text-muted-foreground'
      }`}
      title={listening ? 'Stop listening' : 'Speak to Trinity'}
      aria-label={listening ? 'Stop voice input' : 'Start voice input'}
    >
      {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
    </button>
  );
}