import React, { useState } from 'react';
import { Search, ChevronUp, ChevronDown, Zap, Calendar } from 'lucide-react';

export default function AdminUserTable({ users, subscriptions }) {
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState('created_date');
  const [sortDir, setSortDir] = useState('desc');

  const subByUser = {};
  subscriptions.forEach(s => {
    if (s.created_by_id && !subByUser[s.created_by_id]) subByUser[s.created_by_id] = s;
  });

  const enriched = users.map(u => ({
    ...u,
    subscription: subByUser[u.id] || null,
    tier: subByUser[u.id]?.tier || 'free',
    credits_used: subByUser[u.id]?.credits_used || 0,
    credits_limit: subByUser[u.id]?.credits_limit || 50,
    sub_status: subByUser[u.id]?.status || 'inactive'
  }));

  const filtered = enriched.filter(u => {
    const q = search.toLowerCase();
    return !q || (u.full_name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q);
  });

  const sorted = [...filtered].sort((a, b) => {
    let aVal = a[sortField], bVal = b[sortField];
    if (sortField === 'tier') {
      const rank = { free: 0, pro: 1, enterprise: 2 };
      aVal = rank[a.tier]; bVal = rank[b.tier];
    }
    if (aVal == null) aVal = '';
    if (bVal == null) bVal = '';
    if (typeof aVal === 'string') aVal = aVal.toLowerCase();
    if (typeof bVal === 'string') bVal = bVal.toLowerCase();
    const result = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
    return sortDir === 'asc' ? result : -result;
  });

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const tierBadge = (tier) => {
    const styles = {
      free: 'bg-muted text-muted-foreground',
      pro: 'bg-primary/15 text-primary border border-primary/20',
      enterprise: 'bg-chart-4/15 text-chart-4 border border-chart-4/20'
    };
    return styles[tier] || styles.free;
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ChevronDown className="w-3 h-3 opacity-30" />;
    return sortDir === 'asc' ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />;
  };

  return (
    <div className="glass-card rounded-2xl p-6">
      {/* Search */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded-xl bg-accent/30 border border-border/50">
          <Search className="w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users by name or email..."
            className="bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none flex-1"
          />
        </div>
        <span className="text-sm text-muted-foreground whitespace-nowrap">{sorted.length} users</span>
      </div>

      {/* Table */}
      <div className="overflow-x-auto scrollbar-thin">
        <table className="w-full">
          <thead>
            <tr className="text-xs text-muted-foreground border-b border-border/50">
              <th className="text-left py-2 px-3 font-medium">
                <button onClick={() => toggleSort('full_name')} className="flex items-center gap-1 hover:text-foreground">User <SortIcon field="full_name" /></button>
              </th>
              <th className="text-left py-2 px-3 font-medium">
                <button onClick={() => toggleSort('role')} className="flex items-center gap-1 hover:text-foreground">Role <SortIcon field="role" /></button>
              </th>
              <th className="text-left py-2 px-3 font-medium">
                <button onClick={() => toggleSort('tier')} className="flex items-center gap-1 hover:text-foreground">Tier <SortIcon field="tier" /></button>
              </th>
              <th className="text-left py-2 px-3 font-medium">Credits</th>
              <th className="text-left py-2 px-3 font-medium">Status</th>
              <th className="text-left py-2 px-3 font-medium">
                <button onClick={() => toggleSort('created_date')} className="flex items-center gap-1 hover:text-foreground">Joined <SortIcon field="created_date" /></button>
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((u) => (
              <tr key={u.id} className="border-b border-border/30 hover:bg-accent/20 transition-colors">
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/40 to-chart-2/40 flex items-center justify-center text-xs font-medium text-foreground flex-shrink-0">
                      {(u.full_name || u.email || '?').charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{u.full_name || 'Unnamed'}</p>
                      <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-3">
                  <span className={`text-xs px-2 py-1 rounded-full ${u.role === 'admin' ? 'bg-primary/15 text-primary border border-primary/20' : 'bg-muted text-muted-foreground'}`}>
                    {u.role || 'user'}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <span className={`text-xs px-2 py-1 rounded-full capitalize ${tierBadge(u.tier)}`}>{u.tier}</span>
                </td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-primary" />
                    <span className="text-xs text-foreground">{u.credits_used} / {u.credits_limit}</span>
                  </div>
                </td>
                <td className="py-3 px-3">
                  <span className={`text-xs ${u.sub_status === 'active' ? 'text-primary' : 'text-muted-foreground'}`}>
                    {u.sub_status}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    {u.created_date ? new Date(u.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}