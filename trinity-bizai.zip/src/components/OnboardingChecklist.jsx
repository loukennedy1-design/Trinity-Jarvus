import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';

// Lightweight setup checklist shown to guide first-use onboarding.
export default function OnboardingChecklist() {
  const [steps, setSteps] = useState({ profile: null, sam: null });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const user = await base44.auth.me();
        const profiles = await base44.entities.CompanyProfile.filter({ created_by_id: user.id }, '-created_date', 1);
        let sam = false;
        try {
          const res = await base44.functions.invoke('manageGovernmentConnection', { action: 'status' });
          sam = res.data?.status === 'connected';
        } catch { /* ignore */ }
        if (!active) return;
        setSteps({ profile: !!profiles[0]?.business_name, sam });
      } catch { /* ignore */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, []);

  const items = [
    { done: steps.profile, label: 'Set up your company profile', to: '/settings' },
    { done: steps.sam, label: 'Connect SAM.gov for contract discovery', to: '/government-connections' },
    { done: false, label: 'Connect your tools (Google, Slack, Outlook…)', to: '/integrations' },
  ];
  const completed = items.filter((i) => i.done).length;

  if (loading) return <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin" /> Checking your setup…</div>;
  if (completed === items.length) return null;

  return (
    <div className="glass-card rounded-2xl p-5 text-left max-w-2xl mx-auto mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-heading font-semibold text-foreground">Finish setting up Trinity</h3>
        <span className="text-xs text-muted-foreground">{completed}/{items.length}</span>
      </div>
      <ul className="space-y-2">
        {items.map((item) => (
          <li key={item.label}>
            <Link to={item.to} className="flex items-center gap-2 text-sm text-foreground/80 hover:text-primary transition-colors">
              {item.done
                ? <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                : <Circle className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
              <span className={item.done ? 'line-through text-muted-foreground' : ''}>{item.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}