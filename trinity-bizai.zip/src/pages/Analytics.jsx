import React from 'react';
import { BarChart3 } from 'lucide-react';
import BusinessPage from '@/components/business/BusinessPage';
import useBusinessData from '@/components/business/useBusinessData';
import AnalyticsCharts from '@/components/business/AnalyticsCharts';
export default function Analytics() {
  const {data,isLoading,error}=useBusinessData(); const rivals=(data?.opportunities || []).filter(o=>o.awarded_to || o.competitor_notes);
  return <BusinessPage title="Analytics Hub" subtitle="Bidding trends and industry outcomes grounded in your recorded results." icon={BarChart3} loading={isLoading} error={error}><AnalyticsCharts opportunities={data?.opportunities || []} /><section className="glass-card rounded-2xl p-6"><h2 className="font-semibold mb-3">Competitor Intelligence</h2><p className="text-sm text-muted-foreground mb-4">User-recorded award recipients and competitive notes, not an external competitor ranking.</p>{rivals.map(o=><div key={o.id} className="border-t py-3"><h3>{o.title}</h3><p className="text-primary text-sm">{o.awarded_to || 'Recipient not recorded'} · {o.outcome || 'pending'}</p><p className="text-sm text-muted-foreground whitespace-pre-wrap">{o.competitor_notes}</p></div>)}{!rivals.length && <p className="text-muted-foreground">Add award recipients and competitor notes to bids in the pipeline.</p>}</section></BusinessPage>;
}