import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { consumeCredits, CREDIT_COSTS } from '../../shared/credits.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const text = (body?.text || '').toString().trim();
    if (!text) return Response.json({ error: 'No text provided' }, { status: 400 });
    if (text.length > 5000) return Response.json({ error: 'Text too long (max 5000 chars)' }, { status: 400 });

    // Credit metering — charge proportional to text length (1 credit per 50 chars, matching platform TTS cost).
    const voiceCost = Math.max(1, Math.ceil(text.length / 50));
    const creditCheck = await consumeCredits(base44, voiceCost);
    if (!creditCheck.allowed) {
      return Response.json({ error: 'out_of_credits', message: 'You are out of credits. Upgrade your plan to enable voice output.' }, { status: 402 });
    }

    // Trinity's voice — "storm" is formal and authoritative, fitting her wise-advisor persona.
    const result = await base44.asServiceRole.integrations.Core.GenerateSpeech({
      text: text.slice(0, 5000),
      voice: 'storm'
    });

    return Response.json({ url: result.url, credits_remaining: creditCheck.remaining });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}