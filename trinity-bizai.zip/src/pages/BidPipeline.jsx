import React, { useState } from 'react';
import { KanbanSquare } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import BusinessPage from '@/components/business/BusinessPage';
import useBusinessData from '@/components/business/useBusinessData';
import BidDetails from '@/components/business/BidDetails';
const columns = ['Discovered','Analyzing','Drafting','Submitted','Outcome'];
export const stage = o => o.outcome && o.outcome !== 'pending' ? 'Outcome' : o.status === 'submitted' ? 'Submitted' : ['drafting','drafting_complete'].includes(o.status) ? 'Drafting' : ['analyzing','analyzed'].includes(o.status) ? 'Analyzing' : 'Discovered';
export default function BidPipeline() {
  const { data, isLoading, error, refetch } = useBusinessData(); const [selected,setSelected] = useState(null); const [busy,setBusy] = useState(false); const [failure,setFailure] = useState('');
  const move = async ({ draggableId, destination }) => {
    if (!destination || busy) return;
    const o = data.opportunities.find(o=>o.id===draggableId);
    if (destination.droppableId === 'Outcome') { setSelected(o); return; }
    setBusy(true); setFailure('');
    try { const status = {Discovered:'discovered',Analyzing:'analyzing',Drafting:'drafting',Submitted:'submitted'}[destination.droppableId];
      await base44.entities.ContractOpportunity.update(o.id,{status,outcome:'pending',...(status==='submitted' ? {submitted_at:o.submitted_at || new Date().toISOString()} : {})});
      if (status === 'submitted') await Promise.all(data.proposals.filter(p=>p.opportunity_id===o.id).map(p=>base44.entities.Proposal.update(p.id,{overall_status:'submitted'})));
      await refetch();
    } catch(e) { setFailure(e.message); } finally { setBusy(false); }
  };
  return <BusinessPage title="Bid Pipeline" subtitle="Move bids through discovery, drafting, submission, and recorded outcomes." icon={KanbanSquare} loading={isLoading} error={error || failure}>
    {selected && <BidDetails opportunity={selected} onClose={()=>setSelected(null)} onSaved={()=>{setSelected(null); refetch();}} />}
    <p className="text-sm text-muted-foreground">Drag cards to update their stage, or open a card to record an outcome. Moving to Submitted records your external submission; it does not submit a bid to the government.</p>
    <DragDropContext onDragEnd={move}><div className="flex gap-4 overflow-x-auto pb-4">{columns.map(col=><Droppable droppableId={col} key={col}>{provided=><section ref={provided.innerRef} {...provided.droppableProps} className="bg-card/70 border rounded-2xl p-3 w-64 flex-shrink-0 min-h-80"><h2 className="font-semibold p-2 mb-2">{col} <span className="text-muted-foreground text-sm">{(data?.opportunities || []).filter(o=>o.status!=='archived' && stage(o)===col).length}</span></h2>{(data?.opportunities || []).filter(o=>o.status!=='archived' && stage(o)===col).map((o,index)=><Draggable draggableId={o.id} index={index} key={o.id} isDragDisabled={busy}>{drag=><div ref={drag.innerRef} {...drag.draggableProps} {...drag.dragHandleProps} className="bg-background border rounded-xl p-4 mb-3"><button className="text-left w-full" onClick={()=>setSelected(o)}><h3 className="text-sm font-semibold">{o.title}</h3><p className="text-xs text-muted-foreground mt-2">{o.agency || 'Agency not specified'}</p><p className="text-xs text-primary mt-2">{col==='Outcome' ? o.outcome : `${o.match_score || 0}% match`} · Open details</p></button></div>}</Draggable>)}{provided.placeholder}{!(data?.opportunities || []).some(o=>o.status!=='archived' && stage(o)===col) && <p className="text-sm text-muted-foreground p-2">No bids in this stage.</p>}</section>}</Droppable>)}</div></DragDropContext>
  </BusinessPage>;
}