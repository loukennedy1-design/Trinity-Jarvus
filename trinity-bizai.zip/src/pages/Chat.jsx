import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useConversation } from '@/lib/ConversationContext';
import ChatMessage from '@/components/ChatMessage';
import ChatInput from '@/components/ChatInput';
import TrinityOrb from '@/components/TrinityOrb';
import { Sparkles, Volume2, VolumeX, BookOpen, Check, Loader2, Globe } from 'lucide-react';
import OnboardingChecklist from '@/components/OnboardingChecklist';

export default function Chat() {
  const { conversation, loading: convLoading } = useConversation();
  const [messages, setMessages] = useState([]);
  const [creating, setCreating] = useState(false);
  const [training, setTraining] = useState(false);
  const [trainingDone, setTrainingDone] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(() => localStorage.getItem('trinity_voice') === 'true');
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceOutOfCredits, setVoiceOutOfCredits] = useState(false);
  const [researchMode, setResearchMode] = useState(false);
  const [researching, setResearching] = useState(false);
  const messagesEndRef = useRef(null);
  const lastSpokenRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(() => {
    if (conversation?.id) {
      setMessages(conversation.messages || []);
      let unsubscribe = () => {};
      try {
        unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
          setMessages(data.messages || []);
        });
      } catch (err) {
        console.error('Subscription failed, using static messages:', err);
      }
      return () => unsubscribe();
    }
  }, [conversation?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (!voiceEnabled) return;
    const last = messages[messages.length - 1];
    if (!last || last.role !== 'assistant' || !last.content) return;
    if (lastSpokenRef.current === last.id) return;
    lastSpokenRef.current = last.id;
    setSpeaking(true);
    base44.functions.invoke('speakResponse', { text: last.content })
      .then((res) => {
        if (res?.data?.error === 'out_of_credits') {
          setSpeaking(false);
          setVoiceOutOfCredits(true);
          return;
        }
        const url = res?.data?.url;
        if (url && audioRef.current) {
          audioRef.current.src = url;
          audioRef.current.play().catch(() => setSpeaking(false));
        } else {
          setSpeaking(false);
        }
      })
      .catch(() => setSpeaking(false));
  }, [messages, voiceEnabled]);

  const handleSend = async (text, files) => {
    if (!conversation || creating) return;
    setCreating(true);
    setTrainingDone(false);
    try {
      // If files attached, train Trinity from them in the background
      if (files.length > 0) {
        setTraining(true);
        try {
          await base44.functions.invoke('trainAgent', {
            file_urls: files.map((f) => f.url),
            agent_slug: 'trinity_core',
            agent_name: 'Trinity',
          });
          setTrainingDone(true);
          setTimeout(() => setTrainingDone(false), 5000);
        } catch (err) {
          console.error('Training failed:', err);
        } finally {
          setTraining(false);
        }
      }

      const fileUrls = files.map((f) => f.url);
      const messageText = files.length > 0 && !text.trim()
        ? `I've uploaded ${files.length === 1 ? 'a document' : `${files.length} documents`} (${files.map((f) => f.name).join(', ')}). Please review and learn from ${files.length === 1 ? 'it' : 'them'}.`
        : text;

      if (researchMode && files.length === 0) {
        setResearching(true);
        setMessages((prev) => [...prev, { role: 'user', content: messageText, id: 'u-' + Date.now() }]);
        try {
          const res = await base44.functions.invoke('runResearchTask', { query: messageText });
          if (res.data?.error === 'out_of_credits') {
            setMessages((prev) => [...prev, { role: 'assistant', content: "You're out of credits. Upgrade to **Pro** for unlimited web research.", id: 'r-' + Date.now() }]);
            return;
          }
          if (res.data?.error) {
            setMessages((prev) => [...prev, { role: 'assistant', content: res.data.message || 'Research could not be completed. Try again later.', id: 'r-' + Date.now() }]);
            return;
          }
          const r = res.data?.research || {};
          const parts = [];
          if (r.summary) parts.push(`**Summary**\n${r.summary}`);
          if (Array.isArray(r.key_findings) && r.key_findings.length) parts.push(`**Key findings**\n${r.key_findings.map((f) => `• ${f}`).join('\n')}`);
          if (Array.isArray(r.recommended_actions) && r.recommended_actions.length) parts.push(`**Recommended actions**\n${r.recommended_actions.map((a) => `• ${a}`).join('\n')}`);
          if (Array.isArray(r.sources) && r.sources.length) parts.push(`**Sources**\n${r.sources.map((s) => `[${s.title}](${s.url})`).join('\n')}`);
          setMessages((prev) => [...prev, { role: 'assistant', content: parts.join('\n\n') || 'No results found.', id: 'r-' + Date.now() }]);
        } catch {
          setMessages((prev) => [...prev, { role: 'assistant', content: 'Research could not be completed. Try again later.', id: 'r-' + Date.now() }]);
        } finally {
          setResearching(false);
        }
        return;
      }

      const result = await base44.functions.invoke('sendChatMessage', {
        conversation,
        message: messageText,
        file_urls: fileUrls.length ? fileUrls : undefined,
      });

      if (result.data?.error === 'message_limit_reached') {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content:
              "You've reached your **free monthly message limit** (50 messages). Upgrade to **Pro** for unlimited chat — visit the Subscription page to upgrade.",
            id: 'limit-' + Date.now(),
          },
        ]);
        return;
      }

      if (result.data?.messages) {
        setMessages(result.data.messages);
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setCreating(false);
    }
  };

  const isAssistantThinking =
    messages.length > 0 && messages[messages.length - 1].role === 'user' && creating;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-6 py-3.5 border-b border-border/50 backdrop-blur-xl bg-card/20 flex-shrink-0">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-9 h-9">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary via-chart-2 to-chart-4 animate-orb-pulse" />
              <Sparkles className="absolute inset-0 m-auto w-4 h-4 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-heading font-semibold text-foreground leading-none">Trinity</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Your business AI</p>
            </div>
          </div>
          <button
            onClick={() =>
              setVoiceEnabled((v) => {
                const next = !v;
                localStorage.setItem('trinity_voice', String(next));
                if (!next && audioRef.current) audioRef.current.pause();
                return next;
              })
            }
            className={`flex items-center gap-2 px-3 py-2 rounded-xl glass-card transition-all text-sm ${
              voiceEnabled ? 'border-primary/50 text-primary' : 'text-foreground hover:border-primary/30'
            }`}
            title={voiceEnabled ? 'Voice output on — click to mute' : 'Voice output off — click to enable'}
            aria-label="Toggle voice output"
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setResearchMode((v) => !v)}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl glass-card transition-all text-sm ${
              researchMode ? 'border-primary/50 text-primary' : 'text-foreground hover:border-primary/30'
            }`}
            title={researchMode ? 'Web research on — your next message searches the live web' : 'Web research off'}
            aria-label="Toggle web research mode"
          >
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Web research</span>
          </button>
        </div>
      </div>

      {/* Research Mode Banner */}
      {researchMode && (
        <div className="px-6 py-2 bg-primary/10 border-b border-primary/20 flex items-center justify-center gap-2">
          <Globe className="w-3.5 h-3.5 text-primary" />
          <p className="text-xs text-primary">
            Web research is on — your next message will search the live web (uses 3 credits).
          </p>
        </div>
      )}
      {researching && (
        <div className="px-6 py-2 bg-primary/10 border-b border-primary/20 flex items-center justify-center gap-2">
          <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
          <p className="text-xs text-primary">Trinity is researching the web…</p>
        </div>
      )}

      {/* Training Indicator */}
      {training && (
        <div className="px-6 py-2 bg-primary/10 border-b border-primary/20 flex items-center justify-center gap-2">
          <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
          <p className="text-xs text-primary">
            Training Trinity from your documents…
          </p>
        </div>
      )}
      {trainingDone && (
        <div className="px-6 py-2 bg-chart-5/10 border-b border-chart-5/20 flex items-center justify-center gap-2">
          <Check className="w-3.5 h-3.5 text-chart-5" />
          <p className="text-xs text-chart-5">
            Trinity has learned from your documents. Ask her about them.
          </p>
        </div>
      )}

      {/* Voice Credits Warning */}
      {voiceOutOfCredits && (
        <div className="px-6 py-2 bg-destructive/10 border-b border-destructive/20 text-center">
          <p className="text-xs text-destructive-foreground/80">
            Voice output paused — you're out of credits.{' '}
            <button onClick={() => setVoiceOutOfCredits(false)} className="underline">
              Dismiss
            </button>
          </p>
        </div>
      )}

      <audio ref={audioRef} onEnded={() => setSpeaking(false)} className="hidden" />

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 md:px-6 py-6 min-h-0">
        <div className="max-w-4xl mx-auto space-y-6">
          {convLoading && !conversation ? (
            <div className="flex flex-col items-center justify-center py-20">
              <TrinityOrb size={100} active />
              <p className="text-muted-foreground mt-6 text-sm">Starting Trinity…</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <TrinityOrb size={120} active={listening || speaking} />
              <h2 className="font-heading text-2xl font-semibold text-foreground mt-8 mb-2">
                How can I help your business today?
              </h2>
              <p className="text-muted-foreground max-w-md mb-6">
                I'm Trinity — an AI versed in business. Ask me about strategy, finance, operations, or
                any business challenge. Upload documents and I'll learn from them.
              </p>
              <OnboardingChecklist />
              <div className="grid sm:grid-cols-2 gap-3 max-w-2xl w-full">
                {suggestions.map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => handleSend(suggestion, [])}
                    className="glass-card rounded-xl p-4 text-left text-sm text-foreground/80 hover:border-primary/30 hover:text-foreground transition-all"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => (
                <ChatMessage key={msg.id || idx} message={msg} />
              ))}
              {isAssistantThinking && (
                <ChatMessage message={{ role: 'assistant', content: '' }} />
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="px-4 md:px-6 py-4 border-t border-border/50 backdrop-blur-xl bg-card/20 flex-shrink-0">
        <div className="max-w-4xl mx-auto">
          <ChatInput onSend={handleSend} disabled={creating || convLoading} onListeningChange={setListening} />
          <p className="text-xs text-muted-foreground/50 text-center mt-2">
            Trinity can search the web, learn from your uploads, and gather knowledge from other AIs.
          </p>
        </div>
      </div>
    </div>
  );
}

const suggestions = [
  'Analyze my business model and suggest improvements',
  'What are the key economic principles I should apply to my company?',
  'How can I scale my operations efficiently?',
  'What metrics should I track for business health?',
];