import React from 'react';
import { DollarSign, TrendingUp, Zap, Crown } from 'lucide-react';
import { TIER_INFO } from '@/lib/agentCatalog';

export default function AdminRevenue({ subscriptions, userCount }) {
  const proCount = subscriptions.filter(s => s.tier === 'pro' && s.status === 'active').length;
  const entCount = subscriptions.filter(s => s.tier === 'enterprise' && s.status === 'active').length;
  const freeCount = Math.max(0, userCount - proCount - entCount);

  const mrr = proCount * TIER_INFO.pro.price + entCount * TIER_INFO.enterprise.price;
  const arpu = userCount > 0 ? (mrr / userCount).toFixed(2) : '0.00';
  const totalCreditsUsed = subscriptions.reduce((sum, s) => sum + (s.credits_used || 0), 0);
  const totalCreditsLimit = subscriptions.reduce((sum, s) => sum + (s.credits_limit || 0), 0);

  const tiers = [
    { key: 'free', label: 'Free', count: freeCount, price: 0, color: 'text-muted-foreground', bg: 'bg-muted' },
    { key: 'pro', label: 'Pro', count: proCount, price: TIER_INFO.pro.price, color: 'text-primary', bg: 'bg-primary/15' },
    { key: 'enterprise', label: 'Enterprise', count: entCount, price: TIER_INFO.enterprise.price, color: 'text-chart-4', bg: 'bg-chart-4/15' }
  ];

  return (
    <div className="space-y-6">
      {/* Revenue Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card rounded-2xl p-5">
          <DollarSign className="w-8 h-8 text-primary mb-3" />
          <p className="font-heading text-2xl font-bold text-foreground">${mrr.toLocaleString()}</p>
          <p className="text-sm text-muted-foreground">Monthly Revenue (MRR)</p>
        </div>
        <div className="glass-card rounded-2xl p-5">
          <TrendingUp className="w-8 h-8 text-chart-2 mb-3" />
          <p className="font-heading text-2xl font-bold text-foreground">${arpu}</p>
          <p className="text-sm text-muted-foreground">ARPU (per user)</p>
        </div>
        <div className="glass-card rounded-2xl p-5">
          <Zap className="w-8 h-8 text-chart-4 mb-3" />
          <p className="font-heading text-2xl font-bold text-foreground">{totalCreditsUsed.toLocaleString()}</p>
          <p className="text-sm text-muted-foreground">Credits Used</p>
        </div>
        <div className="glass-card rounded-2xl p-5">
          <Crown className="w-8 h-8 text-chart-5 mb-3" />
          <p className="font-heading text-2xl font-bold text-foreground">{proCount + entCount}</p>
          <p className="text-sm text-muted-foreground">Paying Subscribers</p>
        </div>
      </div>

      {/* Tier Breakdown */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Revenue by Tier</h3>
        <div className="space-y-4">
          {tiers.map((tier) => {
            const revenue = tier.count * tier.price;
            const maxRev = Math.max(...tiers.map(t => t.count * t.price), 1);
            const widthPct = (tier.count * tier.price / maxRev) * 100;
            return (
              <div key={tier.key}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${tier.bg}`} />
                    <span className="text-sm font-medium text-foreground">{tier.label}</span>
                    <span className="text-xs text-muted-foreground">{tier.count} users</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground">${tier.price}/mo each</span>
                    <span className="text-sm font-semibold text-foreground">${revenue.toLocaleString()}/mo</span>
                  </div>
                </div>
                <div className="h-2 rounded-full bg-accent/30 overflow-hidden">
                  <div className={`h-full rounded-full ${tier.bg} transition-all duration-500`} style={{ width: `${widthPct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-6 pt-4 border-t border-border/50 flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Total Credits Allocated</span>
          <span className="text-sm font-medium text-foreground">{totalCreditsLimit.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}