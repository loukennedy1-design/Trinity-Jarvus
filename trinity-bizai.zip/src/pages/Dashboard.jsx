import React from 'react';
import { Link } from 'react-router-dom';
import { LayoutDashboard, Briefcase, Trophy, DollarSign, BookOpen } from 'lucide-react';
import BusinessPage from '@/components/business/BusinessPage';
import StatCard from '@/components/StatCard';
import useBusinessData, { metrics, money } from '@/components/business/useBusinessData';
export default function Dashboard() {
  const { data, isLoading, error } = useBusinessData(); const m = metrics(data);
  return <BusinessPage title="Business Dashboard" subtitle="Your federal contracting business, at a glance." icon={LayoutDashboard} loading={isLoading} error={error}>
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4"><StatCard icon={Briefcase} label="Active opportunities" value={m.active.length} /><StatCard icon={Trophy} label="Proposal success rate" value={m.rate} sublabel="Won ÷ decided bids" /><StatCard icon={DollarSign} label="Pipeline value" value={money(m.pipeline)} sublabel="Recorded estimated values" /><StatCard icon={BookOpen} label="Knowledge entries" value={data?.knowledge.length || 0} /></div>
    <div className="grid lg:grid-cols-2 gap-5"><section className="glass-card rounded-2xl p-6 space-y-4"><div className="flex justify-between"><h2 className="font-semibold">Active Opportunities</h2><Link className="text-primary text-sm" to="/bid-pipeline">View pipeline</Link></div>{!m.active.length && <p className="text-muted-foreground">No active opportunities. <Link to="/contracts" className="text-primary">Search contracts</Link> to get started.</p>}{m.active.slice(0,6).map(o => <Link key={o.id} to="/bid-pipeline" className="block border-t pt-3"><p>{o.title}</p><p className="text-sm text-muted-foreground">{o.agency || 'Agency not specified'} · {o.status.replaceAll('_',' ')}</p></Link>)}</section>
    <section className="glass-card rounded-2xl p-6 space-y-4"><div className="flex justify-between"><h2 className="font-semibold">Recent Activity</h2><Link className="text-primary text-sm" to="/activity-log">View all</Link></div>{!data?.activity.length && <p className="text-muted-foreground">New searches, analyses, and drafts will appear here.</p>}{data?.activity.slice(0,6).map(a => <div key={a.id} className="border-t pt-3"><p>{a.description}</p><p className="text-sm text-muted-foreground">{new Date(a.created_date).toLocaleString()}</p></div>)}</section></div>
    <Link to="/proposals" className="inline-block text-primary">Open Proposal Library →</Link>
  </BusinessPage>;
}