import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import ChatMessage from '@/components/ChatMessage';
import ChatInput from '@/components/ChatInput';
import TrinityOrb from '@/components/TrinityOrb';
import AISystemsPanel from '@/components/AISystemsPanel';
import { Plus, Search, Link2 } from 'lucide-react';

export default function Connector() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadOrCreateConversation();
  }, []);

  const loadOrCreateConversation = async () => {
    setLoading(true);
    try {
      const list = await base44.agents.listConversations({
        q: { agent_name: 'trinity_connector' },
        sort: '-created_date',
        limit: 1
      });
      if (list && list.length > 0) {
        const conv = await base44.agents.getConversation(list[0].id);
        setConversation(conv);
        setMessages(conv.messages || []);
      } else {
        await createNewConversation();
        return;
      }
    } catch (err) {
      console.error('Failed to load conversation:', err);
      await createNewConversation();
      return;
    }
    setLoading(false);
  };

  useEffect(() => {
    if (conversation?.id) {
      let unsubscribe = () => {};
      try {
        unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
          setMessages(data.messages || []);
        });
      } catch (err) {
        console.error('Subscription failed, using static messages:', err);
      }
      return () => unsubscribe();
    }
  }, [conversation?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const createNewConversation = async () => {
    setLoading(true);
    setMessages([]);
    try {
      const conv = await base44.agents.createConversation({
        agent_name: 'trinity_connector',
        metadata: { name: 'Connector Chat', description: 'Search & connect assistant' }
      });
      setConversation(conv);
      setMessages(conv.messages || []);
    } catch (err) {
      console.error('Failed to create conversation:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (text, files) => {
    if (!conversation || creating) return;
    setCreating(true);
    try {
      const fileUrls = files.map(f => f.url);
      const result = await base44.functions.invoke('sendChatMessage', {
        conversation,
        message: text,
        file_urls: fileUrls.length ? fileUrls : undefined
      });
      if (result.data?.error === 'message_limit_reached') {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: "You've reached your **free monthly message limit** (50 messages). Upgrade to **Pro** for unlimited chat — visit the Subscription page to upgrade.",
          id: 'limit-' + Date.now()
        }]);
        return;
      }
      if (result.data?.messages) {
        setMessages(result.data.messages);
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setCreating(false);
    }
  };

  const isAssistantThinking = messages.length > 0 &&
    messages[messages.length - 1].role === 'user' &&
    creating;

  return (
    <div className="h-full flex flex-col aurora-bg">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border/50 backdrop-blur-xl bg-card/20">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 flex items-center justify-center">
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-chart-4 via-primary to-chart-2 animate-orb-pulse" />
              <Link2 className="absolute inset-0 m-auto w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-heading font-semibold text-foreground">Trinity Connector</h1>
              <p className="text-xs text-muted-foreground">Search anything · Connect any system</p>
            </div>
          </div>
          <button
            onClick={createNewConversation}
            className="flex items-center gap-2 px-3 py-2 rounded-xl glass-card hover:border-primary/30 transition-all text-sm text-foreground"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Chat</span>
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 md:px-6 py-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <TrinityOrb size={100} active />
              <p className="text-muted-foreground mt-6 text-sm">Starting Connector...</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="relative w-24 h-24 flex items-center justify-center mb-6">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-chart-4 via-primary to-chart-2 animate-orb-pulse opacity-80" />
                <Link2 className="relative w-10 h-10 text-primary-foreground" />
              </div>
              <h2 className="font-heading text-2xl font-semibold text-foreground mb-2">
                Search & Connect
              </h2>
              <p className="text-muted-foreground max-w-md mb-8">
                I can search the web for any information and connect Trinity to your external systems — Google, Slack, Outlook, and more.
              </p>
              <div className="max-w-2xl w-full mb-8">
                <AISystemsPanel />
              </div>
              <div className="grid sm:grid-cols-2 gap-3 max-w-2xl w-full">
                {suggestions.map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => handleSend(suggestion, [])}
                    className="glass-card rounded-xl p-4 text-left text-sm text-foreground/80 hover:border-primary/30 hover:text-foreground transition-all"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => (
                <ChatMessage key={msg.id || idx} message={msg} />
              ))}
              {isAssistantThinking && (
                <ChatMessage message={{ role: 'assistant', content: '' }} />
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="px-4 md:px-6 py-4 border-t border-border/50 backdrop-blur-xl bg-card/20">
        <div className="max-w-4xl mx-auto">
          <ChatInput
            onSend={handleSend}
            disabled={creating || loading}
            placeholder="Ask me to search for anything or connect a service..."
          />
        </div>
      </div>
    </div>
  );
}

const suggestions = [
  'Search the web for the latest trends in AI for business',
  'Connect Trinity to my Google Drive',
  'Learn about supply chain optimization from other AI systems',
  'Find information about my competitors and connect Slack for team updates'
];