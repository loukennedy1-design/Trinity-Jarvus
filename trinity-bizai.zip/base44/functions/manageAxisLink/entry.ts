import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getAxisLink, startAxisLink, completeAxisLink } from '../../shared/axisLink.ts';
import { recordActivity } from '../../shared/activity.ts';

const CALLBACK_PATH = '/integrations/axis/callback';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'status';

    if (action === 'status') {
      const link = await getAxisLink(base44, user);
      return Response.json({
        connected: link?.status === 'connected',
        status: link?.status || 'not_connected',
        connected_at: link?.connected_at || null,
      });
    }

    if (action === 'start') {
      let redirect = null;
      try { redirect = new URL(String(body.redirect_uri || '')); } catch { redirect = null; }
      if (!redirect || redirect.protocol !== 'https:' || redirect.pathname !== CALLBACK_PATH || redirect.search || redirect.hash) {
        return Response.json({ error: 'invalid_redirect', message: 'Invalid return address for the Axis sign-in.' }, { status: 400 });
      }
      const authUrl = await startAxisLink(base44, user, redirect.toString());
      return Response.json({ auth_url: authUrl });
    }

    if (action === 'complete') {
      const code = typeof body.code === 'string' ? body.code : '';
      const state = typeof body.state === 'string' ? body.state : '';
      if (!code || !state || code.length > 4096 || state.length > 256) {
        return Response.json({ error: 'invalid_request', message: 'The Axis sign-in response was incomplete.' }, { status: 400 });
      }
      await completeAxisLink(base44, user, code, state);
      recordActivity(base44, user, 'connection', 'Axis Business Suite connected via sign-in.');
      return Response.json({ connected: true, status: 'connected' });
    }

    if (action === 'disconnect') {
      await base44.asServiceRole.entities.PartnerConnection.deleteMany({ owner_id: user.id, partner: 'axis' });
      recordActivity(base44, user, 'connection', 'Axis Business Suite disconnected.');
      return Response.json({ connected: false, status: 'not_connected' });
    }

    return Response.json({ error: 'Unsupported action.' }, { status: 400 });
  } catch (error) {
    console.error('manageAxisLink failed:', error?.message);
    const expired = error?.message === 'state_mismatch';
    return Response.json({
      error: 'axis_link_failed',
      message: expired ? 'This sign-in link expired. Start the Axis connection again.' : 'The Axis connection could not be completed. Please try again.',
    }, { status: expired ? 400 : 500 });
  }
}